# SpamGuard AI - Advanced Spam Email Prediction System

A modern, production-ready web application that uses machine learning to accurately predict spam emails with confidence scores and risk assessment.

## Features

### 🔐 **User Authentication System**
- Secure user registration and login
- Email validation and password encryption
- Session management
- Role-based access control (Admin/User)

### 🤖 **Machine Learning Spam Detection**
- Multiple ML algorithms: Naive Bayes, Logistic Regression, SVM
- Ensemble method for improved accuracy
- Real-time predictions with confidence scores
- Risk level indicators (Low/Medium/High)
- Keyword highlighting and analysis

### 📊 **Admin Panel Dashboard**
- User management (activate/deactivate/delete)
- System analytics and reports
- Model retraining capabilities
- Prediction statistics and trends
- Dataset management

### 🎨 **Modern UI/UX Design**
- Responsive design for all devices
- Dark/Light mode support
- Interactive charts and graphs
- Smooth animations and transitions
- Professional interface

### 🛡️ **Advanced Security**
- CSRF protection
- Password hashing with bcrypt
- Secure API endpoints
- Input validation and sanitization

## Tech Stack

### Backend
- **Python 3.8+**
- **Flask** - Web framework
- **SQLAlchemy** - Database ORM
- **Flask-Login** - Authentication
- **Flask-WTF** - Form handling and CSRF protection

### Machine Learning
- **Scikit-learn** - ML algorithms
- **Pandas** - Data manipulation
- **NumPy** - Numerical operations
- **NLTK** - Natural language processing

### Frontend
- **HTML5 & CSS3**
- **Bootstrap 5** - UI framework
- **JavaScript (ES6+)**
- **Chart.js** - Data visualization
- **Font Awesome** - Icons

### Database
- **SQLite** (development)
- **PostgreSQL/MySQL** (production)

## Quick Start

### Prerequisites
- Python 3.8 or higher
- pip package manager
- Git

### Installation

1. **Clone the repository**
```bash
git clone <repository-url>
cd spam-email
```

2. **Create virtual environment**
```bash
python -m venv venv
# Windows
venv\Scripts\activate
# macOS/Linux
source venv/bin/activate
```

3. **Install dependencies**
```bash
pip install -r requirements.txt
```

4. **Set up environment variables**
```bash
cp .env.example .env
# Edit .env with your configuration
```

5. **Initialize the database**
```bash
python app.py
```

6. **Run the application**
```bash
python app.py
```

7. **Open in browser**
Navigate to `http://localhost:5000`

## Project Structure

```
spam-email/
├── app.py                 # Main Flask application
├── config.py             # Configuration settings
├── requirements.txt      # Python dependencies
├── .env.example         # Environment variables template
├── templates/           # HTML templates
│   ├── base.html       # Base template
│   ├── index.html      # Landing page
│   ├── login.html      # Login page
│   ├── register.html   # Registration page
│   ├── dashboard.html  # User dashboard
│   ├── history.html    # Prediction history
│   └── admin/          # Admin templates
│       └── dashboard.html
├── static/             # Static files
│   ├── css/
│   │   └── style.css   # Custom styles
│   ├── js/
│   │   └── main.js     # Main JavaScript
│   └── images/         # Image assets
├── models/             # Trained ML models
├── data/               # Dataset files
└── README.md          # This file
```

## Usage

### For Users

1. **Register an account**
   - Visit the registration page
   - Fill in username, email, and password
   - Click "Create Account"

2. **Login to your dashboard**
   - Use your credentials to log in
   - Access the spam prediction interface

3. **Analyze emails**
   - Paste or type email content
   - Select ML model (or use ensemble)
   - Click "Analyze Email"
   - View results with confidence score and risk level

4. **View history**
   - Track all your predictions
   - Export reports for analysis

### For Admins

1. **Access admin panel**
   - Admin users have access to comprehensive dashboard
   - Monitor system statistics
   - Manage users

2. **User management**
   - View all registered users
   - Activate/deactivate accounts
   - Delete users if needed

3. **Model management**
   - Retrain ML models with new data
   - Monitor model performance
   - View prediction analytics

## Machine Learning Models

### Supported Algorithms

1. **Naive Bayes**
   - Fast and efficient
   - Good baseline performance
   - Works well with text data

2. **Logistic Regression**
   - Interpretable results
   - Good performance on balanced datasets
   - Provides probability estimates

3. **Support Vector Machine (SVM)**
   - High accuracy
   - Works well with high-dimensional data
   - Effective with text classification

4. **Ensemble Method**
   - Combines predictions from all models
   - Improved accuracy and reliability
   - Recommended for production use

### Model Training

- Models are automatically trained on first run
- Uses sample dataset if no data available
- Models are saved in `models/` directory
- Can be retrained from admin panel

## API Endpoints

### Authentication
- `POST /login` - User login
- `POST /register` - User registration
- `GET /logout` - User logout

### Prediction
- `POST /predict` - Analyze email content
- `GET /history` - Get prediction history

### Admin
- `GET /admin` - Admin dashboard
- `POST /admin/train_model` - Retrain models

## Configuration

### Environment Variables

```bash
# Flask Configuration
SECRET_KEY=your-secret-key
DATABASE_URL=sqlite:///spam_email.db

# Email Configuration
MAIL_SERVER=smtp.gmail.com
MAIL_PORT=587
MAIL_USE_TLS=true
MAIL_USERNAME=your-email@gmail.com
MAIL_PASSWORD=your-app-password
```

### Database Setup

#### SQLite (Development)
```python
DATABASE_URL=sqlite:///spam_email.db
```

#### PostgreSQL (Production)
```python
DATABASE_URL=postgresql://username:password@localhost/spam_email_db
```

#### MySQL (Production)
```python
DATABASE_URL=mysql://username:password@localhost/spam_email_db
```

## Security Features

- **CSRF Protection**: All forms protected with CSRF tokens
- **Password Hashing**: Uses bcrypt for secure password storage
- **Input Validation**: Server-side validation for all inputs
- **SQL Injection Protection**: SQLAlchemy ORM prevents SQL injection
- **XSS Protection**: Template auto-escaping prevents XSS attacks

## Deployment

### Production Deployment

1. **Set production environment**
```bash
export FLASK_ENV=production
export FLASK_DEBUG=false
```

2. **Use production database**
```bash
# PostgreSQL recommended for production
DATABASE_URL=postgresql://user:pass@localhost/dbname
```

3. **Use production web server**
```bash
# Install gunicorn
pip install gunicorn

# Run with gunicorn
gunicorn -w 4 -b 0.0.0.0:8000 app:app
```

4. **Set up reverse proxy (nginx)**
```nginx
server {
    listen 80;
    server_name your-domain.com;
    
    location / {
        proxy_pass http://127.0.0.1:8000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }
}
```

### Docker Deployment

```dockerfile
FROM python:3.9-slim

WORKDIR /app
COPY requirements.txt .
RUN pip install -r requirements.txt

COPY . .
EXPOSE 5000

CMD ["gunicorn", "-w", "4", "-b", "0.0.0.0:5000", "app:app"]
```

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests if applicable
5. Submit a pull request

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Support

For support and questions:
- Create an issue in the repository
- Email: support@spamguard.ai
- Documentation: [Link to docs]

## Changelog

### Version 1.0.0
- Initial release
- Basic spam detection functionality
- User authentication system
- Admin panel
- Responsive design
- Dark mode support

---

**SpamGuard AI** - Protect your inbox with the power of machine learning!
