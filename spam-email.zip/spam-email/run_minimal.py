#!/usr/bin/env python
"""
Minimal run script for SpamGuard AI Application
"""

import os
import sys

# Add current directory to path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

print("🔧 Starting minimal SpamGuard AI Application...")

try:
    # Try importing step by step
    print("Importing Flask...")
    from flask import Flask
    print("✅ Flask imported")
    
    print("Importing app_simple...")
    import app_simple
    print("✅ app_simple imported")
    
    # Get the app
    app = app_simple.app
    
    print("🚀 Starting application on http://localhost:5000")
    app.run(host='0.0.0.0', port=5000, debug=True)
    
except Exception as e:
    print(f"❌ Error: {e}")
    import traceback
    traceback.print_exc()
