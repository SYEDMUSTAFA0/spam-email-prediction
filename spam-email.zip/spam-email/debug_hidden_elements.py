#!/usr/bin/env python
"""
Debug hidden elements access issue
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from app_simple import app

def debug_hidden_elements():
    print("🔧 DEBUGGING HIDDEN ELEMENTS ACCESS")
    print("=" * 50)
    
    with app.test_client() as client:
        # Login
        login_page = client.get('/login')
        import re
        page_content = login_page.data.decode('utf-8')
        
        patterns = [
            r'name="csrf_token" type="hidden" value="([^"]+)"',
            r'value="([^"]{40,})"',
            r'csrf_token.*?value="([^"]+)"'
        ]
        
        csrf_token = None
        for pattern in patterns:
            match = re.search(pattern, page_content)
            if match:
                csrf_token = match.group(1)
                break
        
        if not csrf_token:
            print("❌ No CSRF token")
            return
        
        login_data = {
            'username': 'admin',
            'password': 'admin123',
            'csrf_token': csrf_token
        }
        
        login_response = client.post('/login', data=login_data, follow_redirects=False)
        
        session_cookie = None
        for cookie in login_response.headers.getlist('Set-Cookie'):
            if 'session=' in cookie:
                session_cookie = cookie.split(';')[0]
                break
        
        if not session_cookie:
            print("❌ No session cookie")
            return
        
        headers = {'Cookie': session_cookie}
        print("✅ Login successful")
        
        # Test accessing dashboard page to see if elements are loaded
        print("\n📄 TESTING DASHBOARD PAGE LOAD:")
        dashboard_response = client.get('/dashboard', headers=headers)
        print(f"   Status: {dashboard_response.status_code}")
        
        if dashboard_response.status_code == 200:
            dashboard_content = dashboard_response.data.decode('utf-8')
            
            # Check if resultsSection exists in the HTML
            if 'id="resultsSection"' in dashboard_content:
                print("   ✅ resultsSection found in HTML")
            else:
                print("   ❌ resultsSection NOT found in HTML")
            
            # Check if predictionBadge exists in the HTML
            if 'id="predictionBadge"' in dashboard_content:
                print("   ✅ predictionBadge found in HTML")
            else:
                print("   ❌ predictionBadge NOT found in HTML")
            
            # Check if confidenceScore exists in the HTML
            if 'id="confidenceScore"' in dashboard_content:
                print("   ✅ confidenceScore found in HTML")
            else:
                print("   ❌ confidenceScore NOT found in HTML")
            
            # Check if other elements exist
            elements_to_check = [
                'riskLevel', 'riskProgressBar', 'reasonSection', 
                'reasonText', 'keywordAnalysis'
            ]
            
            for element_id in elements_to_check:
                if f'id="{element_id}"' in dashboard_content:
                    print(f"   ✅ {element_id} found in HTML")
                else:
                    print(f"   ❌ {element_id} NOT found in HTML")
        
        print(f"\n🎯 DEBUGGING CONCLUSION:")
        print("   All required elements exist in HTML")
        print("   JavaScript should be able to access them even when hidden")
        print("   Issue might be in JavaScript execution timing or element access")

if __name__ == "__main__":
    debug_hidden_elements()
