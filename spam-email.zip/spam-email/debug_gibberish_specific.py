#!/usr/bin/env python
"""
Debug specific gibberish case
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from app_simple import EnhancedSpamDetector

def debug_gibberish_specific():
    print("🔧 DEBUGGING SPECIFIC GIBBERISH CASE")
    print("=" * 50)
    
    detector = EnhancedSpamDetector()
    
    text = "jevdwhucwqhjbeflj3beoiu18u0398098"
    print(f"Text: '{text}'")
    print(f"Length: {len(text)}")
    
    # Test validation
    validation = detector.validate_input(text)
    print(f"Valid: {validation['valid']}")
    
    if not validation['valid']:
        print(f"Error: {validation['error']}")
        print(f"Reason: {validation['reason']}")
    else:
        print("❌ Validation passed - this is the problem!")
        
        # Test gibberish detection directly
        gibberish_result = detector._is_gibberish(text)
        print(f"Gibberish detection: {gibberish_result}")
        
        # Test prediction
        result = detector.predict(text)
        print(f"Prediction: {result['prediction']}")
        print(f"Confidence: {result['confidence']}%")
        
        # Check spam patterns
        spam_patterns, pattern_score = detector.detect_spam_patterns(text)
        print(f"Spam patterns: {spam_patterns}")
        print(f"Pattern score: {pattern_score}")

if __name__ == "__main__":
    debug_gibberish_specific()
