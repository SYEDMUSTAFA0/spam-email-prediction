#!/usr/bin/env python
"""
Test the complete login and prediction flow
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from app_simple import app, db, User
from flask import session
import json

def test_login_prediction_flow():
    print("🔧 Testing login and prediction flow...")
    
    with app.test_client() as client:
        with client.session_transaction() as sess:
            # Test 1: Access predict without login (should fail)
            print("\n1. Testing prediction without login...")
            response = client.post('/api/predict', 
                json={
                    'email_content': 'test spam content',
                    'model': 'rule_based'
                }
            )
            print(f"   Status: {response.status_code}")
            print(f"   Content-Type: {response.content_type}")
            print(f"   Response: {response.get_json() if response.content_type == 'application/json' else response.data[:200]}")
            
            # Test 2: Login with CSRF token
            print("\n2. Testing login...")
            # First get login page to get CSRF token
            login_page = client.get('/login')
            csrf_token = None
            if b'csrf_token' in login_page.data:
                import re
                csrf_match = re.search(b'name="csrf_token" type="hidden" value="([^"]+)"', login_page.data)
                if csrf_match:
                    csrf_token = csrf_match.group(1).decode('utf-8')
            
            print(f"   CSRF token: {csrf_token}")
            
            login_data = {
                'username': 'admin',
                'password': 'admin123',
                'csrf_token': csrf_token
            }
            
            response = client.post('/login', data=login_data, follow_redirects=True)
            print(f"   Status: {response.status_code}")
            print(f"   Response: {response.data[:200]}")
            
            # Test 3: Access predict after login (should work)
            print("\n3. Testing prediction after login...")
            response = client.post('/api/predict', 
                json={
                    'email_content': 'test spam content',
                    'model': 'rule_based'
                }
            )
            print(f"   Status: {response.status_code}")
            print(f"   Content-Type: {response.content_type}")
            print(f"   Response: {response.get_json() if response.content_type == 'application/json' else response.data[:200]}")
            
            print("\n🔧 Flow test completed!")

if __name__ == "__main__":
    test_login_prediction_flow()
