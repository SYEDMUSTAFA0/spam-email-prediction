#!/usr/bin/env python3
"""
Debug the spam detection issue for normal text
"""

import requests
import json

def debug_normal_text():
    """Debug why normal text is being classified as spam"""
    base_url = "http://localhost:5000"
    
    print("🔍 Debugging Normal Text Classification Issue")
    print("=" * 60)
    
    # Test cases that should be NOT SPAM
    test_cases = [
        "hello brother",
        "hey i'm sagar",
        "hi how are you",
        "good morning",
        "please review the document",
        "thanks for your help",
        "see you tomorrow",
        "have a great day"
    ]
    
    for i, text in enumerate(test_cases, 1):
        print(f"\n{i}. Testing: \"{text}\"")
        
        try:
            response = requests.post(
                f"{base_url}/api/predict",
                json={"email_text": text},
                headers={"Content-Type": "application/json"},
                timeout=10
            )
            
            if response.status_code == 200:
                result = response.json()
                
                print(f"   Prediction: {result['prediction']}")
                print(f"   Confidence: {result['confidence']}%")
                print(f"   Spam Probability: {result['spam_probability']}%")
                print(f"   Risk Level: {result['risk_level']}")
                print(f"   Reason: {result['reason']}")
                print(f"   Keywords: {result['keywords']}")
                print(f"   Model: {result['model_used']}")
                
                # Check if this is an incorrect classification
                if result['prediction'].lower() == 'spam':
                    print(f"   ❌ INCORRECT: This should be NOT SPAM!")
                else:
                    print(f"   ✅ CORRECT: Properly classified as NOT SPAM")
                    
            else:
                print(f"   ❌ API Error: {response.status_code}")
                print(f"   Response: {response.text}")
                
        except Exception as e:
            print(f"   ❌ Request failed: {e}")
    
    print(f"\n" + "=" * 60)
    print("🔧 Analysis:")
    print("If normal text is being classified as SPAM, the issue is likely:")
    print("1. Hybrid scoring algorithm is too aggressive")
    print("2. Keyword detection is flagging common words")
    print("3. Threshold values are too low")
    print("4. ML model needs calibration for conversational text")

if __name__ == "__main__":
    debug_normal_text()
