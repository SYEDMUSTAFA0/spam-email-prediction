#!/usr/bin/env python
"""
Debug individual models to see if they're working correctly
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from app import app, classifier
import numpy as np

def debug_individual_models():
    with app.app_context():
        test_spam = "Congratulations! You have won $1000000 in our lottery. Call now to claim your prize!"
        test_ham = "Hello, how are you doing today?"
        
        print("🔍 Debugging individual models...")
        print("=" * 60)
        
        # Test preprocessing
        processed_spam = classifier.preprocess_text(test_spam)
        processed_ham = classifier.preprocess_text(test_ham)
        
        print(f"Original spam: '{test_spam}'")
        print(f"Processed spam: '{processed_spam}'")
        print(f"Original ham: '{test_ham}'")
        print(f"Processed ham: '{processed_ham}'")
        print("-" * 60)
        
        # Vectorize
        X_spam = classifier.vectorizer.transform([processed_spam])
        X_ham = classifier.vectorizer.transform([processed_ham])
        
        print(f"Vectorized spam shape: {X_spam.shape}")
        print(f"Vectorized ham shape: {X_ham.shape}")
        print("-" * 60)
        
        # Test each model
        for model_name, model in classifier.models.items():
            print(f"\n📊 Testing {model_name} model:")
            
            # Predictions
            pred_spam = model.predict(X_spam)[0]
            pred_ham = model.predict(X_ham)[0]
            
            # Probabilities
            prob_spam = model.predict_proba(X_spam)[0]
            prob_ham = model.predict_proba(X_ham)[0]
            
            print(f"  Spam prediction: {pred_spam} (probabilities: {prob_spam})")
            print(f"  Ham prediction: {pred_ham} (probabilities: {prob_ham})")
            
            # Convert to text
            spam_label = 'spam' if pred_spam == 1 else 'not spam'
            ham_label = 'spam' if pred_ham == 1 else 'not spam'
            
            print(f"  Spam result: {spam_label}")
            print(f"  Ham result: {ham_label}")
            print("-" * 40)

if __name__ == "__main__":
    debug_individual_models()
