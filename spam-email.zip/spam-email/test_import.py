#!/usr/bin/env python
print("Testing imports...")

try:
    import html
    print("✅ html import successful")
except ImportError as e:
    print(f"❌ html import failed: {e}")

try:
    import bleach
    print("✅ bleach import successful")
except ImportError as e:
    print(f"❌ bleach import failed: {e}")

try:
    from app_simple import app
    print("✅ app_simple import successful")
except ImportError as e:
    print(f"❌ app_simple import failed: {e}")

print("Test completed.")
