#!/usr/bin/env python
"""
Debug the actual numeric predictions in ensemble
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from app import app, classifier
import numpy as np

def debug_predictions():
    with app.app_context():
        test_spam = "Congratulations! You have won $1000000 in our lottery. Call now to claim your prize!"
        test_ham = "Hello, how are you doing today?"
        
        print("🔍 Debugging ensemble predictions in detail...")
        print("=" * 60)
        
        for text_name, text in [("Spam", test_spam), ("Ham", test_ham)]:
            print(f"\n📧 {text_name} message: '{text}'")
            
            processed = classifier.preprocess_text(text)
            X = classifier.vectorizer.transform([processed])
            
            predictions = []
            confidences = []
            
            for name, model in classifier.models.items():
                pred = model.predict(X)[0]
                conf = model.predict_proba(X)[0].max()
                predictions.append(pred)
                confidences.append(conf)
                print(f"  {name}: numeric_pred={pred}, confidence={conf:.3f}")
            
            print(f"  All predictions: {predictions}")
            print(f"  Prediction counts: {{pred: predictions.count(pred) for pred in set(predictions)}}")
            
            # Majority voting
            final_pred = max(set(predictions), key=predictions.count)
            avg_confidence = np.mean(confidences)
            
            print(f"  Final numeric prediction: {final_pred}")
            print(f"  Final confidence: {avg_confidence:.3f}")
            
            prediction_label = 'spam' if final_pred == 1 else 'not spam'
            print(f"  Final label: {prediction_label}")
            print("-" * 50)

if __name__ == "__main__":
    debug_predictions()
