from flask import Flask, render_template, request, jsonify, redirect, url_for, flash, session, send_file
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, login_user, logout_user, login_required, current_user
from flask_wtf.csrf import CSRFProtect
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime
import os
import re
import random
import nltk
from nltk.corpus import stopwords
from nltk.stem import PorterStemmer
import pandas as pd

app = Flask(__name__)
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY') or 'your-secret-key-here-change-in-production'
app.config['SQLALCHEMY_DATABASE_URI'] = os.environ.get('DATABASE_URL') or 'sqlite:///spam_email.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'
# CSRF Protection - Exclude API endpoints from CSRF
csrf = CSRFProtect(app)

# Configure CSRF to exempt API endpoints
@app.before_request
def csrf_exempt_api():
    """Exempt API endpoints from CSRF protection"""
    if request.path.startswith('/api/') or request.is_json:
        csrf.exempt = True

# Download NLTK data
try:
    nltk.data.find('tokenizers/punkt')
    nltk.data.find('corpora/stopwords')
    nltk.data.find('tokenizers/punkt_tab')
except LookupError:
    print("📥 Downloading NLTK data...")
    nltk.download('punkt')
    nltk.download('punkt_tab')
    nltk.download('stopwords')
    print("✅ NLTK data downloaded successfully")

# Database Models
class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(128), nullable=False)
    is_admin = db.Column(db.Boolean, default=False)
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    predictions = db.relationship('Prediction', backref='user', lazy=True)
    
    def set_password(self, password):
        self.password_hash = generate_password_hash(password)
    
    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

class Prediction(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    email_content = db.Column(db.Text, nullable=False)
    prediction = db.Column(db.String(10), nullable=False)  # 'spam' or 'ham'
    confidence_score = db.Column(db.Float, nullable=False)
    risk_level = db.Column(db.String(10), nullable=False)  # 'low', 'medium', 'high'
    model_used = db.Column(db.String(50), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class SpamDataset(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    email_text = db.Column(db.Text, nullable=False)
    label = db.Column(db.String(10), nullable=False)  # 'spam' or 'ham'
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

# Simple Rule-Based Spam Classifier
class SimpleSpamClassifier:
    def __init__(self):
        self.stemmer = PorterStemmer()
        self.stop_words = set(stopwords.words('english'))
        
        # Spam indicators with weights
        self.spam_indicators = {
            'urgent': 0.8,
            'free': 0.7,
            'win': 0.8,
            'prize': 0.9,
            'money': 0.6,
            'cash': 0.7,
            'limited': 0.6,
            'offer': 0.5,
            'click': 0.6,
            'buy': 0.5,
            'now': 0.4,
            'guaranteed': 0.8,
            'risk': 0.5,
            'congratulations': 0.9,
            'viagra': 1.0,
            'casino': 0.9,
            'lottery': 0.9,
            'million': 0.8,
            'discount': 0.5,
            'promotion': 0.4,
            'special': 0.3,
            'exclusive': 0.4,
            'act now': 0.8,
            'call now': 0.7,
            'order now': 0.6,
            'subscribe': 0.3,
            'unsubscribe': 0.2,
            'spam': 0.9,
            'deal': 0.5,
            'save': 0.4,
            'cheap': 0.6,
            'winner': 0.9,
            'selected': 0.8,
            'bonus': 0.7,
            'credit': 0.5,
            'loan': 0.7,
            'investment': 0.6,
            'debt': 0.5,
            'refund': 0.6,
            'insurance': 0.5,
            'warranty': 0.4,
            'guarantee': 0.7,
            'break': 0.4,
            'chance': 0.6,
            'opportunity': 0.5,
            'instant': 0.7,
            'quick': 0.4,
            'easy': 0.3,
            'fast': 0.4,
            'new': 0.2,
            'hot': 0.6,
            'sexy': 0.8,
            'adult': 0.7,
            'xxx': 0.9,
            'naked': 0.8,
            'dating': 0.6,
            'singles': 0.7,
            'meet': 0.5,
            'online': 0.3,
            'webcam': 0.8,
            'dating': 0.6,
            'casino': 0.9,
            'poker': 0.8,
            'bet': 0.7,
            'gamble': 0.8,
            'winner': 0.9,
            'congrats': 0.8,
            'claim': 0.7,
            'reward': 0.8,
            'gift': 0.5,
            'present': 0.4,
            'holiday': 0.3,
            'vacation': 0.3,
            'cruise': 0.6,
            'travel': 0.2,
            'flight': 0.2,
            'hotel': 0.3,
            'car': 0.4,
            'weight': 0.5,
            'diet': 0.6,
            'pill': 0.8,
            'medicine': 0.5,
            'health': 0.2,
            'cure': 0.8,
            'cancer': 0.7,
            'virus': 0.9,
            'malware': 0.9,
            'security': 0.3,
            'protect': 0.4,
            'alert': 0.5,
            'warning': 0.4,
            'danger': 0.6,
            'emergency': 0.7,
            'verify': 0.5,
            'confirm': 0.3,
            'update': 0.2,
            'account': 0.4,
            'suspend': 0.7,
            'blocked': 0.8,
            'fraud': 0.9,
            'illegal': 0.8,
            'scam': 0.9,
            'phishing': 0.9,
            'hack': 0.8,
            'crack': 0.9,
            'breach': 0.8,
            'leak': 0.7,
            'expose': 0.6,
            'private': 0.5,
            'confidential': 0.3,
            'secret': 0.6,
            'hidden': 0.7,
            'unauthorized': 0.8,
            'access': 0.4,
            'invasion': 0.8,
            'attack': 0.9,
            'threat': 0.7,
            'risk': 0.5,
            'dangerous': 0.6,
            'vulnerable': 0.7,
            'expire': 0.5,
            'immediate': 0.7,
            'final': 0.4,
            'notice': 0.3,
            'action': 0.2,
            'required': 0.5,
            'failure': 0.6,
            'terminate': 0.8,
            'cancel': 0.4,
            'suspend': 0.7,
            'restrict': 0.6,
            'limit': 0.5,
            'exceed': 0.5,
            'overdue': 0.4,
            'past due': 0.5,
            'collection': 0.6,
            'legal': 0.3,
            'attorney': 0.4,
            'court': 0.6,
            'judgment': 0.7,
            'lien': 0.5,
            'foreclosure': 0.8,
            'bankruptcy': 0.9,
            'divorce': 0.5,
            'inheritance': 0.4,
            'will': 0.3,
            'trust': 0.4,
            'estate': 0.5,
            'beneficiary': 0.6,
            'probate': 0.7,
            'executor': 0.5,
            'bequest': 0.4,
            'legacy': 0.3
        }
        
        # Legitimate indicators with negative weights
        self.legitimate_indicators = {
            'meeting': -0.5,
            'project': -0.4,
            'report': -0.3,
            'deadline': -0.2,
            'team': -0.3,
            'office': -0.4,
            'schedule': -0.3,
            'appointment': -0.4,
            'conference': -0.3,
            'presentation': -0.3,
            'document': -0.2,
            'attachment': -0.1,
            'sincerely': -0.6,
            'regards': -0.5,
            'best': -0.3,
            'thank': -0.4,
            'appreciate': -0.4
        }
    
    def preprocess_text(self, text):
        # Convert to lowercase
        text = text.lower()
        # Remove only numbers and special characters, but keep letters, spaces, and basic punctuation
        text = re.sub(r'[^a-zA-Z\s\!\?\.\,\-]', '', text)
        # Tokenize
        tokens = nltk.word_tokenize(text)
        # Remove stopwords but don't stem too aggressively to preserve compound words
        tokens = [token for token in tokens if token not in self.stop_words]
        return ' '.join(tokens)
    
    def calculate_spam_score(self, text):
        processed_text = self.preprocess_text(text)
        text_lower = text.lower()
        
        spam_score = 0.0
        
        # Check for spam indicators (single words)
        for indicator, weight in self.spam_indicators.items():
            if indicator in text_lower:
                spam_score += weight
        
        # Check for multi-word spam indicators
        multi_word_indicators = {
            'act now': 0.8,
            'limited time': 0.6,
            'order now': 0.6,
            'call now': 0.7,
            'guaranteed cash': 0.8,
            'exclusive deal': 0.6,
            'congratulations winner': 0.9,
            'free viagra': 1.0,
            'special promotion': 0.5,
            'claim reward': 0.8,
            'click here': 0.6
        }
        
        for indicator_phrase, weight in multi_word_indicators.items():
            if indicator_phrase in text_lower:
                spam_score += weight
        
        # Check for legitimate indicators (reduce spam score)
        for indicator, weight in self.legitimate_indicators.items():
            if indicator in text_lower:
                spam_score += weight
        
        # Additional heuristics
        # Check for excessive capitalization
        uppercase_ratio = sum(1 for c in text if c.isupper()) / len(text) if len(text) > 0 else 0
        if uppercase_ratio > 0.3:
            spam_score += 0.5
        
        # Check for excessive punctuation
        punctuation_ratio = sum(1 for c in text if c in '!?$') / len(text) if len(text) > 0 else 0
        if punctuation_ratio > 0.1:
            spam_score += 0.3
        
        # Check for URLs
        url_pattern = r'http[s]?://(?:[a-zA-Z]|[0-9]|[$-_@.&+]|[!*\\(\\),]|(?:%[0-9a-fA-F][0-9a-fA-F]))+'
        urls = re.findall(url_pattern, text)
        spam_score += len(urls) * 0.2
        
        # Check for email addresses
        email_pattern = r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b'
        emails = re.findall(email_pattern, text)
        spam_score += len(emails) * 0.1
        
        # Check for phone numbers
        phone_pattern = r'\b\d{3}[-.]?\d{3}[-.]?\d{4}\b'
        phones = re.findall(phone_pattern, text)
        spam_score += len(phones) * 0.15
        
        # NEW: Check for random character patterns (spam indicators)
        # Check for excessive numbers mixed with letters
        number_letter_mix = re.findall(r'\d+[a-zA-Z]+\d+', text)
        spam_score += len(number_letter_mix) * 0.4
        
        # Check for random alphanumeric sequences
        random_alphanumeric = re.findall(r'[a-zA-Z0-9]{8,}', text)
        spam_score += len(random_alphanumeric) * 0.3
        
        # Check for excessive special characters
        special_chars = sum(1 for c in text if not c.isalnum() and not c.isspace())
        special_ratio = special_chars / len(text) if len(text) > 0 else 0
        if special_ratio > 0.2:
            spam_score += 0.6
        
        # Check for backslashes (common in spam/obfuscation)
        backslashes = text.count('\\')
        if backslashes > 0:
            spam_score += backslashes * 0.3
        
        # Check for hash symbols (common in spam)
        hashes = text.count('#')
        if hashes > 0:
            spam_score += hashes * 0.2
        
        # Check for random looking strings (high entropy)
        words = text.split()
        random_strings = 0
        for word in words:
            if len(word) > 3:
                # Calculate character diversity
                unique_chars = len(set(word.lower()))
                if unique_chars / len(word) > 0.8:  # High diversity suggests randomness
                    random_strings += 1
        spam_score += random_strings * 0.2
        
        # Normalize score to 0-1 range
        spam_score = max(0, min(1, spam_score / 2.0))  # Reduced denominator for more sensitivity
        
        return spam_score
    
    def predict(self, text, model_name='rule_based'):
        spam_score = self.calculate_spam_score(text)
        
        # Determine prediction
        prediction = 'spam' if spam_score > 0.4 else 'ham'  # Lowered threshold for more sensitivity
        
        # Calculate confidence score
        confidence = abs(spam_score - 0.5) * 2  # Distance from 0.5, scaled to 0-1
        confidence = max(0.3, min(0.99, confidence))  # Ensure reasonable range
        
        # Determine risk level
        if spam_score >= 0.8:
            risk_level = 'high'
        elif spam_score >= 0.6:
            risk_level = 'medium'
        else:
            risk_level = 'low'
        
        return prediction, confidence, risk_level

# Security utilities
import html

def sanitize_input(text):
    """Sanitize user input to prevent XSS"""
    if not text:
        return ""
    return html.escape(text)

def validate_email(email):
    """Validate email format"""
    import re
    pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    return re.match(pattern, email) is not None

def validate_username(username):
    """Validate username format"""
    import re
    # Allow alphanumeric, underscores, and hyphens, 3-20 characters
    pattern = r'^[a-zA-Z0-9_-]{3,20}$'
    return re.match(pattern, username) is not None

def validate_password_strength(password):
    """Validate password strength"""
    if len(password) < 8:
        return False, "Password must be at least 8 characters long"
    
    if not re.search(r'[a-z]', password):
        return False, "Password must contain at least one lowercase letter"
    
    if not re.search(r'[A-Z]', password):
        return False, "Password must contain at least one uppercase letter"
    
    if not re.search(r'\d', password):
        return False, "Password must contain at least one number"
    
    if not re.search(r'[^a-zA-Z0-9]', password):
        return False, "Password must contain at least one special character"
    
    return True, "Password meets requirements"

def rate_limit_check(user_id, action='general', limit=10, window=3600):
    """Simple rate limiting implementation"""
    # This is a basic implementation - in production, use Redis or similar
    from datetime import datetime, timedelta
    
    # For now, just return True (implement proper rate limiting in production)
    return True

def log_security_event(event_type, user_id=None, details=None):
    """Log security events"""
    import logging
    logging.basicConfig(level=logging.INFO)
    logger = logging.getLogger(__name__)
    
    log_entry = {
        'timestamp': datetime.utcnow().isoformat(),
        'event_type': event_type,
        'user_id': user_id,
        'ip_address': request.remote_addr if 'request' in globals() else None,
        'details': details
    }
    
    logger.warning(f"Security Event: {log_entry}")

# Database utility functions
def init_database():
    """Initialize database with tables and default admin user"""
    with app.app_context():
        try:
            db.create_all()
            print("✅ Database tables created successfully")
            
            # Create default admin user if not exists
            admin = User.query.filter_by(username='admin').first()
            if not admin:
                admin = User(
                    username='admin',
                    email='admin@spamguard.ai',
                    is_admin=True,
                    is_active=True
                )
                admin.set_password('admin123')
                db.session.add(admin)
                db.session.commit()
                print("✅ Default admin user created (username: admin, password: admin123)")
            else:
                print("✅ Admin user already exists")
                
        except Exception as e:
            print(f"❌ Database initialization error: {e}")
            db.session.rollback()
            raise

def get_database_stats():
    """Get database statistics"""
    with app.app_context():
        try:
            stats = {
                'total_users': User.query.count(),
                'active_users': User.query.filter_by(is_active=True).count(),
                'admin_users': User.query.filter_by(is_admin=True).count(),
                'total_predictions': Prediction.query.count(),
                'spam_predictions': Prediction.query.filter_by(prediction='spam').count(),
                'ham_predictions': Prediction.query.filter_by(prediction='ham').count(),
                'dataset_size': SpamDataset.query.count()
            }
            return stats
        except Exception as e:
            print(f"❌ Error getting database stats: {e}")
            return None

def cleanup_old_predictions(days=30):
    """Clean up predictions older than specified days"""
    with app.app_context():
        try:
            from datetime import timedelta
            cutoff_date = datetime.utcnow() - timedelta(days=days)
            old_predictions = Prediction.query.filter(Prediction.created_at < cutoff_date).all()
            
            count = len(old_predictions)
            for prediction in old_predictions:
                db.session.delete(prediction)
            
            db.session.commit()
            print(f"✅ Cleaned up {count} old predictions")
            return count
        except Exception as e:
            print(f"❌ Error cleaning up predictions: {e}")
            db.session.rollback()
            return 0

# API Error Handler
@app.errorhandler(404)
def not_found_error(error):
    if request.path.startswith('/api/') or request.is_json:
        return jsonify({'error': 'API endpoint not found'}), 404
    return render_template('404.html'), 404

@app.errorhandler(500)
def internal_error(error):
    db.session.rollback()
    if request.path.startswith('/api/') or request.is_json:
        return jsonify({'error': 'Internal server error occurred'}), 500
    return render_template('500.html'), 500

@app.errorhandler(401)
def unauthorized_error(error):
    if request.path.startswith('/api/') or request.is_json:
        return jsonify({'error': 'Authentication required'}), 401
    return redirect(url_for('login'))

@app.errorhandler(403)
def forbidden_error(error):
    if request.path.startswith('/api/') or request.is_json:
        return jsonify({'error': 'Access forbidden'}), 403
    return render_template('403.html'), 403

# Performance optimizations
from functools import wraps
import time

def performance_monitor(f):
    """Decorator to monitor function performance"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        start_time = time.time()
        result = f(*args, **kwargs)
        end_time = time.time()
        
        execution_time = end_time - start_time
        if execution_time > 1.0:  # Log if takes more than 1 second
            print(f"⚠️  Slow operation: {f.__name__} took {execution_time:.2f}s")
        
        return result
    return decorated_function

# Cache frequently accessed data
_cache = {}

def get_cached_data(key, cache_duration=300):
    """Get cached data with expiration"""
    import time
    if key in _cache:
        data, timestamp = _cache[key]
        if time.time() - timestamp < cache_duration:
            return data
        else:
            del _cache[key]
    return None

def set_cached_data(key, data):
    """Set cached data"""
    import time
    _cache[key] = (data, time.time())

# Database query optimizations
def get_user_predictions_optimized(user_id, limit=50):
    """Optimized query for user predictions"""
    try:
        return Prediction.query.filter_by(user_id=user_id)\
                           .order_by(Prediction.created_at.desc())\
                           .limit(limit)\
                           .all()
    except Exception as e:
        print(f"Error getting user predictions: {e}")
        return []

def get_admin_stats_optimized():
    """Optimized admin statistics query"""
    try:
        # Use single query with subqueries for better performance
        stats = db.session.query(
            db.func.count(User.id).label('total_users'),
            db.func.sum(db.case([(User.is_active == True, 1)], else_=0)).label('active_users'),
            db.func.sum(db.case([(User.is_admin == True, 1)], else_=0)).label('admin_users'),
            db.func.count(Prediction.id).label('total_predictions'),
            db.func.sum(db.case([(Prediction.prediction == 'spam', 1)], else_=0)).label('spam_predictions'),
            db.func.sum(db.case([(Prediction.prediction == 'ham', 1)], else_=0)).label('ham_predictions')
        ).first()
        
        return {
            'total_users': stats.total_users or 0,
            'active_users': stats.active_users or 0,
            'admin_users': stats.admin_users or 0,
            'total_predictions': stats.total_predictions or 0,
            'spam_predictions': stats.spam_predictions or 0,
            'ham_predictions': stats.ham_predictions or 0
        }
    except Exception as e:
        print(f"Error getting admin stats: {e}")
        return get_database_stats()  # Fallback to original method

# Enhanced Spam Detector
class EnhancedSpamDetector:
    def __init__(self):
        # Enhanced spam patterns for rule-based detection
        self.spam_patterns = {
            'promotional': [
                'free', 'win', 'prize', 'money', 'cash', 'offer', 'discount', 
                'promotion', 'special', 'deal', 'save', 'cheap', 'buy', 'now', 
                'urgent', 'limited', 'act now', 'click here', 'order now', 'exclusive'
            ],
            'lottery': [
                'lottery', 'winner', 'congratulations', 'selected', 'million', 
                'billion', 'prize', 'claim', 'reward', 'congrats'
            ],
            'suspicious': [
                'viagra', 'casino', 'poker', 'bet', 'gamble', 'xxx', 'adult', 
                'dating', 'webcam', 'sexy', 'naked', 'hot'
            ],
            'financial': [
                'loan', 'credit', 'debt', 'investment', 'insurance', 'refund', 
                'guaranteed', 'risk', 'scam', 'fraud', 'phishing', 'hack', 'breach'
            ],
            'urgency': [
                'urgent', 'immediate', 'final', 'last chance', 'limited time', 
                'expiring', 'act now', 'don\'t wait', 'hurry', 'click now'
            ]
        }
        
        # Suspicious patterns
        self.suspicious_patterns = {
            'exclamation': r'!{2,}',
            'caps': r'[A-Z]{4,}',
            'numbers': r'\d{4,}',
            'special_chars': r'[@#$%^&*]{2,}',
            'random_alphanum': r'[a-zA-Z0-9]{8,}',
            'number_letter_mix': r'\d+[a-zA-Z]+\d+'
        }
        
        # Legitimate indicators
        self.legitimate_patterns = [
            'meeting', 'project', 'report', 'deadline', 'team', 'office', 
            'schedule', 'appointment', 'conference', 'presentation', 
            'document', 'attachment', 'sincerely', 'regards', 'best', 
            'thank', 'appreciate', 'hello', 'hi', 'dear', 'colleague'
        ]
    
    def validate_input(self, text):
        """Validate input text and detect invalid content"""
        if not text or not text.strip():
            return {
                'valid': False,
                'error': 'Email content is required.',
                'reason': 'empty_input'
            }
        
        text = text.strip()
        
        # Check minimum length
        if len(text) < 3:  # Reduced from 5 to 3 characters
            return {
                'valid': False,
                'error': 'Email content too short. Please enter a valid email message.',
                'reason': 'too_short'
            }
        
        # Check maximum length
        if len(text) > 10000:
            return {
                'valid': False,
                'error': 'Email content too long (max 10KB).',
                'reason': 'too_long'
            }
        
        # Check for gibberish/random strings
        gibberish_result = self._is_gibberish(text)
        if gibberish_result['is_gibberish']:  # Removed length condition
            return {
                'valid': False,
                'error': 'Invalid email content. Please enter a meaningful email message.',
                'reason': 'gibberish',
                'details': gibberish_result['details']
            }
        
        # Check for excessive numbers/symbols
        if self._has_excessive_numbers(text):
            return {
                'valid': False,
                'error': 'Invalid email content. Too many numbers detected.',
                'reason': 'excessive_numbers'
            }
        
        if self._has_excessive_symbols(text):
            return {
                'valid': False,
                'error': 'Invalid email content. Too many special characters detected.',
                'reason': 'excessive_symbols'
            }
        
        # Check minimum word count
        words = text.split()
        if len(words) < 1:  # Reduced from 2 to 1 word
            return {
                'valid': False,
                'error': 'Email content too brief. Please enter a complete message.',
                'reason': 'too_few_words'
            }
        
        return {'valid': True, 'error': None, 'reason': None}
    
    def _is_gibberish(self, text):
        """Detect gibberish or random strings"""
        details = []
        
        # Check alphabet ratio
        alpha_chars = sum(1 for c in text if c.isalpha())
        total_chars = len(text.replace(' ', ''))
        if total_chars > 0:
            alpha_ratio = alpha_chars / total_chars
            if alpha_ratio < 0.5:  # Increased threshold from 0.3 to 0.5
                details.append(f"Low alphabet ratio: {alpha_ratio:.2f}")
                return {'is_gibberish': True, 'details': details}
        
        # Check for random character patterns
        words = text.split()
        gibberish_words = 0
        
        for word in words:
            if len(word) > 3:  # Only check words longer than 3 chars
                # Skip common short words that might be flagged incorrectly
                common_words = {'thanks', 'hello', 'hi', 'hey', 'yes', 'no', 'ok', 'bye', 'test', 'call', 'help', 'note'}
                if word.lower().rstrip('!?.') in common_words:  # Remove punctuation for check
                    continue
                    
                # Calculate character diversity
                unique_chars = len(set(word.lower()))
                diversity_ratio = unique_chars / len(word)
                
                # High diversity with no vowels suggests gibberish
                vowels = sum(1 for c in word.lower() if c in 'aeiou')
                vowel_ratio = vowels / len(word)
                
                if diversity_ratio > 0.8 and vowel_ratio < 0.25:  # Made more conservative
                    gibberish_words += 1
                    details.append(f"Gibberish word: {word}")
        
        # If more than 20% of words are gibberish
        gibberish_ratio = gibberish_words / len(words) if words else 0
        if gibberish_ratio > 0.2:  # Reduced from 0.3 to 0.2
            details.append(f"Gibberish words ratio: {gibberish_ratio:.2f}")
            return {'is_gibberish': True, 'details': details}
        
        # Additional check: Very long random alphanumeric strings
        if len(text) > 25 and re.search(r'[a-zA-Z0-9]{20,}', text):  # Increased thresholds
            details.append("Very long alphanumeric string detected")
            return {'is_gibberish': True, 'details': details}
        
        return {'is_gibberish': False, 'details': details}
    
    def _has_excessive_numbers(self, text):
        """Check for excessive numbers"""
        numbers = re.findall(r'\d+', text)
        total_digits = sum(len(num) for num in numbers)
        total_chars = len(text.replace(' ', ''))
        
        if total_chars > 0:
            number_ratio = total_digits / total_chars
            return number_ratio > 0.4  # More than 40% digits
        
        return False
    
    def _has_excessive_symbols(self, text):
        """Check for excessive special characters"""
        special_chars = sum(1 for c in text if not c.isalnum() and not c.isspace())
        total_chars = len(text.replace(' ', ''))
        
        if total_chars > 0:
            symbol_ratio = special_chars / total_chars
            return symbol_ratio > 0.3  # More than 30% special characters
        
        return False
    
    def detect_spam_patterns(self, text):
        """Rule-based spam pattern detection"""
        spam_indicators = []
        spam_score = 0.0
        
        text_lower = text.lower()
        
        # Check spam keywords
        for category, keywords in self.spam_patterns.items():
            matches = []
            for keyword in keywords:
                if keyword in text_lower:
                    matches.append(keyword)
                    spam_score += 0.3
            
            if matches:
                spam_indicators.append({
                    'type': category,
                    'matches': matches,
                    'count': len(matches)
                })
        
        # Check suspicious patterns
        for pattern_name, pattern in self.suspicious_patterns.items():
            matches = re.findall(pattern, text)
            if matches:
                spam_indicators.append({
                    'type': pattern_name,
                    'matches': matches[:3],  # Show first 3 examples
                    'count': len(matches)
                })
                spam_score += len(matches) * 0.2
        
        # Check legitimate patterns (reduce score but be more careful with spam combinations)
        legitimate_matches = 0
        for legit_word in self.legitimate_patterns:
            if legit_word in text_lower:
                legitimate_matches += 1
                spam_score -= 0.1  # Reduced penalty
        
        # Enhanced spam combination detection
        spam_combinations = [
            'last chance', 'limited time', 'get 50% off', 'lose weight', 'guaranteed results',
            'make money', 'quick results', 'high returns', 'credit card', 'debt relief',
            'no credit check', 'investment opportunity', 'exclusive deal', 'expires soon',
            'congratulations winner', 'selected prize', 'free bonus', 'play now',
            'adult dating', 'local singles', 'cheap insurance', 'loan approved'
        ]
        
        for combo in spam_combinations:
            if combo in text_lower:
                spam_score += 0.5  # Strong penalty for spam combinations
        
        if legitimate_matches > 0:
            spam_indicators.append({
                'type': 'legitimate',
                'matches': legitimate_matches,
                'count': legitimate_matches
            })
        
        if legitimate_matches > 0:
            spam_indicators.append({
                'type': 'legitimate',
                'matches': legitimate_matches,
                'count': legitimate_matches
            })
        
        return spam_indicators, max(0, spam_score)
    
    def predict(self, text):
        """Main prediction method - REMOVED OVER-STRICT VALIDATION"""
        # Step 1: Only check for truly empty input
        if not text or text.strip() == "":
            return {
                'prediction': 'invalid',
                'confidence': 0.0,
                'risk_level': 'low',
                'reason': 'Email content cannot be empty',
                'error': 'Email content cannot be empty'
            }
        
        # Step 2: Detect spam patterns (ALWAYS RUN THIS)
        spam_patterns, pattern_score = self.detect_spam_patterns(text)
        
        # Step 3: Rule-based prediction
        if pattern_score > 1.0:
            prediction = 'spam'
            confidence = min(0.95, (pattern_score / 2.0) + 0.5)
            risk_level = 'high'
        elif pattern_score > 0.5:
            prediction = 'spam'
            confidence = min(0.85, (pattern_score / 1.5) + 0.4)
            risk_level = 'medium'
        else:
            prediction = 'ham'
            confidence = 0.8
            risk_level = 'low'
        
        # Step 4: Format response
        response = {
            'prediction': prediction,
            'confidence': round(confidence * 100, 1),
            'risk_level': risk_level,
            'spam_patterns': spam_patterns,
            'pattern_score': round(pattern_score, 2)
        }
        
        # Add reason for prediction
        if prediction == 'spam' and spam_patterns:
            spam_types = [p['type'] for p in spam_patterns if p['type'] != 'legitimate']
            if spam_types:
                response['reason'] = f"Suspicious patterns detected: {', '.join(spam_types[:3])}"
        elif prediction == 'ham':
            response['reason'] = "Content appears to be legitimate"
        
        return response

# Initialize enhanced classifier
classifier = EnhancedSpamDetector()

# Add a version number to force reload
APP_VERSION = "2.0"

# Routes
@app.route('/')
def index():
    return render_template('index.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        
        user = User.query.filter_by(username=username).first()
        
        if user and user.check_password(password) and user.is_active:
            login_user(user, remember=True)
            next_page = request.args.get('next')
            return redirect(next_page) if next_page else redirect(url_for('dashboard'))
        else:
            flash('Invalid username or password', 'error')
    
    return render_template('login.html')

@app.route('/quick-register')
def quick_register():
    """Quick registration page"""
    return send_file('quick_register.html')

@app.route('/check-users')
def check_users():
    """Check existing users page"""
    return send_file('check_users.html')

@app.route('/check-username', methods=['POST'])
def check_username():
    """Check if username is available"""
    try:
        # Try to get JSON data, fallback to form data
        if request.is_json:
            data = request.get_json()
        else:
            data = request.form.to_dict()
        
        username = data.get('username', '')
        
        if not username:
            return jsonify({'available': False, 'message': 'Username is required'}), 400
        
        user = User.query.filter_by(username=username).first()
        available = user is None
        
        return jsonify({
            'available': available,
            'message': 'Available' if available else 'Username already exists'
        })
    except Exception as e:
        print(f"Error checking username: {e}")
        return jsonify({'available': False, 'message': str(e)}), 500

@app.route('/check-email', methods=['POST'])
def check_email():
    """Check if email is available"""
    try:
        # Try to get JSON data, fallback to form data
        if request.is_json:
            data = request.get_json()
        else:
            data = request.form.to_dict()
        
        email = data.get('email', '')
        
        if not email:
            return jsonify({'available': False, 'message': 'Email is required'}), 400
        
        user = User.query.filter_by(email=email).first()
        available = user is None
        
        return jsonify({
            'available': available,
            'message': 'Available' if available else 'Email already registered'
        })
    except Exception as e:
        print(f"Error checking email: {e}")
        return jsonify({'available': False, 'message': str(e)}), 500

@app.route('/test-register-bypass')
def test_register_bypass():
    """Registration test with bypass option"""
    return send_file('test_register_bypass.html')

@app.route('/test-password-regex')
def test_password_regex():
    """Password regex test page"""
    return send_file('test_password_regex.html')

@app.route('/test-register', methods=['POST'])
def test_register():
    """Simple test endpoint to isolate registration issues"""
    try:
        data = request.get_json()
        print("Test register received:", data)
        return jsonify({"status": "success", "message": "Test successful"})
    except Exception as e:
        print(f"Test register error: {e}")
        return jsonify({"status": "error", "message": str(e)}), 500

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        print("Registration POST request received")
        
        # Get and sanitize form data
        username = sanitize_input(request.form.get('username', ''))
        email = sanitize_input(request.form.get('email', ''))
        password = request.form.get('password', '')
        
        print(f"Username: {username}, Email: {email}")
        
        # Rate limiting check
        if not rate_limit_check(None, 'register', 5, 3600):
            log_security_event('register_rate_limit', details={'ip': request.remote_addr})
            flash('Too many registration attempts. Please try again later.', 'error')
            return render_template('register.html')
        
        # Input validation
        if not username or not email or not password:
            flash('All fields are required', 'error')
            log_security_event('register_missing_fields', details={'username': username, 'email': email})
            return render_template('register.html')
        
        # Validate username format
        if not validate_username(username):
            flash('Username must be 3-20 characters and contain only letters, numbers, underscores, and hyphens', 'error')
            log_security_event('register_invalid_username', details={'username': username})
            return render_template('register.html')
        
        # Validate email format
        if not validate_email(email):
            flash('Please enter a valid email address', 'error')
            log_security_event('register_invalid_email', details={'email': email})
            return render_template('register.html')
        
        # Validate password strength
        is_valid, password_message = validate_password_strength(password)
        if not is_valid:
            flash(password_message, 'error')
            log_security_event('register_weak_password', details={'username': username})
            return render_template('register.html')
        
        # Check if username already exists
        if User.query.filter_by(username=username).first():
            flash('Username already exists', 'error')
            log_security_event('register_username_exists', details={'username': username})
            return render_template('register.html')
        
        # Check if email already registered
        if User.query.filter_by(email=email).first():
            flash('Email already registered', 'error')
            log_security_event('register_email_exists', details={'email': email})
            return render_template('register.html')
        
        try:
            # Create new user
            user = User(username=username, email=email)
            user.set_password(password)
            db.session.add(user)
            db.session.commit()
            
            log_security_event('register_success', user_id=user.id, details={'username': username, 'email': email})
            print(f"User {username} created successfully")
            flash('Registration successful! Please log in.', 'success')
            return redirect(url_for('login'))
            
        except Exception as e:
            print(f"Error creating user: {e}")
            log_security_event('register_error', details={'username': username, 'error': str(e)})
            db.session.rollback()
            flash('Registration failed. Please try again.', 'error')
            return render_template('register.html')
    
    return render_template('register.html')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('index'))

@app.route('/dashboard')
@login_required
def dashboard():
    if current_user.is_admin:
        return redirect(url_for('admin_dashboard'))
    return render_template('dashboard.html')

@app.route('/predict', methods=['POST'])
@login_required
@performance_monitor
def predict():
    try:
        print("=== PREDICTION REQUEST RECEIVED ===")
        print(f"Form data: {dict(request.form)}")
        print(f"User authenticated: {current_user.username if current_user else 'None'}")
        
        email_content = sanitize_input(request.form.get('email_content', ''))
        model_name = sanitize_input(request.form.get('model', 'rule_based'))
        
        print(f"Sanitized email_content: '{email_content}'")
        print(f"Sanitized model_name: '{model_name}'")
        print(f"Email content length: {len(email_content) if email_content else 0}")
        
        if not email_content:
            print("ERROR: Email content is empty")
            return jsonify({'error': 'Email content is required'}), 400
        
        # Rate limiting check
        if not rate_limit_check(current_user.id, 'predict', 100, 3600):
            print("ERROR: Rate limit exceeded")
            log_security_event('predict_rate_limit', user_id=current_user.id, details={'model': model_name})
            return jsonify({'error': 'Too many prediction requests. Please try again later.'}), 429
        
        # Validate email content length
        if len(email_content) > 10000:  # 10KB limit
            print(f"ERROR: Email content too long ({len(email_content)} chars)")
            return jsonify({'error': 'Email content too long (max 10KB)'}), 400
        
        print("Validation passed, proceeding with prediction")
        
        result = classifier.predict(email_content)
        print(f"Prediction result: {result}")
        
        # Extract values from result
        prediction = result['prediction']
        confidence = result['confidence']
        risk_level = result['risk_level']
        
        print(f"Extracted: prediction={prediction}, confidence={confidence}, risk_level={risk_level}")
        
        # Handle invalid input
        if prediction == 'invalid':
            return jsonify({
                'error': result.get('reason', 'Invalid input'),
                'prediction': 'invalid',
                'reason': result.get('reason', 'Invalid input')
            }), 400
        
        # Save prediction to database
        prediction_record = Prediction(
            user_id=current_user.id,
            email_content=email_content,
            prediction=prediction,
            confidence_score=confidence / 100,  # Convert percentage to decimal
            risk_level=risk_level,
            model_used=model_name
        )
        db.session.add(prediction_record)
        db.session.commit()
        
        log_security_event('predict_success', user_id=current_user.id, details={
            'prediction': prediction,
            'confidence': confidence,
            'risk_level': risk_level,
            'model': model_name
        })
        
        print("=== PREDICTION SUCCESS ===")
        
        response_data = {
            'prediction': prediction,
            'confidence': confidence,
            'risk_level': risk_level,
            'model_used': model_name
        }
        
        # Add reason if available
        if 'reason' in result:
            response_data['reason'] = result['reason']
        
        print(f"Returning JSON response: {response_data}")
        return jsonify(response_data)
        
    except Exception as e:
        print(f"ERROR: Prediction failed: {e}")
        import traceback
        traceback.print_exc()
        log_security_event('predict_error', user_id=current_user.id if current_user else None, details={'error': str(e)})
        db.session.rollback()
        return jsonify({'error': 'Prediction failed. Please try again.'}), 500

# Create API version of predict endpoint
@app.route('/api/predict', methods=['POST'])
@csrf.exempt  # Exempt from CSRF protection
@login_required
@performance_monitor
def api_predict():
    """API version of predict endpoint for external access"""
    try:
        # Handle JSON request
        if request.is_json:
            data = request.get_json()
            email_content = sanitize_input(data.get('email_content', ''))
            model_name = sanitize_input(data.get('model', 'rule_based'))
        else:
            email_content = sanitize_input(request.form.get('email_content', ''))
            model_name = sanitize_input(request.form.get('model', 'rule_based'))
        
        # LIGHTWEIGHT VALIDATION - Only check for empty content
        if not email_content or email_content.strip() == "":
            return jsonify({'error': 'Email content cannot be empty'}), 400
        
        # Rate limiting check
        if not rate_limit_check(current_user.id, 'predict', 100, 3600):
            return jsonify({'error': 'Too many prediction requests. Please try again later.'}), 429
        
        # Validate email content length (reasonable limit)
        if len(email_content) > 10000:
            return jsonify({'error': 'Email content too long (max 10KB)'}), 400
        
        # PREDICTION PIPELINE - Always run for non-empty input
        try:
            result = classifier.predict(email_content)
        except Exception as predict_error:
            print(f"Prediction error: {predict_error}")
            # Fallback to simple rule-based detection
            result = fallback_predict(email_content)
        
        # Extract values from result
        prediction = result.get('prediction', 'ham')
        confidence = result.get('confidence', 0.5)
        risk_level = result.get('risk_level', 'low')
        
        # NEVER return invalid for prediction - always classify
        if prediction == 'invalid':
            # Convert invalid to ham with low confidence
            prediction = 'ham'
            confidence = 0.3
            risk_level = 'low'
        
        # ENSURE PROPER LABEL MAPPING
        if prediction == 'spam':
            display_prediction = 'Spam'
        else:
            display_prediction = 'Not Spam'
        
        # Calculate confidence percentage
        confidence_percentage = round(confidence * 100, 1) if confidence <= 1 else round(confidence, 1)
        
        # Determine risk level display
        if risk_level == 'high':
            display_risk = 'High'
        elif risk_level == 'medium':
            display_risk = 'Medium'
        else:
            display_risk = 'Low'
        
        # Extract keywords
        keywords = extract_spam_keywords(email_content)
        
        # Determine reason
        if prediction == 'spam':
            if keywords:
                reason = f"Suspicious promotional keywords detected: {', '.join(keywords[:3])}"
            else:
                reason = "Suspicious patterns detected in email content"
        else:
            reason = "Email appears to be legitimate"
        
        # Save prediction to database
        prediction_record = Prediction(
            user_id=current_user.id,
            email_content=email_content,
            prediction=prediction,
            confidence_score=confidence_percentage / 100,  # Convert percentage to decimal
            risk_level=risk_level,
            model_used=model_name
        )
        db.session.add(prediction_record)
        db.session.commit()
        
        # RETURN PROPER JSON RESPONSE
        return jsonify({
            'prediction': display_prediction,
            'confidence': f"{confidence_percentage}%",
            'risk_level': display_risk,
            'reason': reason,
            'keywords': keywords,
            'model_used': model_name
        })
        
    except Exception as e:
        print(f"API Prediction error: {e}")
        db.session.rollback()
        return jsonify({'error': 'Prediction failed. Please try again.'}), 500

def fallback_predict(text):
    """Fallback prediction when main classifier fails"""
    text_lower = text.lower()
    spam_keywords = ['free', 'win', 'prize', 'money', 'cash', 'urgent', 'limited', 'offer', 
                    'click', 'buy', 'now', 'guaranteed', 'risk', 'congratulations', 'lottery']
    
    found_keywords = [kw for kw in spam_keywords if kw in text_lower]
    spam_score = len(found_keywords) * 0.15
    
    # Check for random patterns
    if re.search(r'[a-zA-Z0-9]{8,}', text):
        spam_score += 0.3
    
    if spam_score > 0.3:
        return {
            'prediction': 'spam',
            'confidence': min(spam_score + 0.4, 0.9),
            'risk_level': 'high' if spam_score > 0.6 else 'medium'
        }
    else:
        return {
            'prediction': 'ham',
            'confidence': max(0.7 - spam_score, 0.5),
            'risk_level': 'low'
        }

def extract_spam_keywords(text):
    """Extract spam keywords from text"""
    spam_keywords = ['free', 'win', 'prize', 'money', 'cash', 'urgent', 'limited', 'offer', 
                    'click', 'buy', 'now', 'guaranteed', 'risk', 'congratulations', 'lottery',
                    'winner', 'claim', 'viagra', 'cialis', 'iphone', 'discount']
    
    text_lower = text.lower()
    found_keywords = [kw for kw in spam_keywords if kw in text_lower]
    return found_keywords[:10]  # Limit to 10 keywords

@app.route('/history')
@login_required
def history():
    predictions = Prediction.query.filter_by(user_id=current_user.id).order_by(Prediction.created_at.desc()).limit(50).all()
    return render_template('history.html', predictions=predictions)

@app.route('/admin')
@login_required
@performance_monitor
def admin_dashboard():
    if not current_user.is_admin:
        return redirect(url_for('dashboard'))
    
    # Try to get cached stats first
    cache_key = 'admin_stats'
    stats = get_cached_data(cache_key, cache_duration=60)  # Cache for 1 minute
    
    if not stats:
        stats = get_admin_stats_optimized()
        set_cached_data(cache_key, stats)
    
    recent_predictions = get_user_predictions_optimized(None, limit=10)  # Get all recent predictions
    users = User.query.all()
    
    return render_template('admin/dashboard.html', 
                         total_users=stats['total_users'],
                         total_predictions=stats['total_predictions'],
                         spam_predictions=stats['spam_predictions'],
                         ham_predictions=stats['ham_predictions'],
                         recent_predictions=recent_predictions,
                         users=users)

@app.route('/admin/train_model', methods=['POST'])
@login_required
def train_model():
    if not current_user.is_admin:
        return jsonify({'error': 'Unauthorized'}), 403
    
    # For this simple version, we'll just return success
    return jsonify({'message': 'Rule-based model is always ready!'})

@app.route('/admin/toggle_user/<int:user_id>', methods=['POST'])
@login_required
def toggle_user_status(user_id):
    if not current_user.is_admin:
        return jsonify({'error': 'Unauthorized'}), 403
    
    user = User.query.get_or_404(user_id)
    if user.id == current_user.id:
        return jsonify({'error': 'Cannot deactivate your own account'}), 400
    
    user.is_active = not user.is_active
    db.session.commit()
    
    return jsonify({
        'message': f'User {"activated" if user.is_active else "deactivated"} successfully',
        'is_active': user.is_active
    })

@app.route('/admin/delete_user/<int:user_id>', methods=['DELETE'])
@login_required
def delete_user(user_id):
    if not current_user.is_admin:
        return jsonify({'error': 'Unauthorized'}), 403
    
    user = User.query.get_or_404(user_id)
    if user.id == current_user.id:
        return jsonify({'error': 'Cannot delete your own account'}), 400
    
    # Delete user's predictions first
    Prediction.query.filter_by(user_id=user_id).delete()
    db.session.delete(user)
    db.session.commit()
    
    return jsonify({'message': 'User deleted successfully'})

@app.route('/admin/add_user', methods=['POST'])
@login_required
def add_user():
    if not current_user.is_admin:
        return jsonify({'error': 'Unauthorized'}), 403
    
    data = request.get_json()
    username = data.get('username')
    email = data.get('email')
    password = data.get('password')
    is_admin = data.get('is_admin', False)
    
    if not username or not email or not password:
        return jsonify({'error': 'All fields are required'}), 400
    
    # Check if user already exists
    if User.query.filter_by(username=username).first():
        return jsonify({'error': 'Username already exists'}), 400
    
    if User.query.filter_by(email=email).first():
        return jsonify({'error': 'Email already registered'}), 400
    
    # Create new user
    user = User(username=username, email=email, is_admin=is_admin)
    user.set_password(password)
    db.session.add(user)
    db.session.commit()
    
    return jsonify({
        'message': 'User created successfully',
        'user': {
            'id': user.id,
            'username': user.username,
            'email': user.email,
            'is_admin': user.is_admin,
            'is_active': user.is_active
        }
    })

@app.route('/api/stats')
@login_required
def api_stats():
    """Get user statistics for dashboard"""
    try:
        # Get user-specific stats
        user_predictions = Prediction.query.filter_by(user_id=current_user.id).all()
        total_user_predictions = len(user_predictions)
        user_spam_predictions = len([p for p in user_predictions if p.prediction == 'spam'])
        user_ham_predictions = len([p for p in user_predictions if p.prediction == 'ham'])
        
        # Get global stats
        global_stats = get_database_stats()
        
        return jsonify({
            'user_stats': {
                'total_predictions': total_user_predictions,
                'spam_predictions': user_spam_predictions,
                'ham_predictions': user_ham_predictions,
                'spam_percentage': round((user_spam_predictions / total_user_predictions * 100) if total_user_predictions > 0 else 0, 1)
            },
            'global_stats': global_stats
        })
    except Exception as e:
        print(f"Error getting user stats: {e}")
        return jsonify({'error': 'Failed to get statistics'}), 500

@app.route('/admin/stats')
@login_required
def admin_stats():
    if not current_user.is_admin:
        return jsonify({'error': 'Unauthorized'}), 403
    
    total_users = User.query.count()
    active_users = User.query.filter_by(is_active=True).count()
    admin_users = User.query.filter_by(is_admin=True).count()
    total_predictions = Prediction.query.count()
    spam_predictions = Prediction.query.filter_by(prediction='spam').count()
    ham_predictions = Prediction.query.filter_by(prediction='ham').count()
    
    # Get recent predictions
    recent_predictions = Prediction.query.order_by(Prediction.created_at.desc()).limit(10).all()
    recent_data = []
    for pred in recent_predictions:
        recent_data.append({
            'id': pred.id,
            'user': pred.user.username if pred.user else 'Unknown',
            'prediction': pred.prediction,
            'confidence': pred.confidence_score,
            'risk_level': pred.risk_level,
            'created_at': pred.created_at.strftime('%Y-%m-%d %H:%M:%S')
        })
    
    return jsonify({
        'total_users': total_users,
        'active_users': active_users,
        'admin_users': admin_users,
        'total_predictions': total_predictions,
        'spam_predictions': spam_predictions,
        'ham_predictions': ham_predictions,
        'recent_predictions': recent_data
    })

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    app.run(debug=True)
