#!/usr/bin/env python3

import sys
import os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from app import rule_based_detection

# Test the rule-based detection directly
test_cases = [
    "asdfghjklqwerty",
    "xyz123abc456", 
    "hi",
    "qwerty",
    "randomtext123",
    "Hello, this is a legitimate email",
    "FREE MONEY NOW WIN PRIZE"
]

print("Testing rule-based detection directly...")
print("=" * 50)

for test_text in test_cases:
    prediction, confidence, risk_level, keywords = rule_based_detection(test_text)
    
    print(f"\nInput: '{test_text}'")
    print(f"Prediction: {prediction}")
    print(f"Confidence: {confidence:.2f}")
    print(f"Risk Level: {risk_level}")
    print(f"Keywords: {keywords}")
    print("-" * 40)
