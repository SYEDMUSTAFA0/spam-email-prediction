#!/usr/bin/env python
"""
Test authenticated stats API
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from app_simple import app, db, User, Prediction, classifier

def test_authenticated_stats():
    print("🔧 TESTING AUTHENTICATED STATS API")
    print("=" * 50)
    
    with app.test_client() as client:
        # First login
        login_page = client.get('/login')
        
        # Extract CSRF token
        import re
        csrf_match = re.search(b'name="csrf_token" type="hidden" value="([^"]*)"', login_page.data)
        csrf_token = csrf_match.group(1).decode('utf-8') if csrf_match else None
        
        # Login with admin
        login_data = {
            'username': 'admin',
            'password': 'admin123',
            'csrf_token': csrf_token
        }
        
        login_response = client.post('/login', data=login_data, follow_redirects=False)
        print(f"Login status: {login_response.status_code}")
        
        # Extract session cookie
        session_cookie = None
        for cookie in login_response.headers.getlist('Set-Cookie'):
            if 'session=' in cookie:
                session_cookie = cookie.split(';')[0]
                break
        
        if session_cookie:
            print("✅ Login successful, got session cookie")
            
            # Test stats API with authentication
            headers = {'Cookie': session_cookie}
            stats_response = client.get('/api/stats', headers=headers)
            print(f"Stats API status: {stats_response.status_code}")
            
            if stats_response.status_code == 200:
                data = stats_response.get_json()
                print("✅ Stats API working!")
                print(f"  User stats: {data.get('user_stats', {})}")
                print(f"  Global stats: {data.get('global_stats', {})}")
                
                # Test a prediction
                prediction_response = client.post('/api/predict', 
                    json={
                        'email_content': 'ACT NOW! GUARANTEED CASH REWARD!!!',
                        'model': 'rule_based'
                    },
                    headers=headers
                )
                print(f"Prediction API status: {prediction_response.status_code}")
                
                if prediction_response.status_code == 200:
                    result = prediction_response.get_json()
                    print("✅ Prediction API working!")
                    print(f"  Prediction: {result.get('prediction')}")
                    print(f"  Confidence: {result.get('confidence')}")
                    
                    # Test stats again to see if count increased
                    stats_response2 = client.get('/api/stats', headers=headers)
                    if stats_response2.status_code == 200:
                        data2 = stats_response2.get_json()
                        print("✅ Stats updated after prediction!")
                        print(f"  New user stats: {data2.get('user_stats', {})}")
                else:
                    print("❌ Prediction API failed")
            else:
                print("❌ Stats API failed")
                print(f"  Response: {stats_response.data[:200]}")
        else:
            print("❌ Login failed, no session cookie")
    
    print("\n🎯 AUTHENTICATED STATS TEST COMPLETED!")

if __name__ == "__main__":
    test_authenticated_stats()
