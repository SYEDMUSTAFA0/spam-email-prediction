#!/usr/bin/env python
"""
Test frontend submission fix
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from app_simple import app

def test_frontend_fix():
    print("🔧 TESTING FRONTEND SUBMISSION FIX")
    print("=" * 50)
    
    with app.test_client() as client:
        # Login
        login_page = client.get('/login')
        import re
        page_content = login_page.data.decode('utf-8')
        
        # Try multiple patterns for CSRF token
        patterns = [
            r'name="csrf_token" type="hidden" value="([^"]+)"',
            r'value="([^"]{40,})"',  # Long tokens are usually CSRF
            r'csrf_token.*?value="([^"]+)"'
        ]
        
        csrf_token = None
        for pattern in patterns:
            match = re.search(pattern, page_content)
            if match:
                csrf_token = match.group(1)
                break
        
        if not csrf_token:
            print("❌ No CSRF token")
            return
        
        login_data = {
            'username': 'admin',
            'password': 'admin123',
            'csrf_token': csrf_token
        }
        
        login_response = client.post('/login', data=login_data, follow_redirects=False)
        
        session_cookie = None
        for cookie in login_response.headers.getlist('Set-Cookie'):
            if 'session=' in cookie:
                session_cookie = cookie.split(';')[0]
                break
        
        if not session_cookie:
            print("❌ No session cookie")
            return
        
        headers = {'Cookie': session_cookie}
        print("✅ Login successful")
        
        # Test common email submissions that would fail before
        test_cases = [
            ("Hello team", "ham", "Short business greeting"),
            ("Hi there", "ham", "Casual greeting"),
            ("Test message", "ham", "Simple test"),
            ("Free offer", "spam", "Short spam"),
            ("Meeting at 10am", "ham", "Brief meeting"),
            ("Call me", "ham", "Very brief request"),
            ("Thanks!", "ham", "Brief thanks"),
            ("Click now", "spam", "Urgent spam"),
        ]
        
        correct_predictions = 0
        total_predictions = len(test_cases)
        
        for i, (text, expected, description) in enumerate(test_cases, 1):
            print(f"\n{i}. {description}")
            print(f"   Text: '{text}'")
            print(f"   Expected: {expected}")
            
            try:
                response = client.post('/api/predict', 
                    json={
                        'email_content': text,
                        'model': 'rule_based'
                    },
                    headers=headers
                )
                
                print(f"   Status: {response.status_code}")
                
                if response.status_code == 200:
                    result = response.get_json()
                    prediction = result.get('prediction')
                    confidence = result.get('confidence')
                    
                    print(f"   Prediction: {prediction}")
                    print(f"   Confidence: {confidence}%")
                    
                    if prediction == expected:
                        correct_predictions += 1
                        print(f"   Result: ✅ CORRECT")
                    else:
                        print(f"   Result: ❌ WRONG")
                        
                elif response.status_code == 400:
                    result = response.get_json()
                    prediction = result.get('prediction')
                    error_msg = result.get('error')
                    
                    print(f"   Prediction: {prediction}")
                    print(f"   Error: {error_msg}")
                    
                    if prediction == expected:
                        correct_predictions += 1
                        print(f"   Result: ✅ CORRECT (Invalid as expected)")
                    else:
                        print(f"   Result: ❌ WRONG")
                else:
                    print(f"   ❌ Error: {response.data[:100]}")
                    
            except Exception as e:
                print(f"   ❌ Exception: {e}")
            
            print("-" * 40)
        
        # Calculate accuracy
        accuracy = (correct_predictions / total_predictions) * 100
        print(f"\n📊 FRONTEND SUBMISSION RESULTS:")
        print(f"   Correct: {correct_predictions}/{total_predictions}")
        print(f"   Accuracy: {accuracy:.1f}%")
        
        print(f"\n🎯 FRONTEND STATUS: {'✅ WORKING PERFECTLY!' if accuracy >= 90 else '❌ NEEDS IMPROVEMENT'}")
        
        if accuracy >= 90:
            print(f"\n✅ FRONTEND SUBMISSION ISSUE FIXED!")
            print(f"   ✅ Short emails now work")
            print(f"   ✅ Brief messages accepted")
            print(f"   ✅ Validation less strict")
            print(f"   ✅ User experience improved")

if __name__ == "__main__":
    test_frontend_fix()
