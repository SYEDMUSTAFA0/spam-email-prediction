#!/usr/bin/env python
"""
Debug step by step
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from app_simple import SimpleSpamClassifier

def debug_step():
    print("🔧 STEP BY STEP DEBUG")
    print("=" * 50)
    
    classifier = SimpleSpamClassifier()
    
    # Test the exact problematic message
    message = "ACT NOW! GUARANTEED CASH REWARD!!!"
    
    print(f"Original message: {message}")
    
    # Step 1: Test preprocessing
    processed = classifier.preprocess_text(message)
    print(f"Processed: '{processed}'")
    
    # Step 2: Test individual indicators
    text_lower = message.lower()
    print(f"Text lower: '{text_lower}'")
    
    # Check if multi-word indicators are found
    found_act_now = 'act now' in text_lower
    found_guaranteed = 'guaranteed' in text_lower
    found_cash = 'cash' in text_lower
    found_reward = 'reward' in text_lower
    
    print(f"Found 'act now': {found_act_now}")
    print(f"Found 'guaranteed': {found_guaranteed}")
    print(f"Found 'cash': {found_cash}")
    print(f"Found 'reward': {found_reward}")
    
    # Step 3: Test scoring
    spam_score = classifier.calculate_spam_score(message)
    print(f"Spam score: {spam_score}")
    
    # Step 4: Test prediction
    prediction, confidence, risk = classifier.predict(message, 'rule_based')
    print(f"Prediction: {prediction}")
    print(f"Confidence: {confidence}")
    print(f"Risk: {risk}")

if __name__ == "__main__":
    debug_step()
