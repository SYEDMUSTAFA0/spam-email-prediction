#!/usr/bin/env python
"""
Test specific spam cases that were failing
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from app_simple import EnhancedSpamDetector

def test_specific_spam_cases():
    print("🔧 TESTING SPECIFIC SPAM CASES")
    print("=" * 50)
    
    detector = EnhancedSpamDetector()
    
    # Test the specific cases that were failing
    test_cases = [
        ("Last chance to get 50% off", "spam", "Should be spam - urgency + discount"),
        ("Lose weight quick guaranteed results", "spam", "Should be spam - weight loss promise"),
        ("Don't miss this opportunity buy now", "spam", "Should be spam - urgency + opportunity"),
        ("Make money fast from home guaranteed", "spam", "Should be spam - money making promise"),
        ("Credit card debt relief act now", "spam", "Should be spam - financial + urgency"),
        ("Investment opportunity high returns guaranteed", "spam", "Should be spam - investment + guarantee"),
    ]
    
    correct_predictions = 0
    total_predictions = len(test_cases)
    
    for i, (text, expected, description) in enumerate(test_cases, 1):
        print(f"\n{i}. {description}")
        print(f"   Text: {text}")
        print(f"   Expected: {expected}")
        
        try:
            result = detector.predict(text)
            
            print(f"   Prediction: {result['prediction']}")
            print(f"   Confidence: {result['confidence']}%")
            print(f"   Risk Level: {result['risk_level']}")
            
            if 'reason' in result:
                print(f"   Reason: {result['reason']}")
            
            if 'spam_patterns' in result:
                patterns = result['spam_patterns']
                spam_score = result.get('pattern_score', 0)
                print(f"   Pattern Score: {spam_score}")
                print(f"   Patterns: {len(patterns)} found")
                for pattern in patterns:
                    if pattern['count'] > 0:
                        print(f"     - {pattern['type']}: {pattern['count']} matches")
            
            if result['prediction'] == expected:
                correct_predictions += 1
                print(f"   Result: ✅ CORRECT")
            else:
                print(f"   Result: ❌ WRONG (Should be {expected})")
                
        except Exception as e:
            print(f"   ❌ Error: {e}")
        
        print("-" * 40)
    
    # Calculate accuracy
    accuracy = (correct_predictions / total_predictions) * 100
    print(f"\n📊 SPECIFIC SPAM TEST RESULTS:")
    print(f"   Correct: {correct_predictions}/{total_predictions}")
    print(f"   Accuracy: {accuracy:.1f}%")
    
    if accuracy >= 80:
        print(f"\n🎯 SPAM DETECTION ENHANCEMENT: ✅ SUCCESSFUL!")
        print(f"   ✅ Most spam patterns now detected correctly")
        print(f"   ✅ Spam combinations working")
        print(f"   ✅ Financial spam detection working")
        print(f"   ✅ Urgency spam detection working")
    else:
        print(f"\n❌ SPAM DETECTION NEEDS MORE WORK")
        print(f"   Accuracy too low: {accuracy:.1f}%")
        print(f"   Need to enhance spam detection further")

if __name__ == "__main__":
    test_specific_spam_cases()
