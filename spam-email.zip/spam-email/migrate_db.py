#!/usr/bin/env python3
"""
Database Migration Script
Adds missing columns to the existing database
"""

import sqlite3
import os

def migrate_database():
    """Migrate the database to add missing columns"""
    db_path = 'instance/spam_email.db'
    
    if not os.path.exists(db_path):
        print("❌ Database file not found")
        return False
    
    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        # Check current schema
        cursor.execute("PRAGMA table_info(prediction)")
        columns = [row[1] for row in cursor.fetchall()]
        
        print("📊 Current prediction table columns:")
        for col in columns:
            print(f"   - {col}")
        
        # Add missing columns if they don't exist
        missing_columns = {
            'spam_probability': 'REAL',
            'keywords_found': 'TEXT',
            'processing_time': 'REAL'
        }
        
        for col_name, col_type in missing_columns.items():
            if col_name not in columns:
                print(f"➕ Adding column: {col_name} ({col_type})")
                cursor.execute(f"ALTER TABLE prediction ADD COLUMN {col_name} {col_type}")
            else:
                print(f"✅ Column already exists: {col_name}")
        
        # Check if model_used column exists
        if 'model_used' not in columns:
            print("➕ Adding column: model_used (TEXT)")
            cursor.execute("ALTER TABLE prediction ADD COLUMN model_used TEXT")
        else:
            print("✅ Column already exists: model_used")
        
        conn.commit()
        conn.close()
        
        print("✅ Database migration completed successfully!")
        return True
        
    except Exception as e:
        print(f"❌ Migration error: {e}")
        return False

if __name__ == "__main__":
    migrate_database()
