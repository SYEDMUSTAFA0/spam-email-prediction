#!/usr/bin/env python
"""
Run script for SpamGuard AI Application
"""

import os
from app import app, db, User, SpamDataset, classifier

def create_admin_user():
    """Create default admin user if not exists"""
    admin = User.query.filter_by(username='admin').first()
    if not admin:
        admin = User(
            username='admin',
            email='admin@spamguard.ai',
            is_admin=True,
            is_active=True
        )
        admin.set_password('admin123')
        db.session.add(admin)
        db.session.commit()
        print("✅ Default admin user created (username: admin, password: admin123)")

def main():
    """Main function to run the application"""
    with app.app_context():
        # Create database tables
        db.create_all()
        print("✅ Database tables created")
        
        # Create admin user
        create_admin_user()
        
        # Train ML models if not exists
        if not classifier.models:
            print("🤖 Training ML models...")
            success = classifier.train_models()
            if success:
                print("✅ ML models trained successfully")
            else:
                print("❌ Failed to train models")
        else:
            print("✅ ML models loaded from disk")
    
    print("\n🚀 Starting SpamGuard AI Application...")
    print("📍 Application will be available at: http://localhost:5000")
    print("👤 Default admin login: admin / admin123")
    print("\n🔧 Press Ctrl+C to stop the server\n")
    
    # Run the application
    app.run(
        host='0.0.0.0',
        port=5000,
        debug=app.config.get('FLASK_DEBUG', True)
    )

if __name__ == '__main__':
    main()
