#!/usr/bin/env python
"""
Quick test of spam classifier improvements
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from app_simple import SimpleSpamClassifier

def test_spam_fix():
    print("🔧 TESTING SPAM CLASSIFIER FIX")
    print("=" * 50)
    
    classifier = SimpleSpamClassifier()
    
    # Test the problematic messages
    test_cases = [
        ("ACT NOW! GUARANTEED CASH REWARD!!!", "Should be SPAM"),
        ("CLICK HERE FOR EXCLUSIVE DEAL!!!", "Should be SPAM"),
        ("LIMITED TIME OFFER! Buy now and get 50% discount!", "Should be SPAM"),
        ("URGENT! You have won a FREE prize! Click now to claim your money!", "Should be SPAM"),
        ("Hi team, please review the attached report for our upcoming meeting.", "Should be HAM"),
    ]
    
    for i, (message, expected) in enumerate(test_cases, 1):
        print(f"\n{i}. Testing: {message[:40]}...")
        
        # Test raw scoring
        spam_score = classifier.calculate_spam_score(message)
        print(f"   Raw spam score: {spam_score}")
        
        # Test prediction
        prediction, confidence, risk_level = classifier.predict(message, 'rule_based')
        print(f"   Prediction: {prediction}")
        expected_prediction = "spam" if "SPAM" in expected else "ham"
        print(f"   Expected: {expected_prediction}")
        print(f"   Result: {'✅ CORRECT' if prediction == expected_prediction else '❌ WRONG'}")
        print("-" * 40)
    
    print("\n🎯 SPAM CLASSIFIER TEST COMPLETED!")

if __name__ == "__main__":
    test_spam_fix()
