#!/usr/bin/env python3

import requests
import json

# Test edge cases that might be causing issues
test_cases = [
    "1",  # Single character
    "12",  # Two characters  
    "123",  # Three characters
    "a",  # Single letter
    "test",  # Short word
    "hello",  # Common word
    "Hello world",  # Simple phrase
    "Hello, this is a test email.",  # Simple email
    "Dear Sir, I am writing to inquire about your services. Please let me know if you can help.",  # Formal email
    "asdf",  # Random letters
    "xyz123",  # Mixed
]

print("Testing edge cases...")
print("=" * 60)

for test_text in test_cases:
    try:
        response = requests.post(
            'http://127.0.0.1:5000/api/predict_public',
            json={
                'email_content': test_text,
                'model': 'ensemble'
            },
            headers={
                'Content-Type': 'application/json'
            }
        )
        
        if response.status_code == 200:
            result = response.json()
            print(f"Input: '{test_text}' → {result.get('prediction', 'N/A')} ({result.get('confidence', 'N/A')}%)")
        else:
            print(f"Input: '{test_text}' - ERROR: {response.status_code}")
            
    except Exception as e:
        print(f"Input: '{test_text}' - ERROR: {e}")
