#!/usr/bin/env python
"""
Run script for SpamGuard AI Application (Simple Version)
"""

import os
from app_simple import app, db, User, SpamDataset, classifier, init_database, get_database_stats

def main():
    """Main function to run application"""
    print("🔧 Initializing SpamGuard AI Application...")
    
    # Initialize database
    init_database()
    
    # Get database statistics
    stats = get_database_stats()
    if stats:
        print(f"📊 Database Statistics:")
        print(f"   - Total Users: {stats['total_users']}")
        print(f"   - Active Users: {stats['active_users']}")
        print(f"   - Admin Users: {stats['admin_users']}")
        print(f"   - Total Predictions: {stats['total_predictions']}")
        print(f"   - Spam Predictions: {stats['spam_predictions']}")
        print(f"   - Ham Predictions: {stats['ham_predictions']}")
        print(f"   - Dataset Size: {stats['dataset_size']}")
    
    print("✅ Rule-based spam classifier initialized")
    
    print("\n🚀 Starting SpamGuard AI Application...")
    print("📍 Application will be available at: http://localhost:5000")
    print("👤 Default admin login: admin / admin123")
    print("🔧 Using rule-based spam detection (no ML dependencies required)")
    print("\n🔧 Press Ctrl+C to stop the server\n")
    
    # Run application
    app.run(
        host='0.0.0.0',
        port=5000,
        debug=app.config.get('FLASK_DEBUG', True)
    )

if __name__ == '__main__':
    main()
