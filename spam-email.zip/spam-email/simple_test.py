#!/usr/bin/env python3
"""
Simple API test
"""

import requests
import json

def simple_test():
    try:
        # Test health endpoint
        response = requests.get("http://localhost:5000/api/health", timeout=5)
        print(f"Health endpoint status: {response.status_code}")
        print(f"Response text: {response.text[:200]}")
        
        if response.status_code == 200:
            print("Health check passed!")
            
            # Test prediction endpoint
            response = requests.post(
                "http://localhost:5000/api/predict",
                json={"email_text": "test message"},
                headers={"Content-Type": "application/json"},
                timeout=5
            )
            print(f"\nPrediction endpoint status: {response.status_code}")
            print(f"Response text: {response.text[:500]}")
            
    except Exception as e:
        print(f"Error: {e}")

if __name__ == "__main__":
    simple_test()
