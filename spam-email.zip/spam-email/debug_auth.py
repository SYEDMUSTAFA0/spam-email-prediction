#!/usr/bin/env python
"""
Debug authentication and prediction flow
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from app_simple import app, db, User, login_manager
from flask import request, session

def debug_auth():
    print("🔧 Debugging authentication...")
    
    with app.app_context():
        # Check if admin user exists
        admin_user = User.query.filter_by(username='admin').first()
        if admin_user:
            print(f"✅ Admin user found: {admin_user.username}")
            print(f"   ID: {admin_user.id}")
            print(f"   Email: {admin_user.email}")
            print(f"   Is admin: {admin_user.is_admin}")
            print(f"   Is active: {admin_user.is_active}")
        else:
            print("❌ Admin user not found")
            return
        
        # Check total users
        users = User.query.all()
        print(f"📊 Total users: {len(users)}")
        for user in users:
            print(f"   - {user.username} ({user.email})")
        
        print("🔧 Authentication debug completed!")

if __name__ == "__main__":
    debug_auth()
