#!/usr/bin/env python
"""
Debug prediction errors in the enhanced system
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from app_simple import app, EnhancedSpamDetector

def debug_prediction_error():
    print("🔧 DEBUGGING PREDICTION ERRORS")
    print("=" * 50)
    
    # Test the enhanced detector directly
    detector = EnhancedSpamDetector()
    
    test_cases = [
        "Congratulations! You won a free iPhone",
        "Meeting scheduled tomorrow at 10am",
        "jevdwhucwqhjbeflj3beoiu18u0398098",
        "902y3109r1v ohf kno13hub2-018739-219ep# D\\"
    ]
    
    for i, text in enumerate(test_cases, 1):
        print(f"\n{i}. Testing: {text[:50]}...")
        
        try:
            result = detector.predict(text)
            print(f"   ✅ Prediction: {result['prediction']}")
            print(f"   ✅ Confidence: {result['confidence']}%")
            print(f"   ✅ Risk Level: {result['risk_level']}")
            
            if 'error' in result:
                print(f"   ⚠️  Error: {result['error']}")
            if 'reason' in result:
                print(f"   ℹ️  Reason: {result['reason']}")
                
        except Exception as e:
            print(f"   ❌ ERROR: {e}")
            import traceback
            traceback.print_exc()
        
        print("-" * 40)
    
    # Test with Flask app context
    print(f"\n🌐 TESTING WITH FLASK APP CONTEXT:")
    
    with app.test_client() as client:
        # Test login first
        login_page = client.get('/login')
        
        # Extract CSRF token
        import re
        csrf_match = re.search(b'name="csrf_token" type="hidden" value="([^"]*)"', login_page.data)
        csrf_token = csrf_match.group(1).decode('utf-8') if csrf_match else None
        
        if csrf_token:
            # Login
            login_data = {
                'username': 'admin',
                'password': 'admin123',
                'csrf_token': csrf_token
            }
            
            login_response = client.post('/login', data=login_data, follow_redirects=False)
            
            # Extract session cookie
            session_cookie = None
            for cookie in login_response.headers.getlist('Set-Cookie'):
                if 'session=' in cookie:
                    session_cookie = cookie.split(';')[0]
                    break
            
            if session_cookie:
                headers = {'Cookie': session_cookie}
                
                # Test API prediction
                for i, text in enumerate(test_cases, 1):
                    print(f"\n{i}. API Test: {text[:30]}...")
                    
                    try:
                        response = client.post('/api/predict', 
                            json={
                                'email_content': text,
                                'model': 'rule_based'
                            },
                            headers=headers
                        )
                        
                        print(f"   Status: {response.status_code}")
                        print(f"   Content-Type: {response.content_type}")
                        
                        if response.status_code == 200:
                            result = response.get_json()
                            print(f"   ✅ Prediction: {result.get('prediction', 'N/A')}")
                            print(f"   ✅ Confidence: {result.get('confidence', 'N/A')}%")
                            if 'error' in result:
                                print(f"   ⚠️  Error: {result['error']}")
                        else:
                            print(f"   ❌ Response: {response.data[:200]}")
                            
                    except Exception as e:
                        print(f"   ❌ API ERROR: {e}")
                    
                    print("-" * 30)
            else:
                print("❌ No session cookie obtained")
        else:
            print("❌ No CSRF token obtained")

if __name__ == "__main__":
    debug_prediction_error()
