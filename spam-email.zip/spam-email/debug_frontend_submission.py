#!/usr/bin/env python
"""
Debug frontend submission issue
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from app_simple import EnhancedSpamDetector

def debug_frontend_submission():
    print("🔧 DEBUGGING FRONTEND SUBMISSION")
    print("=" * 50)
    
    detector = EnhancedSpamDetector()
    
    # Test cases that might be failing
    test_cases = [
        "Congratulations! You won a free iPhone",
        "Meeting scheduled tomorrow at 10am",
        "Hello team",
        "Hi there",
        "Test message",
        "This is a test email",
        "Please review the attached document",
        "Free offer now",
        "Limited time discount",
        "Click here for special promotion"
    ]
    
    for i, text in enumerate(test_cases, 1):
        print(f"\n{i}. Testing: '{text}'")
        print(f"   Length: {len(text)} chars")
        print(f"   Words: {len(text.split())}")
        
        # Test validation
        validation = detector.validate_input(text)
        print(f"   Valid: {validation['valid']}")
        
        if not validation['valid']:
            print(f"   Error: {validation['error']}")
            print(f"   Reason: {validation['reason']}")
        else:
            # Test prediction
            result = detector.predict(text)
            print(f"   Prediction: {result['prediction']}")
            print(f"   Confidence: {result['confidence']}%")
        
        print("-" * 40)

if __name__ == "__main__":
    debug_frontend_submission()
