#!/usr/bin/env python3

import requests
import json

# Test the specific cases mentioned by user
test_cases = [
    "1",  # Random string
    "Hello, this is a proper email with good structure and meaningful content. I hope you are doing well.",  # Proper email
]

print("Testing API endpoint with user's specific cases...")
print("=" * 60)

for test_text in test_cases:
    try:
        response = requests.post(
            'http://127.0.0.1:5000/api/predict_public',
            json={
                'email_content': test_text,
                'model': 'ensemble'
            },
            headers={
                'Content-Type': 'application/json'
            }
        )
        
        if response.status_code == 200:
            result = response.json()
            print(f"\nInput: '{test_text}'")
            print(f"API Prediction: {result.get('prediction', 'N/A')}")
            print(f"API Confidence: {result.get('confidence', 'N/A')}%")
            print(f"API Risk Level: {result.get('risk_level', 'N/A')}")
            print(f"API Reason: {result.get('reason', 'N/A')}")
            print(f"Model Used: {result.get('model_used', 'N/A')}")
        else:
            print(f"\nInput: '{test_text}' - ERROR: {response.status_code}")
            print(f"Response: {response.text}")
            
    except Exception as e:
        print(f"\nInput: '{test_text}' - ERROR: {e}")
    
    print("-" * 40)
