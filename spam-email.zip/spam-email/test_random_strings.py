#!/usr/bin/env python
"""
Test the classifier with random strings
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from app import app, classifier

def test_random_strings():
    with app.app_context():
        test_cases = [
            # Random strings
            "asdfghjkl",
            "qwertyuiop", 
            "123456789",
            "abc123xyz",
            "randomtext",
            "xxxxxxxx",
            
            # Actual spam examples
            "Congratulations! You have won $1000000 in our lottery. Call now to claim your prize!",
            "URGENT: Your account has been suspended. Click here to verify immediately",
            "FREE iPhone! Limited time offer. Get your brand new iPhone today",
            "Make money fast! Work from home and earn $5000 per week",
            "Viagra now available at 50% discount. Limited stock",
            
            # Normal messages
            "hello world",
            "test message", 
            "How are you doing today?",
            "Meeting at 3pm tomorrow"
        ]
        
        print("🧪 Testing random strings with ML classifier...")
        print("=" * 60)
        
        for text in test_cases:
            try:
                prediction, confidence, risk_level = classifier.predict(text, 'ensemble')
                print(f"Text: '{text}'")
                print(f"  Prediction: {prediction}")
                print(f"  Confidence: {confidence:.3f}")
                print(f"  Risk Level: {risk_level}")
                print("-" * 40)
            except Exception as e:
                print(f"Text: '{text}' - ERROR: {e}")
                print("-" * 40)

if __name__ == "__main__":
    test_random_strings()
