#!/usr/bin/env python
"""
Test ensemble without SVM model
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from app import app, classifier
import numpy as np

def test_ensemble_fix():
    with app.app_context():
        test_spam = "Congratulations! You have won $1000000 in our lottery. Call now to claim your prize!"
        test_ham = "Hello, how are you doing today?"
        
        print("🔧 Testing ensemble without problematic SVM...")
        print("=" * 60)
        
        # Preprocess
        processed_spam = classifier.preprocess_text(test_spam)
        processed_ham = classifier.preprocess_text(test_ham)
        X_spam = classifier.vectorizer.transform([processed_spam])
        X_ham = classifier.vectorizer.transform([processed_ham])
        
        # Test ensemble without SVM
        for text, X in [("Spam", X_spam), ("Ham", X_ham)]:
            print(f"\n📧 Testing {text} message:")
            predictions = []
            confidences = []
            
            # Use only naive_bayes and logistic_regression (skip SVM)
            working_models = {k: v for k, v in classifier.models.items() if k != 'svm'}
            
            for name, model in working_models.items():
                pred = model.predict(X)[0]
                conf = model.predict_proba(X)[0].max()
                predictions.append(pred)
                confidences.append(conf)
                print(f"  {name}: prediction={pred}, confidence={conf:.3f}")
            
            # Majority voting
            final_pred = max(set(predictions), key=predictions.count)
            avg_confidence = np.mean(confidences)
            
            prediction_label = 'spam' if final_pred == 1 else 'not spam'
            print(f"  Final: {prediction_label} (confidence: {avg_confidence:.3f})")
            print("-" * 40)

if __name__ == "__main__":
    test_ensemble_fix()
