#!/usr/bin/env python3
"""
Test script for the ML Spam Detection API
"""

import requests
import json
import time

def test_ml_api():
    """Test the ML spam detection API endpoints"""
    base_url = "http://localhost:5000"
    
    print("🧪 Testing ML Spam Detection API...")
    print("=" * 50)
    
    # Test cases
    test_cases = [
        {
            "name": "Spam Example 1",
            "text": "Congratulations! You won $5000. Click here to claim prize.",
            "expected": "spam"
        },
        {
            "name": "Spam Example 2", 
            "text": "FREE iPhone offer! Limited time only. Act now!",
            "expected": "spam"
        },
        {
            "name": "Normal Email",
            "text": "Please review the attached document.",
            "expected": "ham"
        },
        {
            "name": "Random String",
            "text": "jevdwhucwqhjbeflj3beoiu18u0398098",
            "expected": "ham"
        }
    ]
    
    # Test prediction endpoint
    print("\n📊 Testing /api/predict endpoint:")
    print("-" * 40)
    
    for i, test_case in enumerate(test_cases, 1):
        print(f"\n{i}. {test_case['name']}")
        print(f"   Input: {test_case['text']}")
        
        try:
            response = requests.post(
                f"{base_url}/api/predict",
                json={"email_text": test_case['text']},
                headers={"Content-Type": "application/json"},
                timeout=10
            )
            
            if response.status_code == 200:
                result = response.json()
                print(f"   ✅ Prediction: {result['prediction']}")
                print(f"   📊 Confidence: {result['confidence']}%")
                print(f"   ⚠️  Risk Level: {result['risk_level']}")
                print(f"   🔑 Keywords: {result['keywords']}")
                print(f"   ⏱️  Processing Time: {result['processing_time_ms']}ms")
                
                # Check if prediction matches expectation
                if result['prediction'].lower() == test_case['expected']:
                    print(f"   ✅ Correct!")
                else:
                    print(f"   ❌ Expected: {test_case['expected']}")
            else:
                print(f"   ❌ Error: {response.status_code}")
                print(f"   Response: {response.text}")
                
        except requests.exceptions.RequestException as e:
            print(f"   ❌ Request failed: {e}")
    
    # Test health endpoint
    print(f"\n🏥 Testing /api/health endpoint:")
    print("-" * 40)
    
    try:
        response = requests.get(f"{base_url}/api/health", timeout=5)
        if response.status_code == 200:
            result = response.json()
            print(f"   Status: {result['status']}")
            print(f"   Model Loaded: {result['model_loaded']}")
            print(f"   Timestamp: {result['timestamp']}")
        else:
            print(f"   ❌ Error: {response.status_code}")
    except requests.exceptions.RequestException as e:
        print(f"   ❌ Request failed: {e}")
    
    # Test stats endpoint (requires authentication)
    print(f"\n📈 Testing /api/stats endpoint:")
    print("-" * 40)
    
    try:
        response = requests.get(f"{base_url}/api/stats", timeout=5)
        if response.status_code == 401:
            print(f"   ✅ Authentication required (expected)")
        elif response.status_code == 200:
            result = response.json()
            print(f"   ✅ Stats retrieved successfully")
            print(f"   Total Predictions: {result.get('total_predictions', 0)}")
        else:
            print(f"   Response: {response.status_code}")
    except requests.exceptions.RequestException as e:
        print(f"   ❌ Request failed: {e}")
    
    print("\n" + "=" * 50)
    print("🎉 API Testing Complete!")

if __name__ == "__main__":
    test_ml_api()
