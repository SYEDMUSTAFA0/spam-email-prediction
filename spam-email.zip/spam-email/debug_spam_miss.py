#!/usr/bin/env python
"""
Debug spam detection miss cases
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from app_simple import EnhancedSpamDetector

def debug_spam_miss():
    print("🔧 DEBUGGING SPAM DETECTION MISS")
    print("=" * 50)
    
    detector = EnhancedSpamDetector()
    
    # Test cases that should be spam but might be missed
    test_cases = [
        "Buy now limited time offer special discount",
        "Click here immediately for free prize",
        "Urgent act now guaranteed money back",
        "Special promotion just for you today",
        "Don't miss this opportunity buy now",
        "Last chance to get 50% off",
        "Exclusive deal expires soon click here",
        "Congratulations you have been selected winner",
        "Free viagra cialis special promotion",
        "Make money fast from home guaranteed",
        "Lose weight quick guaranteed results",
        "Cheap insurance rates limited time",
        "Investment opportunity high returns guaranteed",
        "Casino bonus free play now",
        "Adult dating meet local singles free",
        "Credit card debt relief act now",
        "Loan approved no credit check guaranteed",
    ]
    
    for i, text in enumerate(test_cases, 1):
        print(f"\n{i}. Testing: {text[:50]}...")
        
        try:
            result = detector.predict(text)
            
            print(f"   Prediction: {result['prediction']}")
            print(f"   Confidence: {result['confidence']}%")
            print(f"   Risk Level: {result['risk_level']}")
            
            if 'reason' in result:
                print(f"   Reason: {result['reason']}")
            
            if 'spam_patterns' in result:
                patterns = result['spam_patterns']
                print(f"   Patterns found: {len(patterns)}")
                for pattern in patterns:
                    if pattern['count'] > 0:
                        print(f"     - {pattern['type']}: {pattern['count']} matches")
            
            if result['prediction'] == 'spam':
                print(f"   Result: ✅ CORRECT (Spam detected)")
            else:
                print(f"   Result: ❌ WRONG (Should be spam)")
                
        except Exception as e:
            print(f"   ❌ Error: {e}")
        
        print("-" * 40)
    
    # Test specific spam indicators that should be caught
    print(f"\n🔍 TESTING SPAM INDICATORS:")
    
    spam_indicators = [
        "free", "buy", "now", "click", "here", "urgent", "act", "guaranteed", 
        "limited", "time", "offer", "discount", "special", "promotion", "exclusive",
        "expires", "soon", "congratulations", "winner", "selected", "prize", "money",
        "cash", "viagra", "cialis", "casino", "bonus", "play", "adult", "dating",
        "singles", "credit", "card", "debt", "relief", "loan", "approved", "investment",
        "opportunity", "returns", "weight", "lose", "quick", "insurance", "rates"
    ]
    
    for indicator in spam_indicators:
        test_text = f"This is {indicator} special offer buy now"
        result = detector.predict(test_text)
        
        print(f"   {indicator}: {result['prediction']} (confidence: {result['confidence']}%)")
        
        if result['prediction'] != 'spam':
            print(f"      ❌ MISSED: '{indicator}' should trigger spam detection")

if __name__ == "__main__":
    debug_spam_miss()
