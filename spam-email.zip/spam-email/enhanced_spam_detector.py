#!/usr/bin/env python
"""
Enhanced Spam Email Prediction System with Input Validation and ML Pipeline
"""

import re
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.naive_bayes import MultinomialNB
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, classification_report
import nltk
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize
from nltk.stem import PorterStemmer
import string

class EnhancedSpamDetector:
    def __init__(self):
        self.tfidf_vectorizer = None
        self.ml_model = None
        self.stemmer = PorterStemmer()
        self.stop_words = set(stopwords.words('english'))
        
        # Spam patterns for rule-based detection
        self.spam_patterns = {
            'promotional': r'\b(free|win|prize|money|cash|offer|discount|promotion|special|deal|save|cheap|buy|now|urgent|limited|act now|click here|order now)\b',
            'lottery': r'\b(lottery|winner|congratulations|selected|million|billion|prize|claim|reward)\b',
            'suspicious': r'\b(viagra|casino|poker|bet|gamble|xxx|adult|dating|webcam|sexy)\b',
            'financial': r'\b(loan|credit|debt|investment|insurance|refund|guaranteed|risk|scam|fraud|phishing)\b',
            'exclamation': r'!{3,}',
            'caps': r'[A-Z]{4,}',
            'numbers': r'\d{4,}',
            'special_chars': r'[@#$%^&*]{3,}'
        }
        
        # Initialize with basic rule-based detection
        self._initialize_basic_detector()
    
    def _initialize_basic_detector(self):
        """Initialize basic rule-based spam detection"""
        # This will be enhanced with ML training
        pass
    
    def validate_input(self, text):
        """Validate input text and detect invalid content"""
        if not text or not text.strip():
            return {
                'valid': False,
                'error': 'Email content is required.',
                'reason': 'empty_input'
            }
        
        text = text.strip()
        
        # Check minimum length
        if len(text) < 10:
            return {
                'valid': False,
                'error': 'Email content too short. Please enter a valid email message.',
                'reason': 'too_short'
            }
        
        # Check maximum length
        if len(text) > 10000:
            return {
                'valid': False,
                'error': 'Email content too long (max 10KB).',
                'reason': 'too_long'
            }
        
        # Check for gibberish/random strings
        if self._is_gibberish(text):
            return {
                'valid': False,
                'error': 'Invalid email content. Please enter a meaningful email message.',
                'reason': 'gibberish'
            }
        
        # Check for excessive numbers/symbols
        if self._has_excessive_numbers(text):
            return {
                'valid': False,
                'error': 'Invalid email content. Too many numbers detected.',
                'reason': 'excessive_numbers'
            }
        
        if self._has_excessive_symbols(text):
            return {
                'valid': False,
                'error': 'Invalid email content. Too many special characters detected.',
                'reason': 'excessive_symbols'
            }
        
        # Check minimum word count
        words = text.split()
        if len(words) < 3:
            return {
                'valid': False,
                'error': 'Email content too brief. Please enter a complete message.',
                'reason': 'too_few_words'
            }
        
        return {'valid': True, 'error': None, 'reason': None}
    
    def _is_gibberish(self, text):
        """Detect gibberish or random strings"""
        # Check alphabet ratio
        alpha_chars = sum(1 for c in text if c.isalpha())
        total_chars = len(text.replace(' ', ''))
        if total_chars > 0:
            alpha_ratio = alpha_chars / total_chars
            if alpha_ratio < 0.3:  # Less than 30% letters
                return True
        
        # Check for random character patterns
        words = text.split()
        gibberish_words = 0
        
        for word in words:
            if len(word) > 5:
                # Calculate character diversity
                unique_chars = len(set(word.lower()))
                diversity_ratio = unique_chars / len(word)
                
                # High diversity with no vowels suggests gibberish
                vowels = sum(1 for c in word.lower() if c in 'aeiou')
                vowel_ratio = vowels / len(word)
                
                if diversity_ratio > 0.8 and vowel_ratio < 0.2:
                    gibberish_words += 1
        
        # If more than 30% of words are gibberish
        return gibberish_words / len(words) > 0.3 if words else False
    
    def _has_excessive_numbers(self, text):
        """Check for excessive numbers"""
        numbers = re.findall(r'\d+', text)
        total_digits = sum(len(num) for num in numbers)
        total_chars = len(text.replace(' ', ''))
        
        if total_chars > 0:
            number_ratio = total_digits / total_chars
            return number_ratio > 0.4  # More than 40% digits
        
        return False
    
    def _has_excessive_symbols(self, text):
        """Check for excessive special characters"""
        special_chars = sum(1 for c in text if not c.isalnum() and not c.isspace())
        total_chars = len(text.replace(' ', ''))
        
        if total_chars > 0:
            symbol_ratio = special_chars / total_chars
            return symbol_ratio > 0.3  # More than 30% special characters
        
        return False
    
    def preprocess_text(self, text):
        """Enhanced text preprocessing"""
        # Convert to lowercase
        text = text.lower()
        
        # Remove URLs
        text = re.sub(r'http[s]?://(?:[a-zA-Z]|[0-9]|[$-_@.&+]|[!*\\(\\),]|(?:%[0-9a-fA-F][0-9a-fA-F]))+', '', text)
        
        # Remove email addresses
        text = re.sub(r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b', '', text)
        
        # Remove excessive numbers (keep some for context)
        text = re.sub(r'\d{4,}', '', text)
        
        # Remove special characters but keep basic punctuation
        text = re.sub(r'[^a-zA-Z\s\!\?\.\,\-]', '', text)
        
        # Tokenize
        tokens = word_tokenize(text)
        
        # Remove stopwords and stem
        tokens = [self.stemmer.stem(token) for token in tokens if token not in self.stop_words and len(token) > 2]
        
        return ' '.join(tokens)
    
    def detect_spam_patterns(self, text):
        """Rule-based spam pattern detection"""
        spam_indicators = []
        spam_score = 0.0
        
        text_lower = text.lower()
        
        for pattern_name, pattern in self.spam_patterns.items():
            matches = re.findall(pattern, text_lower)
            if matches:
                spam_indicators.append({
                    'type': pattern_name,
                    'matches': len(matches),
                    'examples': matches[:3]  # Show first 3 examples
                })
                spam_score += len(matches) * 0.2
        
        return spam_indicators, spam_score
    
    def predict(self, text):
        """Main prediction method"""
        # Step 1: Validate input
        validation = self.validate_input(text)
        if not validation['valid']:
            return {
                'prediction': 'invalid',
                'confidence': 0.0,
                'risk_level': 'low',
                'reason': validation['error'],
                'error': validation['error']
            }
        
        # Step 2: Detect spam patterns
        spam_patterns, pattern_score = self.detect_spam_patterns(text)
        
        # Step 3: Preprocess text
        processed_text = self.preprocess_text(text)
        
        # Step 4: Rule-based prediction (for now, will be enhanced with ML)
        if pattern_score > 0.6:
            prediction = 'spam'
            confidence = min(0.95, pattern_score + 0.3)
            risk_level = 'high'
        elif pattern_score > 0.3:
            prediction = 'spam'
            confidence = min(0.85, pattern_score + 0.4)
            risk_level = 'medium'
        else:
            prediction = 'ham'
            confidence = 0.8
            risk_level = 'low'
        
        # Step 5: Format response
        response = {
            'prediction': prediction,
            'confidence': round(confidence * 100, 1),
            'risk_level': risk_level,
            'processed_text': processed_text,
            'spam_patterns': spam_patterns,
            'pattern_score': round(pattern_score, 2)
        }
        
        # Add reason for spam prediction
        if prediction == 'spam' and spam_patterns:
            response['reason'] = f"Suspicious patterns detected: {', '.join([p['type'] for p in spam_patterns[:3]])}"
        
        return response

# Test the enhanced detector
if __name__ == "__main__":
    detector = EnhancedSpamDetector()
    
    test_cases = [
        "Congratulations! You won a free iPhone",
        "Meeting scheduled tomorrow at 10am", 
        "jevdwhucwqhjbeflj3beoiu18u0398098",
        "902y3109r1v ohf kno13hub2-018739-219ep# D\\",
        "Hi team, please review the attached report",
        "FREE VIAGRA!!! SPECIAL PROMOTION!!!",
        "Hello, I hope this email finds you well"
    ]
    
    print("🔧 TESTING ENHANCED SPAM DETECTOR")
    print("=" * 60)
    
    for i, text in enumerate(test_cases, 1):
        print(f"\n{i}. Testing: {text[:50]}...")
        result = detector.predict(text)
        
        print(f"   Prediction: {result['prediction']}")
        print(f"   Confidence: {result['confidence']}%")
        print(f"   Risk Level: {result['risk_level']}")
        
        if 'error' in result:
            print(f"   Error: {result['error']}")
        elif 'reason' in result:
            print(f"   Reason: {result['reason']}")
        
        if result.get('spam_patterns'):
            print(f"   Patterns: {len(result['spam_patterns'])} detected")
        
        print("-" * 40)
