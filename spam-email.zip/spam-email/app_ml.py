#!/usr/bin/env python3
"""
Production-Ready Spam Detection Flask API
Integrates ML model with existing dashboard system
"""

from flask import Flask, render_template, request, jsonify, redirect, url_for, flash, session, send_file
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, login_user, logout_user, login_required, current_user
from flask_wtf.csrf import CSRFProtect
from flask_cors import CORS
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime
import os
import re
import pickle
import pandas as pd
import numpy as np
import nltk
from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer
from nltk.tokenize import word_tokenize
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.naive_bayes import MultinomialNB
import html
import time
import logging

# Initialize Flask app
app = Flask(__name__)
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY') or 'your-secret-key-here-change-in-production'
app.config['SQLALCHEMY_DATABASE_URI'] = os.environ.get('DATABASE_URL') or 'sqlite:///spam_email.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# Enable CORS for API endpoints
CORS(app)

# Initialize extensions
db = SQLAlchemy(app)
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'

# Initialize CSRF protection
csrf = CSRFProtect(app)

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Exempt API endpoints from CSRF protection
@csrf.exempt
@app.route('/api/predict', methods=['POST'])
def api_predict():
    """API endpoint for spam prediction"""
    start_time = time.time()
    
    try:
        # Get request data
        data = request.get_json()
        if not data or 'email_text' not in data:
            return jsonify({
                'error': 'email_text is required',
                'status': 'error'
            }), 400
        
        email_text = data['email_text']
        
        # Validate input
        if not email_text or not email_text.strip():
            return jsonify({
                'error': 'Email content cannot be empty',
                'status': 'error'
            }), 400
        
        if len(email_text) > 10000:
            return jsonify({
                'error': 'Email content too long (max 10KB)',
                'status': 'error'
            }), 400
        
        # Make prediction using hybrid detector
        result = hybrid_detector.predict_hybrid(email_text)
        if not result:
            return jsonify({
                'error': 'Prediction service unavailable',
                'status': 'error'
            }), 503
        
        # Calculate processing time
        processing_time = (time.time() - start_time) * 1000  # Convert to milliseconds
        
        # Create response (hybrid detector already provides correct format)
        response = {
            'prediction': result['prediction'].capitalize(),
            'confidence': result['confidence'],
            'spam_probability': result['spam_probability'],
            'ham_probability': result['ham_probability'],
            'risk_level': result['risk_level'],
            'reason': result['reason'],
            'keywords': result['keywords'],
            'processing_time_ms': round(processing_time, 2),
            'model_used': result['model_used'],
            'status': 'success'
        }
        
        # Save prediction to database if user is authenticated
        if current_user.is_authenticated:
            try:
                prediction_record = Prediction(
                    user_id=current_user.id,
                    email_content=sanitize_input(email_text),
                    prediction=result['prediction'],
                    confidence_score=result['confidence'] / 100,  # Convert back to 0-1 range
                    risk_level=result['risk_level'].lower(),
                    model_used=result['model_used'],
                    spam_probability=result['spam_probability'] / 100,  # Convert back to 0-1 range
                    keywords_found=str(result['keywords']),
                    processing_time=processing_time
                )
                db.session.add(prediction_record)
                db.session.commit()
            except Exception as e:
                logger.error(f"Error saving prediction: {e}")
                db.session.rollback()
        
        return jsonify(response)
        
    except Exception as e:
        logger.error(f"API prediction error: {e}")
        return jsonify({
            'error': 'Internal server error',
            'status': 'error'
        }), 500

@csrf.exempt
@app.route('/api/stats', methods=['GET'])
@login_required
def api_stats():
    """API endpoint for statistics"""
    try:
        # Get database statistics
        total_predictions = Prediction.query.count()
        spam_predictions = Prediction.query.filter_by(prediction='spam').count()
        ham_predictions = Prediction.query.filter_by(prediction='ham').count()
        
        # Calculate percentages
        spam_percentage = (spam_predictions / total_predictions * 100) if total_predictions > 0 else 0
        ham_percentage = (ham_predictions / total_predictions * 100) if total_predictions > 0 else 0
        
        # Get user-specific stats
        user_predictions = Prediction.query.filter_by(user_id=current_user.id).count()
        user_spam = Prediction.query.filter_by(user_id=current_user.id, prediction='spam').count()
        user_ham = Prediction.query.filter_by(user_id=current_user.id, prediction='ham').count()
        
        # Model performance
        avg_confidence = db.session.query(db.func.avg(Prediction.confidence_score)).scalar() or 0
        avg_processing_time = db.session.query(db.func.avg(Prediction.processing_time)).scalar() or 0
        
        stats = {
            'total_predictions': total_predictions,
            'spam_predictions': spam_predictions,
            'ham_predictions': ham_predictions,
            'spam_percentage': round(spam_percentage, 2),
            'ham_percentage': round(ham_percentage, 2),
            'user_predictions': user_predictions,
            'user_spam': user_spam,
            'user_ham': user_ham,
            'model_accuracy': '98.21%',  # From training
            'avg_confidence': round(avg_confidence * 100, 2),
            'avg_processing_time': round(avg_processing_time, 2),
            'model_status': 'active' if ml_detector.model_loaded else 'inactive'
        }
        
        return jsonify(stats)
        
    except Exception as e:
        logger.error(f"API stats error: {e}")
        return jsonify({'error': 'Failed to fetch statistics'}), 500

@csrf.exempt
@app.route('/api/history', methods=['GET'])
@login_required
def api_history():
    """API endpoint for prediction history"""
    try:
        # Get user's prediction history
        predictions = Prediction.query.filter_by(user_id=current_user.id)\
                                     .order_by(Prediction.created_at.desc())\
                                     .limit(50)\
                                     .all()
        
        history = []
        for pred in predictions:
            history.append({
                'id': pred.id,
                'email_content': pred.email_content[:100] + '...' if len(pred.email_content) > 100 else pred.email_content,
                'prediction': pred.prediction.capitalize(),
                'confidence': round(pred.confidence_score * 100, 2),
                'risk_level': pred.risk_level.capitalize(),
                'created_at': pred.created_at.isoformat(),
                'processing_time': pred.processing_time
            })
        
        return jsonify(history)
        
    except Exception as e:
        logger.error(f"API history error: {e}")
        return jsonify({'error': 'Failed to fetch history'}), 500

@csrf.exempt
@app.route('/api/health', methods=['GET'])
def health_check():
    """Health check endpoint"""
    return jsonify({
        'status': 'healthy',
        'model_loaded': ml_detector.model_loaded,
        'timestamp': datetime.utcnow().isoformat()
    })

# Download NLTK data
try:
    nltk.data.find('tokenizers/punkt')
    nltk.data.find('corpora/stopwords')
    nltk.data.find('corpora/wordnet')
    nltk.data.find('tokenizers/punkt_tab')
except LookupError:
    print("📥 Downloading NLTK data...")
    nltk.download('punkt', quiet=True)
    nltk.download('punkt_tab', quiet=True)
    nltk.download('stopwords', quiet=True)
    nltk.download('wordnet', quiet=True)
    print("✅ NLTK data downloaded successfully")

# Database Models
class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(128), nullable=False)
    is_admin = db.Column(db.Boolean, default=False)
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    predictions = db.relationship('Prediction', backref='user', lazy=True)
    
    def set_password(self, password):
        self.password_hash = generate_password_hash(password)
    
    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

class Prediction(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    email_content = db.Column(db.Text, nullable=False)
    prediction = db.Column(db.String(10), nullable=False)  # 'spam' or 'ham'
    confidence_score = db.Column(db.Float, nullable=False)
    risk_level = db.Column(db.String(10), nullable=False)  # 'low', 'medium', 'high'
    model_used = db.Column(db.String(50), nullable=False)
    spam_probability = db.Column(db.Float, nullable=False)
    keywords_found = db.Column(db.Text)  # JSON string of keywords
    processing_time = db.Column(db.Float)  # Processing time in milliseconds
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class SpamDataset(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    email_text = db.Column(db.Text, nullable=False)
    label = db.Column(db.String(10), nullable=False)  # 'spam' or 'ham'
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

# Production ML Spam Detector
class MLSpamDetector:
    def __init__(self):
        self.model = None
        self.vectorizer = None
        self.lemmatizer = WordNetLemmatizer()
        self.stop_words = set(stopwords.words('english'))
        self.model_loaded = False
        
        # Spam keywords for analysis
        self.spam_keywords = [
            'free', 'win', 'prize', 'money', 'cash', 'offer', 'discount', 'promotion',
            'special', 'deal', 'save', 'cheap', 'buy', 'now', 'urgent', 'limited',
            'act now', 'click here', 'order now', 'exclusive', 'congratulations',
            'winner', 'selected', 'million', 'billion', 'claim', 'reward', 'congrats',
            'viagra', 'casino', 'poker', 'bet', 'gamble', 'xxx', 'adult', 'dating',
            'loan', 'credit', 'debt', 'investment', 'insurance', 'guaranteed', 'risk',
            'scam', 'fraud', 'phishing', 'hack', 'breach', 'instant', 'quick',
            'easy', 'fast', 'new', 'hot', 'sexy', 'suspicious', 'verify', 'confirm'
        ]
        
        # Load the trained model
        self.load_model()
    
    def load_model(self):
        """Load the trained ML model and vectorizer"""
        try:
            # Load the model
            with open('spam_model.pkl', 'rb') as f:
                self.model = pickle.load(f)
            
            # Load the vectorizer
            with open('vectorizer.pkl', 'rb') as f:
                self.vectorizer = pickle.load(f)
            
            self.model_loaded = True
            logger.info("✅ ML model and vectorizer loaded successfully")
            return True
        except Exception as e:
            logger.error(f"❌ Error loading ML model: {e}")
            self.model_loaded = False
            return False
    
    def preprocess_text(self, text):
        """
        Preprocess text data:
        1. Convert to lowercase
        2. Remove URLs and special characters
        3. Tokenization
        4. Remove stopwords
        5. Lemmatization
        """
        if not isinstance(text, str):
            text = str(text)
        
        # Convert to lowercase
        text = text.lower()
        
        # Remove URLs
        text = re.sub(r'http\S+|www\S+|https\S+', '', text, flags=re.MULTILINE)
        
        # Remove email addresses
        text = re.sub(r'\S+@\S+', '', text)
        
        # Remove phone numbers
        text = re.sub(r'\b\d{3}[-.]?\d{3}[-.]?\d{4}\b', '', text)
        
        # Remove special characters and numbers, keep only letters and spaces
        text = re.sub(r'[^a-zA-Z\s]', '', text)
        
        # Tokenization
        tokens = word_tokenize(text)
        
        # Remove stopwords
        tokens = [word for word in tokens if word not in self.stop_words]
        
        # Lemmatization
        tokens = [self.lemmatizer.lemmatize(word) for word in tokens]
        
        # Remove single characters
        tokens = [word for word in tokens if len(word) > 1]
        
        return ' '.join(tokens)
    
    def predict_spam(self, text):
        """Make prediction on new text using ML model"""
        if not self.model_loaded:
            return None
        
        try:
            # Preprocess the text
            processed_text = self.preprocess_text(text)
            
            # Vectorize the text
            vector = self.vectorizer.transform([processed_text])
            
            # Make prediction
            prediction = self.model.predict(vector)[0]
            probability = self.model.predict_proba(vector)[0]
            
            # Convert prediction to label
            label = 'spam' if prediction == 1 else 'ham'
            confidence = max(probability)
            spam_probability = probability[1]
            
            return {
                'prediction': label,
                'confidence': confidence,
                'spam_probability': spam_probability,
                'ham_probability': probability[0]
            }
        except Exception as e:
            logger.error(f"❌ Error making prediction: {e}")
            return None
    
    def extract_keywords(self, text):
        """Extract spam keywords from text"""
        text_lower = text.lower()
        found_keywords = []
        
        for keyword in self.spam_keywords:
            if keyword in text_lower:
                found_keywords.append(keyword)
        
        return found_keywords
    
    def get_risk_level(self, spam_probability):
        """Determine risk level based on spam probability"""
        if spam_probability >= 0.7:
            return 'high'
        elif spam_probability >= 0.4:
            return 'medium'
        else:
            return 'low'
    
    def get_reason(self, prediction, spam_probability, keywords):
        """Generate reason for prediction"""
        if prediction == 'spam':
            if spam_probability >= 0.9:
                return "Highly suspicious promotional content detected"
            elif spam_probability >= 0.7:
                return "Suspicious promotional language detected"
            elif keywords:
                return f"Spam indicators found: {', '.join(keywords[:3])}"
            else:
                return "Pattern matches known spam characteristics"
        else:
            return "Content appears to be legitimate"

# Hybrid Spam Detection Engine
class HybridSpamDetector:
    def __init__(self, ml_detector):
        """Initialize hybrid detector with ML model"""
        self.ml_detector = ml_detector
        
        # Enhanced spam keyword library
        self.spam_keywords = [
            'free', 'winner', 'lottery', 'money', 'offer', 'click', 'urgent', 
            'prize', 'claim', 'bonus', 'discount', 'crypto', 'investment',
            'win', 'cash', 'prize', 'million', 'billion', 'congratulations',
            'selected', 'guaranteed', 'risk', 'scam', 'fraud', 'phishing',
            'viagra', 'casino', 'poker', 'bet', 'gamble', 'dating', 'adult',
            'loan', 'credit', 'debt', 'insurance', 'refund', 'instant',
            'quick', 'easy', 'fast', 'special', 'promotion', 'exclusive',
            'limited', 'act now', 'order now', 'buy now', 'subscribe'
        ]
        
        # Suspicious patterns
        self.suspicious_patterns = {
            'excessive_punctuation': r'[!$]{3,}',
            'excessive_caps': r'[A-Z]{4,}',
            'phone_numbers': r'\b\d{3}[-.]?\d{3}[-.]?\d{4}\b',
            'email_addresses': r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b',
            'urls': r'http[s]?://(?:[a-zA-Z]|[0-9]|[$-_@.&+]|[!*\\(\\),]|(?:%[0-9a-fA-F][0-9a-fA-F]))+',
            'excessive_digits': r'\d{4,}'
        }
    
    def is_gibberish(self, text):
        """Detect gibberish/random text"""
        if not text or len(text.strip()) < 3:
            return True
        
        # Remove spaces and punctuation for analysis
        clean_text = re.sub(r'[^\w]', '', text)
        
        if len(clean_text) < 5:
            return True
        
        # Count words - if it's a proper sentence with multiple words, it's likely not gibberish
        words = text.split()
        if len(words) >= 2:
            # Check if words are common English words
            common_words = {'hello', 'hi', 'hey', 'good', 'morning', 'afternoon', 'evening', 'night', 
                          'thanks', 'thank', 'please', 'brother', 'sister', 'friend', 'dear', 'love',
                          'see', 'you', 'have', 'great', 'day', 'how', 'are', 'doing', 'well', 'fine',
                          'review', 'document', 'meeting', 'tomorrow', 'today', 'yesterday', 'week', 'month'}
            
            # If most words are common English words, it's not gibberish
            common_word_count = sum(1 for word in words if word.lower() in common_words)
            if len(words) > 0 and common_word_count / len(words) >= 0.5:
                return False
        
        letters = sum(c.isalpha() for c in clean_text)
        numbers = sum(c.isdigit() for c in clean_text)
        
        # High number-to-letter ratio suggests gibberish
        if numbers > letters and numbers / len(clean_text) > 0.6:
            return True
        
        # Check if it's mostly one word (no spaces) and long
        if len(words) <= 1 and len(text) > 10:
            # Check character diversity (high diversity suggests randomness)
            unique_chars = len(set(clean_text.lower()))
            diversity_ratio = unique_chars / len(clean_text)
            
            # Very high character diversity with no vowels suggests gibberish
            vowels = sum(1 for c in clean_text.lower() if c in 'aeiou')
            vowel_ratio = vowels / len(clean_text) if len(clean_text) > 0 else 0
            
            if diversity_ratio > 0.8 and vowel_ratio < 0.2:
                return True
        
        # Check for random alphanumeric patterns (only if it's clearly random)
        if re.search(r'[a-zA-Z0-9]{8,}', clean_text) and len(words) <= 2:
            # Additional check: if it contains consecutive letters that make sense, it's not gibberish
            if not re.search(r'[aeiou]{3,}', clean_text.lower()):  # No vowel sequences
                return True
        
        return False
    
    def detect_excessive_numbers(self, text):
        """Detect excessive numbers in text"""
        if not text:
            return 0
        
        digit_count = sum(c.isdigit() for c in text)
        total_chars = len(text.replace(' ', ''))
        
        if total_chars == 0:
            return 0
        
        digit_ratio = digit_count / total_chars
        
        if digit_ratio > 0.30:
            return 2  # High penalty
        elif digit_ratio > 0.20:
            return 1  # Medium penalty
        
        return 0
    
    def detect_suspicious_patterns(self, text):
        """Detect suspicious patterns in text"""
        if not text:
            return 0
        
        score = 0
        
        # Check for excessive punctuation
        if re.search(self.suspicious_patterns['excessive_punctuation'], text):
            score += 1
        
        # Check for excessive capitalization
        if re.search(self.suspicious_patterns['excessive_caps'], text):
            score += 1
        
        # Check for phone numbers
        if re.search(self.suspicious_patterns['phone_numbers'], text):
            score += 1
        
        # Check for email addresses
        if re.search(self.suspicious_patterns['email_addresses'], text):
            score += 1
        
        # Check for URLs
        if re.search(self.suspicious_patterns['urls'], text):
            score += 1
        
        # Check for excessive digits
        if re.search(self.suspicious_patterns['excessive_digits'], text):
            score += 1
        
        return score
    
    def calculate_keyword_score(self, text):
        """Calculate spam keyword score"""
        if not text:
            return 0, []
        
        text_lower = text.lower()
        found_keywords = []
        score = 0
        
        for keyword in self.spam_keywords:
            if keyword in text_lower:
                found_keywords.append(keyword)
                score += 1
        
        return score, found_keywords
    
    def calculate_hybrid_score(self, text):
        """Calculate hybrid spam score combining all detection methods"""
        if not text:
            return {
                'ml_score': 0.0,
                'gibberish_score': 0,
                'number_score': 0,
                'pattern_score': 0,
                'keyword_score': 0,
                'total_score': 0.0,
                'found_keywords': []
            }
        
        # Get ML prediction
        ml_result = self.ml_detector.predict_spam(text)
        ml_score = ml_result['spam_probability'] if ml_result else 0.0
        
        # Calculate individual scores
        gibberish_score = 3 if self.is_gibberish(text) else 0
        number_score = self.detect_excessive_numbers(text)
        pattern_score = self.detect_suspicious_patterns(text)
        keyword_score, found_keywords = self.calculate_keyword_score(text)
        
        # Calculate total hybrid score
        total_score = ml_score + (gibberish_score * 0.1) + (number_score * 0.05) + \
                      (pattern_score * 0.05) + (keyword_score * 0.1)
        
        # Cap score at 1.0
        total_score = min(1.0, total_score)
        
        return {
            'ml_score': ml_score,
            'gibberish_score': gibberish_score,
            'number_score': number_score,
            'pattern_score': pattern_score,
            'keyword_score': keyword_score,
            'total_score': total_score,
            'found_keywords': found_keywords
        }
    
    def predict_hybrid(self, text):
        """Make hybrid prediction combining ML and rule-based detection"""
        # Calculate hybrid scores
        scores = self.calculate_hybrid_score(text)
        
        # Determine final prediction
        total_score = scores['total_score']
        
        # Apply more conservative decision logic for normal text
        if scores['gibberish_score'] >= 3:
            final_prediction = 'spam'
            reason = 'Random or gibberish text detected'
            confidence = min(95.0, 50.0 + (total_score * 40))
        elif total_score >= 0.8:  # Increased from 0.7
            final_prediction = 'spam'
            reason = 'Multiple spam indicators detected'
            confidence = min(98.0, 50.0 + (total_score * 45))
        elif total_score >= 0.6:  # Increased from 0.4
            final_prediction = 'spam'
            if scores['found_keywords']:
                reason = f"Suspicious keywords found: {', '.join(scores['found_keywords'][:3])}"
            else:
                reason = 'Suspicious patterns detected'
            confidence = min(90.0, 50.0 + (total_score * 40))
        else:
            final_prediction = 'ham'
            reason = 'Content appears to be legitimate'
            confidence = max(60.0, 50.0 + ((1-total_score) * 30))
        
        # Calculate risk level
        risk_level = self.get_risk_level(total_score)
        
        return {
            'prediction': final_prediction,
            'confidence': round(confidence, 2),
            'spam_probability': round(total_score * 100, 2),
            'ham_probability': round((1 - total_score) * 100, 2),
            'risk_level': risk_level.capitalize(),
            'reason': reason,
            'keywords': scores['found_keywords'],
            'model_used': 'Hybrid Detection Engine',
            'detailed_scores': scores
        }
    
    def get_risk_level(self, spam_probability):
        """Determine risk level based on spam probability"""
        if spam_probability >= 0.7:
            return 'High'
        elif spam_probability >= 0.4:
            return 'Medium'
        else:
            return 'Low'

# Initialize detectors
ml_detector = MLSpamDetector()
hybrid_detector = HybridSpamDetector(ml_detector)

# Security utilities
def sanitize_input(text):
    """Sanitize user input to prevent XSS"""
    if not text:
        return ""
    return html.escape(text)

def validate_email(email):
    """Validate email format"""
    pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    return re.match(pattern, email) is not None

def validate_username(username):
    """Validate username format"""
    pattern = r'^[a-zA-Z0-9_-]{3,20}$'
    return re.match(pattern, username) is not None

def validate_password_strength(password):
    """Validate password strength"""
    if len(password) < 8:
        return False, "Password must be at least 8 characters long"
    
    if not re.search(r'[a-z]', password):
        return False, "Password must contain at least one lowercase letter"
    
    if not re.search(r'[A-Z]', password):
        return False, "Password must contain at least one uppercase letter"
    
    if not re.search(r'\d', password):
        return False, "Password must contain at least one number"
    
    if not re.search(r'[^a-zA-Z0-9]', password):
        return False, "Password must contain at least one special character"
    
    return True, "Password meets requirements"

# Database utility functions
@app.route('/')
def index():
    return render_template('index.html')

@app.route('/dashboard')
@login_required
def dashboard():
    return render_template('dashboard.html')

@app.route('/history')
@login_required
def history():
    """History page - shows user's prediction history"""
    # Get user's prediction history
    predictions = Prediction.query.filter_by(user_id=current_user.id)\
                                 .order_by(Prediction.created_at.desc())\
                                 .limit(50)\
                                 .all()
    return render_template('history.html', predictions=predictions)

@app.route('/admin')
@login_required
def admin_dashboard():
    """Admin dashboard page"""
    if not current_user.is_admin:
        flash('Access denied. Admin privileges required.', 'error')
        return redirect(url_for('dashboard'))
    
    # Get admin statistics
    stats = get_admin_stats_optimized()
    return render_template('admin/dashboard.html', stats=stats)

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        
        if not username or not password:
            flash('Please enter both username and password', 'error')
            return render_template('login.html')
        
        user = User.query.filter_by(username=username).first()
        
        if user and user.check_password(password) and user.is_active:
            login_user(user)
            flash('Login successful!', 'success')
            return redirect(url_for('dashboard'))
        else:
            flash('Invalid username or password', 'error')
    
    return render_template('login.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form.get('username')
        email = request.form.get('email')
        password = request.form.get('password')
        
        # Validate inputs
        if not all([username, email, password]):
            flash('All fields are required', 'error')
            return render_template('register.html')
        
        if not validate_username(username):
            flash('Invalid username format', 'error')
            return render_template('register.html')
        
        if not validate_email(email):
            flash('Invalid email format', 'error')
            return render_template('register.html')
        
        valid_password, password_msg = validate_password_strength(password)
        if not valid_password:
            flash(password_msg, 'error')
            return render_template('register.html')
        
        # Check if user already exists
        if User.query.filter_by(username=username).first():
            flash('Username already exists', 'error')
            return render_template('register.html')
        
        if User.query.filter_by(email=email).first():
            flash('Email already exists', 'error')
            return render_template('register.html')
        
        # Create new user
        user = User(username=username, email=email)
        user.set_password(password)
        db.session.add(user)
        db.session.commit()
        
        flash('Registration successful! Please login.', 'success')
        return redirect(url_for('login'))
    
    return render_template('register.html')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    flash('You have been logged out', 'info')
    return redirect(url_for('index'))

# Database utility functions
def init_database():
    """Initialize database with tables and default admin user"""
    with app.app_context():
        try:
            db.create_all()
            print("✅ Database tables created successfully")
            
            # Create default admin user if not exists
            admin = User.query.filter_by(username='admin').first()
            if not admin:
                admin = User(
                    username='admin',
                    email='admin@spamguard.ai',
                    is_admin=True,
                    is_active=True
                )
                admin.set_password('admin123')
                db.session.add(admin)
                db.session.commit()
                print("✅ Default admin user created (username: admin, password: admin123)")
            else:
                print("✅ Admin user already exists")
                
        except Exception as e:
            print(f"❌ Database initialization error: {e}")
            db.session.rollback()
            raise

# Error handlers
@app.errorhandler(404)
def not_found_error(error):
    if request.path.startswith('/api/') or request.is_json:
        return jsonify({'error': 'API endpoint not found', 'status': 'error'}), 404
    return render_template('404.html'), 404

@app.errorhandler(500)
def internal_error(error):
    db.session.rollback()
    if request.path.startswith('/api/') or request.is_json:
        return jsonify({'error': 'Internal server error', 'status': 'error'}), 500
    return render_template('500.html'), 500

@app.errorhandler(401)
def unauthorized_error(error):
    if request.path.startswith('/api/') or request.is_json:
        return jsonify({'error': 'Authentication required', 'status': 'error'}), 401
    return redirect(url_for('login'))

@app.errorhandler(403)
def forbidden_error(error):
    if request.path.startswith('/api/') or request.is_json:
        return jsonify({'error': 'Access forbidden', 'status': 'error'}), 403
    return render_template('403.html'), 403

# Performance monitoring
def performance_monitor(f):
    """Decorator to monitor function performance"""
    from functools import wraps
    @wraps(f)
    def decorated_function(*args, **kwargs):
        start_time = time.time()
        result = f(*args, **kwargs)
        end_time = time.time()
        
        execution_time = end_time - start_time
        if execution_time > 1.0:  # Log if takes more than 1 second
            logger.warning(f"⚠️  Slow operation: {f.__name__} took {execution_time:.2f}s")
        
        return result
    return decorated_function

if __name__ == '__main__':
    # Initialize database
    init_database()
    
    # Check if ML model is loaded
    if ml_detector.model_loaded:
        print("🎉 ML Spam Detection System is ready!")
        print("📊 Model Accuracy: 98.21%")
        print("🚀 API endpoints available at:")
        print("   - POST /api/predict - Spam prediction")
        print("   - GET /api/stats - Statistics")
        print("   - GET /api/history - Prediction history")
        print("   - GET /api/health - Health check")
    else:
        print("⚠️  ML model not loaded. Using fallback system.")
    
    # Run the app
    app.run(debug=True, host='0.0.0.0', port=5000)
