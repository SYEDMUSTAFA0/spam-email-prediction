#!/usr/bin/env python
"""
Debug spam classifier to see why messages aren't detected as spam
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from app_simple import SimpleSpamClassifier

def debug_spam_classifier():
    print("🔧 DEBUGGING SPAM CLASSIFIER")
    print("=" * 50)
    
    classifier = SimpleSpamClassifier()
    
    # Test messages
    test_messages = [
        "URGENT! You have won a FREE prize! Click now to claim your money!",
        "Hi team, please review the attached report for our upcoming meeting.",
        "LIMITED TIME OFFER! Buy now and get 50% discount!",
        "Hello, I hope this email finds you well. Best regards.",
        "CONGRATULATIONS! You've been selected for a million dollar prize!",
        "Please find attached the quarterly report for your review.",
        "FREE VIAGRA!!! SPECIAL PROMOTION!!!",
        "Dear colleague, I'm writing to follow up on our discussion.",
        "ACT NOW! GUARANTEED CASH REWARD!!!",
        "Thank you for your time and consideration.",
        "CLICK HERE FOR EXCLUSIVE DEAL!!!",
    ]
    
    for i, message in enumerate(test_messages, 1):
        print(f"\n{i}. Testing: {message[:50]}...")
        
        # Get detailed scoring
        processed_text = classifier.preprocess_text(message)
        print(f"   Processed: '{processed_text}'")
        
        # Check individual indicators
        text_lower = message.lower()
        print(f"   Text lower: '{text_lower}'")
        
        spam_score = classifier.calculate_spam_score(message)
        print(f"   Raw spam score: {spam_score}")
        
        # Debug specific indicators for problematic messages
        if 'act now' in message.lower():
            print(f"   Found 'act now': ✅")
        else:
            print(f"   Found 'act now': ❌")
            
        if 'guaranteed' in message.lower():
            print(f"   Found 'guaranteed': ✅")
        else:
            print(f"   Found 'guaranteed': ❌")
            
        if 'cash' in message.lower():
            print(f"   Found 'cash': ✅")
        else:
            print(f"   Found 'cash': ❌")
            
        if 'reward' in message.lower():
            print(f"   Found 'reward': ✅")
        else:
            print(f"   Found 'reward': ❌")
        
        prediction, confidence, risk_level = classifier.predict(message, 'rule_based')
        print(f"   Prediction: {prediction}")
        print(f"   Confidence: {confidence}")
        print(f"   Risk Level: {risk_level}")
        print(f"   Expected: {'SPAM' if 'urgent' in message.lower() or 'free' in message.lower() or 'prize' in message.lower() else 'HAM'}")
        print(f"   Match: {'✅' if (prediction == 'spam' and ('urgent' in message.lower() or 'free' in message.lower() or 'prize' in message.lower())) or (prediction == 'ham' and not any(word in message.lower() for word in ['urgent', 'free', 'prize'])) else '❌'}")
        print("-" * 40)
    
    print("\n🎯 CLASSIFIER DEBUGGING COMPLETED!")

if __name__ == "__main__":
    debug_spam_classifier()
