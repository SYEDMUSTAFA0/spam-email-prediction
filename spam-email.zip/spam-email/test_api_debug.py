#!/usr/bin/env python3

import requests
import json

# Test the formal email specifically
formal_email = "Dear Sir, I am writing to inquire about your services. Please let me know if you can help."

print("Testing API with formal email...")
print("=" * 60)
print(f"Input: '{formal_email}'")
print()

try:
    response = requests.post(
        'http://127.0.0.1:5000/api/predict_public',
        json={
            'email_content': formal_email,
            'model': 'ensemble'
        },
        headers={
            'Content-Type': 'application/json'
        }
    )
    
    if response.status_code == 200:
        result = response.json()
        print(f"API Prediction: {result.get('prediction', 'N/A')}")
        print(f"API Confidence: {result.get('confidence', 'N/A')}%")
        print(f"API Risk Level: {result.get('risk_level', 'N/A')}")
        print(f"API Reason: {result.get('reason', 'N/A')}")
        print(f"Model Used: {result.get('model_used', 'N/A')}")
    else:
        print(f"ERROR: {response.status_code}")
        print(f"Response: {response.text}")
        
except Exception as e:
    print(f"ERROR: {e}")
