#!/usr/bin/env python
"""
Test API response format to see what's being returned
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from app import app, classifier

def test_api_response():
    with app.app_context():
        test_cases = [
            "asdfghjkl",  # Random string
            "Hello John,\n\nI hope this email finds you well. I wanted to follow up on our meeting from last week regarding the project timeline. Let me know if you have any questions.\n\nBest regards,\nSarah"
        ]
        
        print("🔍 Testing API response format...")
        print("=" * 80)
        
        for text in test_cases:
            print(f"\n📧 Testing: '{text[:50]}...'")
            
            # Simulate what the API does
            prediction, confidence, risk_level = classifier.predict(text, 'ensemble')
            
            print(f"ML Result: prediction='{prediction}', confidence={confidence}, risk_level='{risk_level}'")
            
            # Simulate the API response structure
            if prediction is None:
                # Fallback to rule-based detection
                from app import rule_based_detection, extract_spam_keywords
                prediction, confidence, risk_level, keywords = rule_based_detection(text)
                model_used = 'rule_based'
                keywords_list = keywords
            else:
                # Extract keywords from the email
                from app import extract_spam_keywords
                keywords_list = extract_spam_keywords(text)
                model_used = 'ensemble'
            
            # Generate reason
            if prediction == 'spam':
                if confidence < 0.6:
                    reason = 'Suspicious formatting and unusual content patterns'
                elif confidence < 0.8:
                    reason = 'Contains spam-like characteristics and suspicious elements'
                else:
                    reason = 'High confidence spam detection based on multiple factors'
            else:
                if confidence < 0.6:
                    reason = 'Appears to be legitimate but lacks clear context'
                elif confidence < 0.8:
                    reason = 'Email appears to be legitimate'
                else:
                    reason = 'Email appears to be legitimate with proper structure'
            
            api_response = {
                'prediction': prediction,
                'confidence': float(confidence),
                'risk_level': risk_level,
                'reason': reason,
                'model_used': model_used,
                'keywords': keywords_list
            }
            
            print(f"API Response: {api_response}")
            print("-" * 60)

if __name__ == "__main__":
    test_api_response()
