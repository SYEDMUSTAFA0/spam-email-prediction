#!/usr/bin/env python3

import sys
import os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from app import rule_based_detection, is_email_like_content, has_proper_structure, detect_gibberish

# Test the specific cases mentioned by user
test_cases = [
    "1",  # Random string
    "Hello, this is a proper email with good structure and meaningful content. I hope you are doing well.",  # Proper email
]

print("Testing current behavior...")
print("=" * 60)

for test_text in test_cases:
    print(f"\nInput: '{test_text}'")
    
    # Test individual components
    gibberish_score = detect_gibberish(test_text)
    email_like = is_email_like_content(test_text)
    proper_structure = has_proper_structure(test_text)
    
    print(f"Gibberish Score: {gibberish_score:.2f}")
    print(f"Email Like: {email_like}")
    print(f"Proper Structure: {proper_structure}")
    print(f"Length: {len(test_text.strip())}")
    
    # Test full detection
    prediction, confidence, risk_level, keywords = rule_based_detection(test_text)
    
    print(f"Final Prediction: {prediction}")
    print(f"Confidence: {confidence:.2f}")
    print(f"Risk Level: {risk_level}")
    print(f"Keywords: {keywords}")
    print("-" * 40)
