#!/usr/bin/env python3
"""
Hybrid Spam Detection Engine
Combines ML predictions with anomaly detection and gibberish detection
"""

import re
import numpy as np
from collections import Counter
import string

class HybridSpamDetector:
    def __init__(self, ml_detector):
        """Initialize hybrid detector with ML model"""
        self.ml_detector = ml_detector
        
        # Spam keyword library
        self.spam_keywords = [
            'free', 'winner', 'lottery', 'money', 'offer', 'click', 'urgent', 
            'prize', 'claim', 'bonus', 'discount', 'crypto', 'investment',
            'win', 'cash', 'prize', 'million', 'billion', 'congratulations',
            'selected', 'guaranteed', 'risk', 'scam', 'fraud', 'phishing',
            'viagra', 'casino', 'poker', 'bet', 'gamble', 'dating', 'adult',
            'loan', 'credit', 'debt', 'insurance', 'refund', 'instant',
            'quick', 'easy', 'fast', 'special', 'promotion', 'exclusive',
            'limited', 'act now', 'order now', 'buy now', 'subscribe'
        ]
        
        # Suspicious patterns
        self.suspicious_patterns = {
            'excessive_punctuation': r'[!$]{3,}',
            'excessive_caps': r'[A-Z]{4,}',
            'phone_numbers': r'\b\d{3}[-.]?\d{3}[-.]?\d{4}\b',
            'email_addresses': r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b',
            'urls': r'http[s]?://(?:[a-zA-Z]|[0-9]|[$-_@.&+]|[!*\\(\\),]|(?:%[0-9a-fA-F][0-9a-fA-F]))+',
            'excessive_digits': r'\d{4,}'
        }
    
    def is_gibberish(self, text):
        """
        Detect gibberish/random text
        Returns True if text appears to be random characters
        """
        if not text or len(text.strip()) < 3:
            return True
        
        # Remove spaces and punctuation for analysis
        clean_text = re.sub(r'[^\w]', '', text)
        
        if len(clean_text) < 5:
            return True
        
        letters = sum(c.isalpha() for c in clean_text)
        numbers = sum(c.isdigit() for c in clean_text)
        
        # High number-to-letter ratio suggests gibberish
        if numbers > letters and numbers / len(clean_text) > 0.6:
            return True
        
        # Check if it's mostly one word (no spaces)
        words = text.split()
        if len(words) <= 1 and len(text) > 10:
            # Check character diversity (high diversity suggests randomness)
            unique_chars = len(set(clean_text.lower()))
            diversity_ratio = unique_chars / len(clean_text)
            
            # Very high character diversity with no vowels suggests gibberish
            vowels = sum(1 for c in clean_text.lower() if c in 'aeiou')
            vowel_ratio = vowels / len(clean_text) if len(clean_text) > 0 else 0
            
            if diversity_ratio > 0.8 and vowel_ratio < 0.2:
                return True
        
        # Check for random alphanumeric patterns
        if re.search(r'[a-zA-Z0-9]{8,}', clean_text) and len(words) <= 2:
            return True
        
        return False
    
    def detect_excessive_numbers(self, text):
        """
        Detect excessive numbers in text
        Returns penalty score
        """
        if not text:
            return 0
        
        digit_count = sum(c.isdigit() for c in text)
        total_chars = len(text.replace(' ', ''))
        
        if total_chars == 0:
            return 0
        
        digit_ratio = digit_count / total_chars
        
        if digit_ratio > 0.30:
            return 2  # High penalty
        elif digit_ratio > 0.20:
            return 1  # Medium penalty
        
        return 0
    
    def detect_suspicious_patterns(self, text):
        """
        Detect suspicious patterns in text
        Returns penalty score
        """
        if not text:
            return 0
        
        score = 0
        
        # Check for excessive punctuation
        if re.search(self.suspicious_patterns['excessive_punctuation'], text):
            score += 1
        
        # Check for excessive capitalization
        if re.search(self.suspicious_patterns['excessive_caps'], text):
            score += 1
        
        # Check for phone numbers
        if re.search(self.suspicious_patterns['phone_numbers'], text):
            score += 1
        
        # Check for email addresses
        if re.search(self.suspicious_patterns['email_addresses'], text):
            score += 1
        
        # Check for URLs
        if re.search(self.suspicious_patterns['urls'], text):
            score += 1
        
        # Check for excessive digits
        if re.search(self.suspicious_patterns['excessive_digits'], text):
            score += 1
        
        return score
    
    def calculate_keyword_score(self, text):
        """
        Calculate spam keyword score
        Returns score based on keyword matches
        """
        if not text:
            return 0, []
        
        text_lower = text.lower()
        found_keywords = []
        score = 0
        
        for keyword in self.spam_keywords:
            if keyword in text_lower:
                found_keywords.append(keyword)
                score += 1
        
        return score, found_keywords
    
    def calculate_hybrid_score(self, text):
        """
        Calculate hybrid spam score combining all detection methods
        Returns dictionary with all scores and analysis
        """
        if not text:
            return {
                'final_prediction': 'Not Spam',
                'confidence': 50.0,
                'spam_probability': 0.0,
                'risk_level': 'Low',
                'reason': 'Empty text detected',
                'keywords': [],
                'scores': {
                    'ml_score': 0.0,
                    'gibberish_score': 0,
                    'number_score': 0,
                    'pattern_score': 0,
                    'keyword_score': 0,
                    'total_score': 0
                }
            }
        
        # Get ML prediction
        ml_result = self.ml_detector.predict_spam(text)
        ml_score = ml_result['spam_probability'] if ml_result else 0.0
        
        # Calculate individual scores
        gibberish_score = 3 if self.is_gibberish(text) else 0
        number_score = self.detect_excessive_numbers(text)
        pattern_score = self.detect_suspicious_patterns(text)
        keyword_score, found_keywords = self.calculate_keyword_score(text)
        
        # Calculate total hybrid score
        total_score = ml_score + (gibberish_score * 0.1) + (number_score * 0.05) + \
                      (pattern_score * 0.05) + (keyword_score * 0.1)
        
        # Cap score at 1.0
        total_score = min(1.0, total_score)
        
        return {
            'ml_score': ml_score,
            'gibberish_score': gibberish_score,
            'number_score': number_score,
            'pattern_score': pattern_score,
            'keyword_score': keyword_score,
            'total_score': total_score,
            'found_keywords': found_keywords
        }
    
    def predict_hybrid(self, text):
        """
        Make hybrid prediction combining ML and rule-based detection
        Returns complete prediction result
        """
        # Calculate hybrid scores
        scores = self.calculate_hybrid_score(text)
        
        # Determine final prediction
        total_score = scores['total_score']
        
        # Apply decision logic
        if scores['gibberish_score'] >= 3:
            final_prediction = 'Spam'
            reason = 'Random or gibberish text detected'
            confidence = min(95.0, 50.0 + (total_score * 40))
        elif total_score >= 0.7:
            final_prediction = 'Spam'
            reason = 'Multiple spam indicators detected'
            confidence = min(98.0, 50.0 + (total_score * 45))
        elif total_score >= 0.4:
            final_prediction = 'Spam'
            if scores['found_keywords']:
                reason = f"Suspicious keywords found: {', '.join(scores['found_keywords'][:3])}"
            else:
                reason = 'Suspicious patterns detected'
            confidence = min(90.0, 50.0 + (total_score * 40))
        else:
            final_prediction = 'Ham'
            reason = 'Content appears to be legitimate'
            confidence = max(60.0, 50.0 + ((1-total_score) * 30))
        
        # Calculate risk level
        risk_level = self.get_risk_level(total_score)
        
        return {
            'prediction': final_prediction,
            'confidence': round(confidence, 2),
            'spam_probability': round(total_score * 100, 2),
            'ham_probability': round((1 - total_score) * 100, 2),
            'risk_level': risk_level,
            'reason': reason,
            'keywords': scores['found_keywords'],
            'processing_time_ms': 0,  # Will be set by API
            'model_used': 'Hybrid Detection Engine',
            'status': 'success',
            'detailed_scores': scores
        }
    
    def get_risk_level(self, spam_probability):
        """Determine risk level based on spam probability"""
        if spam_probability >= 0.7:
            return 'High'
        elif spam_probability >= 0.4:
            return 'Medium'
        else:
            return 'Low'

# Test the hybrid detector
def test_hybrid_detector():
    """Test the hybrid spam detector with various examples"""
    
    # Import ML detector (assuming it's available)
    try:
        from ml_spam_detector import SpamDatasetHandler
        ml_handler = SpamDatasetHandler()
        ml_handler.load_model()
        hybrid_detector = HybridSpamDetector(ml_handler)
    except ImportError:
        print("ML detector not available, using mock predictions")
        hybrid_detector = HybridSpamDetector(None)
    
    # Test cases
    test_cases = [
        {
            'name': 'Random Gibberish',
            'text': 'jhbdhsbkbcsk879898',
            'expected': 'Spam'
        },
        {
            'name': 'Another Gibberish',
            'text': 'asdweqweqwe123123',
            'expected': 'Spam'
        },
        {
            'name': 'Short Gibberish',
            'text': 'ksdhfksdhfksdf',
            'expected': 'Spam'
        },
        {
            'name': 'Spam with Numbers',
            'text': 'Congratulations! You won $5000 lottery click here',
            'expected': 'Spam'
        },
        {
            'name': 'Normal Email',
            'text': 'Hi team please review the attached report',
            'expected': 'Ham'
        },
        {
            'name': 'Suspicious Pattern',
            'text': 'FREE!!! WINNER!!! $$$ CLICK NOW!!!',
            'expected': 'Spam'
        },
        {
            'name': 'Mixed Content',
            'text': 'Please review the document, but act now for special offer!',
            'expected': 'Ham'  # Should lean toward legitimate due to context
        }
    ]
    
    print("🧪 Testing Hybrid Spam Detection Engine")
    print("=" * 60)
    
    for i, test_case in enumerate(test_cases, 1):
        print(f"\n{i}. {test_case['name']}")
        print(f"   Input: {test_case['text']}")
        
        result = hybrid_detector.predict_hybrid(test_case['text'])
        
        print(f"   Prediction: {result['prediction']}")
        print(f"   Confidence: {result['confidence']}%")
        print(f"   Spam Probability: {result['spam_probability']}%")
        print(f"   Risk Level: {result['risk_level']}")
        print(f"   Reason: {result['reason']}")
        print(f"   Keywords: {result['keywords']}")
        
        if 'detailed_scores' in result:
            scores = result['detailed_scores']
            print(f"   Scores:")
            print(f"     ML: {scores['ml_score']:.3f}")
            print(f"     Gibberish: {scores['gibberish_score']}")
            print(f"     Numbers: {scores['number_score']}")
            print(f"     Patterns: {scores['pattern_score']}")
            print(f"     Keywords: {scores['keyword_score']}")
            print(f"     Total: {scores['total_score']:.3f}")
        
        status = "✅" if result['prediction'] == test_case['expected'] else "❌"
        print(f"   {status} Expected: {test_case['expected']}")
    
    print("\n" + "=" * 60)
    print("🎉 Hybrid Spam Detection Engine Test Complete!")

if __name__ == "__main__":
    test_hybrid_detector()
