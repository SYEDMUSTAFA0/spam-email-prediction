#!/usr/bin/env python3
"""
SMS Spam Collection Dataset Handler
Downloads and prepares the SMS Spam Collection Dataset for training
"""

import pandas as pd
import numpy as np
import re
import nltk
from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer
from nltk.tokenize import word_tokenize
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import MultinomialNB
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
import pickle
import os
from urllib.request import urlretrieve
import zipfile

class SpamDatasetHandler:
    def __init__(self):
        self.data = None
        self.vectorizer = None
        self.model = None
        self.lemmatizer = WordNetLemmatizer()
        
        # Download required NLTK data
        self._download_nltk_data()
    
    def _download_nltk_data(self):
        """Download required NLTK data"""
        try:
            nltk.data.find('tokenizers/punkt')
            nltk.data.find('corpora/stopwords')
            nltk.data.find('corpora/wordnet')
            nltk.data.find('tokenizers/punkt_tab')
        except LookupError:
            print("📥 Downloading NLTK data...")
            nltk.download('punkt', quiet=True)
            nltk.download('punkt_tab', quiet=True)
            nltk.download('stopwords', quiet=True)
            nltk.download('wordnet', quiet=True)
            print("✅ NLTK data downloaded successfully")
    
    def download_dataset(self):
        """Download SMS Spam Collection Dataset"""
        dataset_url = "https://archive.ics.uci.edu/ml/machine-learning-databases/00228/smsspamcollection.zip"
        zip_path = "smsspamcollection.zip"
        
        if not os.path.exists(zip_path):
            print("📥 Downloading SMS Spam Collection Dataset...")
            try:
                urlretrieve(dataset_url, zip_path)
                print("✅ Dataset downloaded successfully")
            except Exception as e:
                print(f"❌ Error downloading dataset: {e}")
                return False
        
        # Extract dataset
        try:
            with zipfile.ZipFile(zip_path, 'r') as zip_ref:
                zip_ref.extractall('.')
            print("✅ Dataset extracted successfully")
            return True
        except Exception as e:
            print(f"❌ Error extracting dataset: {e}")
            return False
    
    def load_dataset(self):
        """Load and prepare the dataset"""
        # Try to load the extracted dataset
        dataset_file = "SMSSpamCollection"
        
        if not os.path.exists(dataset_file):
            # If extraction failed, create a sample dataset
            print("⚠️  Creating sample dataset...")
            self._create_sample_dataset()
            dataset_file = "spam_dataset.csv"
        
        try:
            # Load the dataset
            if dataset_file.endswith('.csv'):
                self.data = pd.read_csv(dataset_file)
            else:
                # For the original UCI dataset format
                self.data = pd.read_csv(dataset_file, sep='\t', header=None, names=['label', 'message'])
            
            print(f"✅ Dataset loaded successfully: {len(self.data)} messages")
            print(f"   Spam messages: {len(self.data[self.data['label'] == 'spam'])}")
            print(f"   Ham messages: {len(self.data[self.data['label'] == 'ham'])}")
            
            return True
        except Exception as e:
            print(f"❌ Error loading dataset: {e}")
            return False
    
    def _create_sample_dataset(self):
        """Create a sample spam dataset for demonstration"""
        sample_data = {
            'label': [
                'spam', 'spam', 'spam', 'spam', 'spam', 'spam', 'spam', 'spam', 'spam', 'spam',
                'ham', 'ham', 'ham', 'ham', 'ham', 'ham', 'ham', 'ham', 'ham', 'ham',
                'spam', 'spam', 'ham', 'ham', 'spam', 'ham', 'spam', 'ham', 'ham', 'spam'
            ],
            'message': [
                'Congratulations! You won $5000. Click here to claim prize.',
                'FREE iPhone offer! Limited time only. Act now!',
                'WIN a FREE vacation package! Call now to claim.',
                'URGENT: Your account will be suspended. Click here.',
                'Special promotion! 50% OFF on all products today.',
                'Congratulations! You have been selected for a prize.',
                'FREE money! Get $1000 instantly. No strings attached.',
                'WINNER! You won the lottery. Claim your prize now.',
                'Limited time offer! Buy now and save big.',
                'URGENT! Verify your account immediately.',
                'Hi, how are you doing today?',
                'Meeting scheduled for tomorrow at 3 PM.',
                'Please review the attached document.',
                'Thanks for your help with the project.',
                'Can we schedule a call for next week?',
                'The report is ready for your review.',
                'Looking forward to our meeting tomorrow.',
                'Please find the attachment with the details.',
                'Thanks for your email. I will get back to you.',
                'The project deadline is next Friday.',
                'Get FREE Viagra now! Limited supply.',
                'Make money fast! Guaranteed returns.',
                'Team meeting has been rescheduled to Thursday.',
                'Please confirm your attendance for the event.',
                'WIN a FREE car! Call now to claim.',
                'Your order has been shipped successfully.',
                'FREE casino bonus! Play and win big.',
                'The invoice is attached for your records.',
                'Thanks for your cooperation on this matter.',
                'URGENT: Your payment is due immediately.'
            ]
        }
        
        df = pd.DataFrame(sample_data)
        df.to_csv('spam_dataset.csv', index=False)
        print("✅ Sample dataset created successfully")
    
    def preprocess_text(self, text):
        """
        Preprocess text data:
        1. Convert to lowercase
        2. Remove URLs and special characters
        3. Tokenization
        4. Remove stopwords
        5. Lemmatization
        """
        if not isinstance(text, str):
            text = str(text)
        
        # Convert to lowercase
        text = text.lower()
        
        # Remove URLs
        text = re.sub(r'http\S+|www\S+|https\S+', '', text, flags=re.MULTILINE)
        
        # Remove email addresses
        text = re.sub(r'\S+@\S+', '', text)
        
        # Remove phone numbers
        text = re.sub(r'\b\d{3}[-.]?\d{3}[-.]?\d{4}\b', '', text)
        
        # Remove special characters and numbers, keep only letters and spaces
        text = re.sub(r'[^a-zA-Z\s]', '', text)
        
        # Tokenization
        tokens = word_tokenize(text)
        
        # Remove stopwords
        stop_words = set(stopwords.words('english'))
        tokens = [word for word in tokens if word not in stop_words]
        
        # Lemmatization
        tokens = [self.lemmatizer.lemmatize(word) for word in tokens]
        
        # Remove single characters
        tokens = [word for word in tokens if len(word) > 1]
        
        return ' '.join(tokens)
    
    def prepare_features(self):
        """Prepare features using TF-IDF Vectorizer"""
        if self.data is None:
            print("❌ No dataset loaded")
            return False
        
        # Preprocess all messages
        print("🔄 Preprocessing text data...")
        self.data['processed_message'] = self.data['message'].apply(self.preprocess_text)
        
        # Create TF-IDF features
        self.vectorizer = TfidfVectorizer(
            max_features=5000,
            ngram_range=(1, 2),  # Use bigrams as well
            min_df=2,  # Minimum document frequency
            max_df=0.95  # Maximum document frequency
        )
        
        # Convert labels to binary (spam=1, ham=0)
        y = self.data['label'].map({'spam': 1, 'ham': 0})
        
        # Create TF-IDF features
        X = self.vectorizer.fit_transform(self.data['processed_message'])
        
        print(f"✅ Features prepared: {X.shape}")
        print(f"   Vocabulary size: {len(self.vectorizer.vocabulary_)}")
        
        return X, y
    
    def train_model(self, X, y):
        """Train the Naive Bayes classifier"""
        # Split the data
        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=0.2, random_state=42, stratify=y
        )
        
        # Train the model
        print("🔄 Training Naive Bayes classifier...")
        self.model = MultinomialNB(alpha=0.1)  # Laplace smoothing
        self.model.fit(X_train, y_train)
        
        # Make predictions
        y_pred = self.model.predict(X_test)
        
        # Calculate accuracy
        accuracy = accuracy_score(y_test, y_pred)
        
        print(f"✅ Model trained successfully!")
        print(f"   Accuracy: {accuracy:.4f} ({accuracy*100:.2f}%)")
        
        # Print detailed classification report
        print("\n📊 Classification Report:")
        print(classification_report(y_test, y_pred, target_names=['Ham', 'Spam']))
        
        return accuracy
    
    def save_model(self):
        """Save the trained model and vectorizer"""
        if self.model is None or self.vectorizer is None:
            print("❌ No model to save")
            return False
        
        try:
            # Save the model
            with open('spam_model.pkl', 'wb') as f:
                pickle.dump(self.model, f)
            
            # Save the vectorizer
            with open('vectorizer.pkl', 'wb') as f:
                pickle.dump(self.vectorizer, f)
            
            print("✅ Model and vectorizer saved successfully")
            return True
        except Exception as e:
            print(f"❌ Error saving model: {e}")
            return False
    
    def load_model(self):
        """Load the trained model and vectorizer"""
        try:
            # Load the model
            with open('spam_model.pkl', 'rb') as f:
                self.model = pickle.load(f)
            
            # Load the vectorizer
            with open('vectorizer.pkl', 'rb') as f:
                self.vectorizer = pickle.load(f)
            
            print("✅ Model and vectorizer loaded successfully")
            return True
        except Exception as e:
            print(f"❌ Error loading model: {e}")
            return False
    
    def predict_spam(self, text):
        """Make prediction on new text"""
        if self.model is None or self.vectorizer is None:
            print("❌ Model not loaded")
            return None
        
        # Preprocess the text
        processed_text = self.preprocess_text(text)
        
        # Vectorize the text
        vector = self.vectorizer.transform([processed_text])
        
        # Make prediction
        prediction = self.model.predict(vector)[0]
        probability = self.model.predict_proba(vector)[0]
        
        # Convert prediction to label
        label = 'spam' if prediction == 1 else 'ham'
        confidence = max(probability)
        
        return {
            'prediction': label,
            'confidence': confidence,
            'spam_probability': probability[1],
            'ham_probability': probability[0]
        }
    
    def get_spam_keywords(self, text):
        """Extract spam keywords from text"""
        spam_keywords = [
            'free', 'win', 'prize', 'money', 'cash', 'offer', 'discount', 'promotion',
            'special', 'deal', 'save', 'cheap', 'buy', 'now', 'urgent', 'limited',
            'act now', 'click here', 'order now', 'exclusive', 'congratulations',
            'winner', 'selected', 'million', 'billion', 'claim', 'reward', 'congrats',
            'viagra', 'casino', 'poker', 'bet', 'gamble', 'xxx', 'adult', 'dating',
            'loan', 'credit', 'debt', 'investment', 'insurance', 'guaranteed', 'risk',
            'scam', 'fraud', 'phishing', 'hack', 'breach', 'instant', 'quick',
            'easy', 'fast', 'new', 'hot', 'sexy', 'suspicious', 'verify', 'confirm'
        ]
        
        text_lower = text.lower()
        found_keywords = []
        
        for keyword in spam_keywords:
            if keyword in text_lower:
                found_keywords.append(keyword)
        
        return found_keywords
    
    def get_risk_level(self, spam_probability):
        """Determine risk level based on spam probability"""
        if spam_probability >= 0.7:
            return 'high'
        elif spam_probability >= 0.4:
            return 'medium'
        else:
            return 'low'

def main():
    """Main function to train and save the spam detection model"""
    print("🚀 Starting SMS Spam Detection Model Training...")
    
    # Initialize handler
    handler = SpamDatasetHandler()
    
    # Download dataset
    if not handler.download_dataset():
        print("⚠️  Using sample dataset instead...")
    
    # Load dataset
    if not handler.load_dataset():
        print("❌ Failed to load dataset")
        return
    
    # Prepare features
    X, y = handler.prepare_features()
    if X is None:
        print("❌ Failed to prepare features")
        return
    
    # Train model
    accuracy = handler.train_model(X, y)
    if accuracy < 0.9:
        print(f"⚠️  Model accuracy ({accuracy:.2%}) is below 90%")
    else:
        print(f"🎉 Model accuracy ({accuracy:.2%}) meets target!")
    
    # Save model
    if handler.save_model():
        print("✅ Model training completed successfully!")
    else:
        print("❌ Failed to save model")
        return
    
    # Test with examples
    print("\n🧪 Testing with example messages:")
    
    test_messages = [
        "Congratulations! You won $5000. Click here to claim prize.",
        "Please review the attached document.",
        "jevdwhucwqhjbeflj3beoiu18u0398098"
    ]
    
    for message in test_messages:
        result = handler.predict_spam(message)
        if result:
            keywords = handler.get_spam_keywords(message)
            risk_level = handler.get_risk_level(result['spam_probability'])
            
            print(f"\n📧 Message: {message}")
            print(f"🔍 Prediction: {result['prediction'].upper()}")
            print(f"📊 Confidence: {result['confidence']:.2%}")
            print(f"⚠️  Risk Level: {risk_level.upper()}")
            print(f"🔑 Keywords: {keywords if keywords else 'None'}")

if __name__ == "__main__":
    main()
