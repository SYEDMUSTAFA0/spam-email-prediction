#!/usr/bin/env python
"""
Test browser simulation of the actual issue
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from app_simple import app

def test_browser_simulation():
    print("🌐 BROWSER SIMULATION TEST")
    print("=" * 50)
    
    with app.test_client() as client:
        # Step 1: Login and get session
        print("1. Testing login...")
        login_page = client.get('/login')
        import re
        page_content = login_page.data.decode('utf-8')
        
        patterns = [
            r'name="csrf_token" type="hidden" value="([^"]+)"',
            r'value="([^"]{40,})"',
            r'csrf_token.*?value="([^"]+)"'
        ]
        
        csrf_token = None
        for pattern in patterns:
            match = re.search(pattern, page_content)
            if match:
                csrf_token = match.group(1)
                break
        
        login_data = {
            'username': 'admin',
            'password': 'admin123',
            'csrf_token': csrf_token
        }
        
        login_response = client.post('/login', data=login_data, follow_redirects=False)
        
        session_cookie = None
        for cookie in login_response.headers.getlist('Set-Cookie'):
            if 'session=' in cookie:
                session_cookie = cookie.split(';')[0]
                break
        
        if not session_cookie:
            print("   ❌ Login failed")
            return
        
        headers = {'Cookie': session_cookie}
        print("   ✅ Login successful")
        
        # Step 2: Follow the redirect to get dashboard page
        print("2. Following redirect to dashboard...")
        dashboard_response = client.get(login_response.location, headers=headers, follow_redirects=True)
        print(f"   Status: {dashboard_response.status_code}")
        
        if dashboard_response.status_code != 200:
            print("   ❌ Dashboard load failed")
            return
        
        dashboard_content = dashboard_response.data.decode('utf-8')
        
        # Step 3: Test prediction with the same session
        print("3. Testing prediction...")
        prediction_response = client.post('/api/predict', 
            json={
                'email_content': 'Hello team',
                'model': 'rule_based'
            },
            headers=headers
        )
        
        print(f"   Status: {prediction_response.status_code}")
        
        if prediction_response.status_code == 200:
            result = prediction_response.get_json()
            print(f"   ✅ Prediction: {result.get('prediction')}")
            print(f"   ✅ Confidence: {result.get('confidence')}%")
        else:
            print(f"   ❌ Prediction failed: {prediction_response.data[:200]}")
        
        # Step 4: Test stats update
        print("4. Testing stats update...")
        stats_response = client.get('/api/stats', headers=headers)
        print(f"   Status: {stats_response.status_code}")
        
        if stats_response.status_code == 200:
            stats_data = stats_response.get_json()
            user_stats = stats_data.get('user_stats', {})
            print(f"   ✅ Stats: {user_stats}")
        else:
            print(f"   ❌ Stats failed: {stats_response.data[:200]}")
        
        print(f"\n🎯 BROWSER SIMULATION RESULTS:")
        print("   ✅ Login and session management working")
        print("   ✅ Dashboard page loading working")
        print("   ✅ API prediction endpoint working")
        print("   ✅ Statistics endpoint working")
        print("   ✅ All core functionality working")
        print("   ❌ Issue might be browser-specific JavaScript timing")

if __name__ == "__main__":
    test_browser_simulation()
