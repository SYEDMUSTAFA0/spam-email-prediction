#!/usr/bin/env python
"""
Test API endpoints to verify JSON responses
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import requests
import json
from urllib.parse import urlencode

def test_api_endpoints():
    print("🔧 Testing API endpoints...")
    
    base_url = "http://localhost:5000"
    session = requests.Session()
    
    # Test 1: Check if server is running
    try:
        response = session.get(base_url)
        print(f"✅ Server is running (Status: {response.status_code})")
    except Exception as e:
        print(f"❌ Server not accessible: {e}")
        return
    
    # Test 2: Login
    login_data = {
        'username': 'admin',
        'password': 'admin123'
    }
    
    try:
        response = session.post(f"{base_url}/login", data=login_data)
        print(f"Login response status: {response.status_code}")
        print(f"Login content type: {response.headers.get('content-type', 'unknown')}")
        
        if response.status_code == 302:
            print("✅ Login successful (redirect)")
        elif response.status_code == 200:
            print("ℹ️  Login returned 200 (might be form)")
        else:
            print(f"❌ Login failed: {response.text[:200]}")
            return
            
    except Exception as e:
        print(f"❌ Login error: {e}")
        return
    
    # Test 3: Predict endpoint
    predict_data = {
        'email_content': 'This is a test email with some spam content like free money and urgent offers',
        'model': 'rule_based'
    }
    
    try:
        response = session.post(f"{base_url}/predict", data=predict_data)
        print(f"Predict response status: {response.status_code}")
        print(f"Predict content type: {response.headers.get('content-type', 'unknown')}")
        
        if response.headers.get('content-type', '').startswith('application/json'):
            result = response.json()
            print(f"✅ Predict API returned JSON: {result}")
        else:
            print(f"❌ Predict API returned non-JSON: {response.text[:500]}")
            
    except Exception as e:
        print(f"❌ Predict API error: {e}")
    
    print("🔧 API testing completed!")

if __name__ == "__main__":
    test_api_endpoints()
