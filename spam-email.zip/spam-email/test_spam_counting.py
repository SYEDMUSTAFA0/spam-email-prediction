#!/usr/bin/env python
"""
Test spam counting functionality
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from app_simple import app, db, User, Prediction, classifier

def test_spam_counting():
    print("🔧 TESTING SPAM COUNTING FUNCTIONALITY")
    print("=" * 50)
    
    with app.app_context():
        # Get initial stats
        initial_stats = {
            'total': Prediction.query.count(),
            'spam': Prediction.query.filter_by(prediction='spam').count(),
            'ham': Prediction.query.filter_by(prediction='ham').count()
        }
        
        print(f"Initial stats:")
        print(f"  Total: {initial_stats['total']}")
        print(f"  Spam: {initial_stats['spam']}")
        print(f"  Ham: {initial_stats['ham']}")
        
        # Test spam predictions
        test_messages = [
            ("ACT NOW! GUARANTEED CASH REWARD!!!", "spam"),
            ("CLICK HERE FOR EXCLUSIVE DEAL!!!", "spam"),
            ("URGENT! You have won a FREE prize!", "spam"),
            ("Hi team, please review the report", "ham"),
            ("LIMITED TIME OFFER! Buy now!", "spam"),
            ("Hello, I hope this email finds you well", "ham")
        ]
        
        # Create test user if needed
        test_user = User.query.filter_by(username='testuser').first()
        if not test_user:
            test_user = User.query.filter_by(username='admin').first()  # Use admin instead
        
        # Add test predictions
        for message, expected in test_messages:
            prediction, confidence, risk = classifier.predict(message, 'rule_based')
            
            pred_record = Prediction(
                user_id=test_user.id,
                email_content=message,
                prediction=prediction,
                confidence_score=confidence,
                risk_level=risk,
                model_used='rule_based'
            )
            db.session.add(pred_record)
            
            print(f"Added: {message[:30]}... -> {prediction} ({'✅' if prediction == expected else '❌'})")
        
        db.session.commit()
        
        # Get final stats
        final_stats = {
            'total': Prediction.query.count(),
            'spam': Prediction.query.filter_by(prediction='spam').count(),
            'ham': Prediction.query.filter_by(prediction='ham').count()
        }
        
        print(f"\nFinal stats:")
        print(f"  Total: {final_stats['total']} (+{final_stats['total'] - initial_stats['total']})")
        print(f"  Spam: {final_stats['spam']} (+{final_stats['spam'] - initial_stats['spam']})")
        print(f"  Ham: {final_stats['ham']} (+{final_stats['ham'] - initial_stats['ham']})")
        
        # Calculate spam percentage
        spam_percentage = (final_stats['spam'] / final_stats['total'] * 100) if final_stats['total'] > 0 else 0
        print(f"  Spam Rate: {spam_percentage:.1f}%")
        
        print("\n🎯 SPAM COUNTING TEST COMPLETED!")

if __name__ == "__main__":
    test_spam_counting()
