#!/usr/bin/env python3

import requests
import json

# Test "hello" specifically
test_text = "hello"

print("Testing 'hello' specifically...")
print("=" * 50)
print(f"Input: '{test_text}'")

try:
    response = requests.post(
        'http://127.0.0.1:5000/api/predict_public',
        json={
            'email_content': test_text,
            'model': 'ensemble'
        },
        headers={
            'Content-Type': 'application/json'
        }
    )
    
    if response.status_code == 200:
        result = response.json()
        print(f"API Prediction: {result.get('prediction', 'N/A')}")
        print(f"API Confidence: {result.get('confidence', 'N/A')}%")
        print(f"API Risk Level: {result.get('risk_level', 'N/A')}")
        print(f"API Reason: {result.get('reason', 'N/A')}")
        print(f"Model Used: {result.get('model_used', 'N/A')}")
    else:
        print(f"ERROR: {response.status_code}")
        print(f"Response: {response.text}")
        
except Exception as e:
    print(f"ERROR: {e}")

print()
print("Debugging rule-based detection for 'hello'...")
import sys
import os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from app import rule_based_detection

prediction, confidence, risk_level, keywords = rule_based_detection(test_text)
print(f"Rule-based Prediction: {prediction}")
print(f"Rule-based Confidence: {confidence:.2f}")
print(f"Rule-based Risk Level: {risk_level}")
print(f"Rule-based Keywords: {keywords}")
