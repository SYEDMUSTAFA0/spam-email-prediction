#!/usr/bin/env python3

import sys
import os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from app import classifier

# Test the ML classifier directly
test_cases = [
    "asdfghjklqwerty",
    "Hello, this is a legitimate email",
    "FREE MONEY NOW WIN PRIZE"
]

print("Testing ML classifier directly...")
print("=" * 50)

for test_text in test_cases:
    prediction, confidence, risk_level = classifier.predict(test_text, 'ensemble')
    
    print(f"\nInput: '{test_text}'")
    print(f"ML Prediction: {prediction}")
    print(f"ML Confidence: {confidence}")
    print(f"ML Risk Level: {risk_level}")
    print("-" * 40)
