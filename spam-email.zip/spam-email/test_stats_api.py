#!/usr/bin/env python3

import requests
import json

print("Testing public stats API...")
print("=" * 40)

try:
    response = requests.get('http://127.0.0.1:5000/api/stats_public')
    
    if response.status_code == 200:
        data = response.json()
        user_stats = data.get('user_stats', {})
        
        print(f"Total Predictions: {user_stats.get('total_predictions', 0)}")
        print(f"Spam Predictions: {user_stats.get('spam_predictions', 0)}")
        print(f"Ham Predictions: {user_stats.get('ham_predictions', 0)}")
        print(f"Spam Percentage: {user_stats.get('spam_percentage', 0)}%")
    else:
        print(f"Error: {response.status_code}")
        print(f"Response: {response.text}")
        
except Exception as e:
    print(f"Error: {e}")
