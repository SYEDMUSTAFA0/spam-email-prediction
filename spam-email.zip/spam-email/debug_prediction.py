#!/usr/bin/env python
"""
Debug script to test prediction functionality
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

# Import the classifier directly
from app_simple import SimpleSpamClassifier

def test_classifier():
    print("🔧 Testing spam classifier directly...")
    
    classifier = SimpleSpamClassifier()
    
    # Test with sample spam content
    spam_text = "URGENT! You have won a FREE prize! Click now to claim your money! Limited time offer!"
    ham_text = "Hi team, please review the attached report for our upcoming meeting. Let me know if you have any questions."
    
    print(f"\nTesting spam text: '{spam_text}'")
    spam_prediction, spam_confidence, spam_risk = classifier.predict(spam_text, 'rule_based')
    print(f"Spam prediction: {spam_prediction}, confidence: {spam_confidence}, risk: {spam_risk}")
    
    print(f"\nTesting ham text: '{ham_text}'")
    ham_prediction, ham_confidence, ham_risk = classifier.predict(ham_text, 'rule_based')
    print(f"Ham prediction: {ham_prediction}, confidence: {ham_confidence}, risk: {ham_risk}")
    
    print("\n✅ Classifier test completed successfully!")

if __name__ == "__main__":
    test_classifier()
