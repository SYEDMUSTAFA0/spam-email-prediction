#!/usr/bin/env python3

import sys
import os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from app import rule_based_detection, is_email_like_content, has_proper_structure, detect_gibberish

# Test the formal email specifically
formal_email = "Dear Sir, I am writing to inquire about your services. Please let me know if you can help."

print("Debugging formal email detection...")
print("=" * 60)
print(f"Input: '{formal_email}'")
print()

# Test individual components
gibberish_score = detect_gibberish(formal_email)
email_like = is_email_like_content(formal_email)
proper_structure = has_proper_structure(formal_email)

print(f"Gibberish Score: {gibberish_score:.2f}")
print(f"Email Like: {email_like}")
print(f"Proper Structure: {proper_structure}")
print(f"Length: {len(formal_email.strip())}")
print()

# Test full detection
prediction, confidence, risk_level, keywords = rule_based_detection(formal_email)

print(f"Final Prediction: {prediction}")
print(f"Confidence: {confidence:.2f}")
print(f"Risk Level: {risk_level}")
print(f"Keywords: {keywords}")
print()

# Let's also check the spam score calculation
from app import re

def debug_spam_score(text):
    spam_keywords = ['free', 'win', 'prize', 'money', 'cash', 'urgent', 'limited', 'offer', 
                    'click', 'buy', 'now', 'guaranteed', 'risk', 'congratulations', 'lottery',
                    'winner', 'claim', 'viagra', 'cialis', 'iphone', 'discount']
    
    text_lower = text.lower()
    found_keywords = [kw for kw in spam_keywords if kw in text_lower]
    
    # Calculate spam score
    spam_score = len(found_keywords) * 0.15
    
    # Check for urgent language
    if any(urgent in text_lower for urgent in ['urgent', 'immediate', 'act now', 'hurry']):
        spam_score += 0.2
    
    # Check for money amounts
    if any(money in text_lower for money in ['$1000', '$5000', 'million', 'prize', 'award']):
        spam_score += 0.25
    
    # Check for excessive punctuation or capitalization
    if text.count('!') > 3 or text.count('?') > 2:
        spam_score += 0.1
    if sum(1 for c in text if c.isupper()) / len(text) > 0.3:
        spam_score += 0.1
    
    # Check for random strings and gibberish
    gibberish_score = detect_gibberish(text)
    spam_score += gibberish_score
    
    # Check for non-email format content
    if not is_email_like_content(text):
        spam_score += 0.3
    
    # Check for very short or very long content (suspicious)
    if len(text.strip()) < 10:
        spam_score += 0.4  # Very short content is suspicious
    elif len(text.strip()) > 1000:
        spam_score += 0.2  # Very long content might be spam
    
    # Check for lack of proper sentence structure
    if not has_proper_structure(text):
        spam_score += 0.2
    
    print(f"Spam Score Breakdown:")
    print(f"  Keywords ({len(found_keywords)}): {len(found_keywords) * 0.15}")
    print(f"  Gibberish: {gibberish_score}")
    print(f"  Not email-like: {0.3 if not email_like else 0}")
    print(f"  Length check: {0.4 if len(text.strip()) < 10 else 0}")
    print(f"  Structure check: {0.2 if not proper_structure else 0}")
    print(f"  Total spam score: {spam_score}")
    print(f"  Threshold: 0.3")
    print(f"  Is spam: {spam_score >= 0.3}")

debug_spam_score(formal_email)
