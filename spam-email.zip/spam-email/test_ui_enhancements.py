#!/usr/bin/env python3
"""
Test UI Enhancement Features
Tests the enhanced dashboard UI with proper colors and keyword display
"""

import requests
import json

def test_ui_enhancements():
    """Test the enhanced UI features"""
    base_url = "http://localhost:5000"
    
    print("🎨 Testing UI Enhancement Features")
    print("=" * 50)
    
    # Test cases for UI validation
    test_cases = [
        {
            "name": "Spam with Keywords",
            "text": "Congratulations! You won a free lottery prize",
            "expected_prediction": "Spam",
            "expected_keywords": ["free", "lottery", "prize"],
            "ui_expectations": {
                "badge_color": "red",
                "badge_text": "SPAM",
                "keywords_displayed": True
            }
        },
        {
            "name": "Normal Email",
            "text": "Please review the meeting notes attached",
            "expected_prediction": "Ham",
            "expected_keywords": [],
            "ui_expectations": {
                "badge_color": "green", 
                "badge_text": "NOT SPAM",
                "keywords_displayed": False
            }
        },
        {
            "name": "Gibberish Text",
            "text": "jhbdhsbkbcsk879898",
            "expected_prediction": "Spam",
            "expected_keywords": [],
            "ui_expectations": {
                "badge_color": "red",
                "badge_text": "SPAM", 
                "keywords_displayed": False
            }
        },
        {
            "name": "Suspicious Pattern",
            "text": "FREE!!! WINNER!!! $$$ CLICK NOW!!!",
            "expected_prediction": "Spam",
            "expected_keywords": ["free", "winner", "click"],
            "ui_expectations": {
                "badge_color": "red",
                "badge_text": "SPAM",
                "keywords_displayed": True
            }
        }
    ]
    
    for i, test_case in enumerate(test_cases, 1):
        print(f"\n{i}. {test_case['name']}")
        print(f"   Input: {test_case['text']}")
        
        try:
            response = requests.post(
                f"{base_url}/api/predict",
                json={"email_text": test_case['text']},
                headers={"Content-Type": "application/json"},
                timeout=10
            )
            
            if response.status_code == 200:
                result = response.json()
                
                print(f"   ✅ API Response:")
                print(f"      Prediction: {result['prediction']}")
                print(f"      Confidence: {result['confidence']}%")
                print(f"      Risk Level: {result['risk_level']}")
                print(f"      Keywords: {result['keywords']}")
                print(f"      Reason: {result['reason']}")
                print(f"      Model: {result['model_used']}")
                
                # Validate UI expectations
                prediction_match = result['prediction'].lower() == test_case['expected_prediction'].lower()
                
                # Check confidence format (should be 0-100)
                confidence = float(result['confidence'])
                confidence_valid = 0 <= confidence <= 100
                
                # Check keywords
                keywords_found = len(result['keywords']) > 0 if result['keywords'] else False
                keywords_expected = len(test_case['expected_keywords']) > 0
                
                print(f"   🎨 UI Validation:")
                print(f"      ✅ Prediction Correct: {prediction_match}")
                print(f"      ✅ Confidence Valid (0-100%): {confidence_valid}")
                print(f"      ✅ Keywords Found: {keywords_found}")
                print(f"      ✅ Keywords Expected: {keywords_expected}")
                
                if prediction_match and confidence_valid:
                    print(f"      🎯 UI Will Display:")
                    if result['prediction'].lower() == 'spam':
                        print(f"         🔴 RED badge: SPAM")
                    else:
                        print(f"         🟢 GREEN badge: NOT SPAM")
                    
                    if keywords_found:
                        print(f"         🏷️  Keywords: {result['keywords']}")
                    else:
                        print(f"         ℹ️  Message: 'No suspicious keywords detected'")
                else:
                    print(f"      ❌ Validation Failed")
                
            else:
                print(f"   ❌ API Error: {response.status_code}")
                print(f"   Response: {response.text}")
                
        except Exception as e:
            print(f"   ❌ Request failed: {e}")
    
    print(f"\n" + "=" * 50)
    print("🎯 UI Enhancement Features Summary:")
    print("✅ Prediction Badge Color Logic: RED for Spam, GREEN for Ham")
    print("✅ Enhanced Badge Styling: Bold, padded, bordered")
    print("✅ Smooth Animation: Fade-in effect for results")
    print("✅ Keyword Analysis: Red badges for detected keywords")
    print("✅ Fallback Message: 'No suspicious keywords detected'")
    print("✅ Confidence Fix: Proper 0-100% range")
    print("✅ Dynamic Updates: Instant UI refresh after API response")
    
    print(f"\n🚀 Expected Dashboard Behavior:")
    print("📧 Spam Example → 🔴 RED 'SPAM' badge + keyword badges")
    print("📧 Normal Email → 🟢 GREEN 'NOT SPAM' badge + fallback message")
    print("📧 Gibberish → 🔴 RED 'SPAM' badge + gibberish reason")
    
    print(f"\n🏆 UI Enhancement System Complete!")

if __name__ == "__main__":
    test_ui_enhancements()
