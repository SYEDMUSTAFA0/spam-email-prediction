#!/usr/bin/env python3

import requests
import json

# Test the API endpoint with random strings
test_cases = [
    "asdfghjklqwerty",
    "xyz123abc456", 
    "hi",
    "qwerty",
    "randomtext123",
    "Hello, this is a legitimate email",
    "FREE MONEY NOW WIN PRIZE"
]

print("Testing PUBLIC API endpoint with random strings...")
print("=" * 50)

for test_text in test_cases:
    try:
        # Make POST request to PUBLIC API endpoint
        response = requests.post(
            'http://127.0.0.1:5000/api/predict_public',
            json={
                'email_content': test_text,
                'model': 'ensemble'
            },
            headers={
                'Content-Type': 'application/json'
            }
        )
        
        if response.status_code == 200:
            result = response.json()
            print(f"\nInput: '{test_text}'")
            print(f"Prediction: {result.get('prediction', 'N/A')}")
            print(f"Confidence: {result.get('confidence', 'N/A')}%")
            print(f"Risk Level: {result.get('risk_level', 'N/A')}")
            print(f"Reason: {result.get('reason', 'N/A')}")
            print(f"Model Used: {result.get('model_used', 'N/A')}")
        else:
            print(f"\nInput: '{test_text}' - ERROR: {response.status_code}")
            print(f"Response: {response.text}")
            
    except requests.exceptions.ConnectionError:
        print(f"\nConnection error - server might not be running")
        break
    except Exception as e:
        print(f"\nInput: '{test_text}' - ERROR: {e}")
    
    print("-" * 40)
