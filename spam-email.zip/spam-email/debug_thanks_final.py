#!/usr/bin/env python
"""
Final debug of Thanks! issue
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from app_simple import EnhancedSpamDetector

def debug_thanks_final():
    print("🔧 FINAL DEBUG OF 'THANKS!' ISSUE")
    print("=" * 50)
    
    detector = EnhancedSpamDetector()
    
    text = "Thanks!"
    print(f"Text: '{text}'")
    
    # Test validation step by step
    validation = detector.validate_input(text)
    print(f"Validation result: {validation}")
    
    # Test prediction directly
    result = detector.predict(text)
    print(f"Prediction result: {result}")

if __name__ == "__main__":
    debug_thanks_final()
