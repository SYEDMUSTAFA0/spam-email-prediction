#!/usr/bin/env python
"""
Test both spam and ham detection to ensure both work properly
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from app_simple import SimpleSpamClassifier

def test_both_types():
    print("🔧 TESTING BOTH SPAM AND HAM DETECTION")
    print("=" * 50)
    
    classifier = SimpleSpamClassifier()
    
    # Test cases with expected results
    test_cases = [
        # Spam messages
        ("ACT NOW! GUARANTEED CASH REWARD!!!", "spam", "High urgency spam"),
        ("CLICK HERE FOR EXCLUSIVE DEAL!!!", "spam", "Clickbait spam"),
        ("URGENT! You have won a FREE prize!", "spam", "Prize scam spam"),
        ("LIMITED TIME OFFER! Buy now and get 50% discount!", "spam", "Commercial spam"),
        ("CONGRATULATIONS! You've been selected for a million dollar prize!", "spam", "Lottery spam"),
        ("FREE VIAGRA!!! SPECIAL PROMOTION!!!", "spam", "Adult content spam"),
        
        # Ham messages (legitimate emails)
        ("Hi team, please review the attached report for our upcoming meeting.", "ham", "Business meeting"),
        ("Hello, I hope this email finds you well. Best regards.", "ham", "Professional greeting"),
        ("Please find attached the quarterly report for your review.", "ham", "Business document"),
        ("Dear colleague, I'm writing to follow up on our discussion.", "ham", "Professional follow-up"),
        ("Thank you for your time and consideration.", "ham", "Polite closing"),
        ("The project deadline is next Friday. Please submit your updates.", "ham", "Project management"),
        ("Can we schedule a call to discuss the proposal?", "ham", "Business coordination"),
        ("Here are the meeting minutes from yesterday's session.", "ham", "Meeting documentation"),
    ]
    
    spam_correct = 0
    ham_correct = 0
    total_spam = 0
    total_ham = 0
    
    for i, (message, expected, description) in enumerate(test_cases, 1):
        print(f"\n{i}. {description}")
        print(f"   Message: {message[:50]}...")
        
        # Get prediction
        prediction, confidence, risk_level = classifier.predict(message, 'rule_based')
        
        print(f"   Expected: {expected}")
        print(f"   Predicted: {prediction}")
        print(f"   Confidence: {confidence:.2f}")
        print(f"   Risk Level: {risk_level}")
        
        # Check if correct
        is_correct = prediction == expected
        print(f"   Result: {'✅ CORRECT' if is_correct else '❌ WRONG'}")
        
        # Update counters
        if expected == "spam":
            total_spam += 1
            if is_correct:
                spam_correct += 1
        else:
            total_ham += 1
            if is_correct:
                ham_correct += 1
        
        print("-" * 50)
    
    # Calculate accuracy
    spam_accuracy = (spam_correct / total_spam * 100) if total_spam > 0 else 0
    ham_accuracy = (ham_correct / total_ham * 100) if total_ham > 0 else 0
    overall_accuracy = ((spam_correct + ham_correct) / len(test_cases) * 100)
    
    print(f"\n📊 ACCURACY RESULTS:")
    print(f"   Spam Detection: {spam_correct}/{total_spam} ({spam_accuracy:.1f}% accuracy)")
    print(f"   Ham Detection: {ham_correct}/{total_ham} ({ham_accuracy:.1f}% accuracy)")
    print(f"   Overall Accuracy: {spam_correct + ham_correct}/{len(test_cases)} ({overall_accuracy:.1f}%)")
    
    print(f"\n🎯 {'✅ BOTH SPAM AND HAM DETECTION WORKING!' if spam_accuracy >= 80 and ham_accuracy >= 80 else '❌ DETECTION NEEDS IMPROVEMENT'}")

if __name__ == "__main__":
    test_both_types()
