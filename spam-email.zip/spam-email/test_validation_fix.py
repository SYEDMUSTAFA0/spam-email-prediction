#!/usr/bin/env python3
"""
Test script to verify the over-strict validation fixes
"""

import requests
import json

def test_validation_fix():
    """Test that validation no longer blocks legitimate inputs"""
    
    base_url = "http://localhost:5000"
    
    # Test cases
    test_cases = [
        {
            "name": "Spam Input",
            "email": "Congratulations! You won $1000 lottery. Click here now.",
            "expected_prediction": "Spam"
        },
        {
            "name": "Normal Email", 
            "email": "Hi team, please review the attached report.",
            "expected_prediction": "Not Spam"
        },
        {
            "name": "Random String",
            "email": "jevdwhucwqhjbeflj3beoiu18u0398098",
            "expected_prediction": "Spam"  # Should be classified as spam, not invalid
        },
        {
            "name": "Short Input",
            "email": "Free money",
            "expected_prediction": "Spam"
        },
        {
            "name": "Empty Input",
            "email": "",
            "expected_error": "Email content cannot be empty"
        }
    ]
    
    session = requests.Session()
    
    # Try to login first
    try:
        login_response = session.post(f"{base_url}/login", data={
            "username": "admin",
            "password": "admin123"
        })
        print(f"Login status: {login_response.status_code}")
    except:
        print("Warning: Could not login - testing without authentication")
    
    print("\n🧪 TESTING VALIDATION FIXES")
    print("=" * 50)
    
    for i, test_case in enumerate(test_cases, 1):
        print(f"\n{i}. Testing: {test_case['name']}")
        print(f"   Input: '{test_case['email']}'")
        
        try:
            response = session.post(
                f"{base_url}/api/predict",
                json={
                    "email_content": test_case["email"],
                    "model": "rule_based"
                },
                headers={"Content-Type": "application/json"}
            )
            
            print(f"   Status: {response.status_code}")
            
            if response.status_code == 200:
                data = response.json()
                prediction = data.get("prediction", "unknown")
                confidence = data.get("confidence", "unknown")
                risk_level = data.get("risk_level", "unknown")
                keywords = data.get("keywords", [])
                reason = data.get("reason", "")
                
                print(f"   ✅ Prediction: {prediction}")
                print(f"   📊 Confidence: {confidence}")
                print(f"   ⚠️  Risk Level: {risk_level}")
                print(f"   🔍 Keywords: {keywords}")
                
                # Check if prediction matches expected
                if "expected_prediction" in test_case:
                    if prediction == test_case["expected_prediction"]:
                        print(f"   ✅ CORRECT - Expected {test_case['expected_prediction']}")
                    else:
                        print(f"   ❌ WRONG - Expected {test_case['expected_prediction']}, got {prediction}")
                
            elif response.status_code == 400:
                data = response.json()
                error = data.get("error", "Unknown error")
                print(f"   ⚠️  Error: {error}")
                
                if "expected_error" in test_case:
                    if error == test_case["expected_error"]:
                        print(f"   ✅ CORRECT ERROR - Expected this error")
                    else:
                        print(f"   ❌ WRONG ERROR - Expected '{test_case['expected_error']}'")
                        
            elif response.status_code == 401:
                print(f"   🔒 Authentication required")
                
            else:
                print(f"   ❌ Unexpected status: {response.status_code}")
                print(f"   Response: {response.text}")
                
        except Exception as e:
            print(f"   ❌ Exception: {e}")
    
    print("\n" + "=" * 50)
    print("🎯 VALIDATION FIX TEST COMPLETED!")
    print("\n✅ Expected Results:")
    print("   • No more 'Invalid email content' errors for legitimate inputs")
    print("   • Random strings should be classified as SPAM, not INVALID")
    print("   • Only truly empty content should return an error")
    print("   • All predictions should return proper JSON structure")

if __name__ == "__main__":
    test_validation_fix()
