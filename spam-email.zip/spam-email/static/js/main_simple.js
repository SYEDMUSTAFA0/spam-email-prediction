// Simplified JavaScript for SpamGuard AI - Production Ready

// Theme Management
function setTheme(theme) {
    try {
        // Remove all theme classes first
        document.body.classList.remove('dark-mode', 'dark', 'light-mode', 'light');
        
        if (theme === 'dark') {
            document.body.classList.add('dark-mode');
            localStorage.setItem('theme', 'dark');
        } else {
            document.body.classList.add('light-mode');
            localStorage.setItem('theme', 'light');
        }
        
        console.log('Theme set to:', theme);
    } catch (error) {
        console.error('Theme error:', error);
    }
}

// Load saved theme
document.addEventListener('DOMContentLoaded', function() {
    try {
        const savedTheme = localStorage.getItem('theme') || 'light';
        setTheme(savedTheme);
        
        // Initialize tooltips if Bootstrap is available
        if (typeof bootstrap !== 'undefined') {
            const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
            tooltipTriggerList.map(function (tooltipTriggerEl) {
                return new bootstrap.Tooltip(tooltipTriggerEl);
            });
        }
        
        console.log('Main.js loaded successfully');
    } catch (error) {
        console.error('Initialization error:', error);
    }
});

// Form Validation
function validateEmail(email) {
    try {
        const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return re.test(email);
    } catch (error) {
        console.error('Email validation error:', error);
        return false;
    }
}

function validatePassword(password) {
    try {
        const re = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*\W).{8,}$/;
        return re.test(password);
    } catch (error) {
        console.error('Password validation error:', error);
        return false;
    }
}

// Password Strength Checker
function checkPasswordStrength(password) {
    try {
        let strength = 0;
        
        if (password.length >= 8) strength++;
        if (password.length >= 12) strength++;
        if (/[a-z]/.test(password)) strength++;
        if (/[A-Z]/.test(password)) strength++;
        if (/[0-9]/.test(password)) strength++;
        if (/[^a-zA-Z0-9]/.test(password)) strength++;
        
        return strength;
    } catch (error) {
        console.error('Password strength error:', error);
        return 0;
    }
}

// Show password strength indicator
function showPasswordStrength(password, inputElement) {
    try {
        const strength = checkPasswordStrength(password);
        const strengthBar = inputElement.nextElementSibling;
        
        if (strengthBar && strengthBar.classList.contains('password-strength')) {
            let color, text;
            
            if (strength <= 2) {
                color = 'danger';
                text = 'Weak';
            } else if (strength <= 4) {
                color = 'warning';
                text = 'Medium';
            } else {
                color = 'success';
                text = 'Strong';
            }
            
            strengthBar.className = `progress password-strength mt-2`;
            strengthBar.innerHTML = `
                <div class="progress-bar bg-${color}" style="width: ${(strength / 6) * 100}%">
                    ${text}
                </div>
            `;
        }
    } catch (error) {
        console.error('Password strength display error:', error);
    }
}

// Copy to Clipboard
function copyToClipboard(text) {
    try {
        if (navigator.clipboard && navigator.clipboard.writeText) {
            navigator.clipboard.writeText(text).then(() => {
                showNotification('Copied to clipboard!', 'success', 2000);
            }).catch(err => {
                console.error('Failed to copy:', err);
                showNotification('Failed to copy to clipboard', 'error');
            });
        } else {
            // Fallback for older browsers
            const textArea = document.createElement('textarea');
            textArea.value = text;
            document.body.appendChild(textArea);
            textArea.select();
            document.execCommand('copy');
            document.body.removeChild(textArea);
            showNotification('Copied to clipboard!', 'success', 2000);
        }
    } catch (error) {
        console.error('Clipboard error:', error);
        showNotification('Copy failed', 'error');
    }
}

// Notification System
function showNotification(message, type = 'info', duration = 5000) {
    try {
        // Remove existing notifications
        const existingNotifications = document.querySelectorAll('.alert-dismissible');
        existingNotifications.forEach(notification => {
            notification.remove();
        });
        
        const notification = document.createElement('div');
        notification.className = `alert alert-${type} alert-dismissible fade show position-fixed`;
        notification.style.cssText = 'top: 20px; right: 20px; z-index: 9999; min-width: 300px;';
        notification.innerHTML = `
            ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        `;
        
        document.body.appendChild(notification);
        
        // Auto dismiss
        setTimeout(() => {
            if (notification.parentNode) {
                notification.remove();
            }
        }, duration);
    } catch (error) {
        console.error('Error showing notification:', error);
        alert(message); // Fallback to alert
    }
}

// Export Data
function exportData(format = 'csv') {
    try {
        showNotification(`Exporting data as ${format.toUpperCase()}...`, 'info');
    } catch (error) {
        console.error('Export error:', error);
        showNotification('Export failed', 'error');
    }
}

// Print Function
function printElement(elementId) {
    try {
        const element = document.getElementById(elementId);
        if (element) {
            const printWindow = window.open('', '_blank');
            printWindow.document.write(`
                <html>
                    <head>
                        <title>Print</title>
                        <style>
                            body { font-family: Arial, sans-serif; margin: 20px; }
                            table { width: 100%; border-collapse: collapse; }
                            th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
                            th { background-color: #f2f2f2; }
                        </style>
                    </head>
                    <body>
                        ${element.innerHTML}
                    </body>
                </html>
            `);
            printWindow.document.close();
            printWindow.print();
        }
    } catch (error) {
        console.error('Print error:', error);
        showNotification('Print failed', 'error');
    }
}

// Local Storage Helpers
function saveToLocalStorage(key, data) {
    try {
        localStorage.setItem(key, JSON.stringify(data));
        return true;
    } catch (error) {
        console.error('LocalStorage save error:', error);
        return false;
    }
}

function getFromLocalStorage(key, defaultValue = null) {
    try {
        const data = localStorage.getItem(key);
        return data ? JSON.parse(data) : defaultValue;
    } catch (error) {
        console.error('LocalStorage get error:', error);
        return defaultValue;
    }
}

function removeFromLocalStorage(key) {
    try {
        localStorage.removeItem(key);
        return true;
    } catch (error) {
        console.error('LocalStorage remove error:', error);
        return false;
    }
}

// Debounce Function
function debounce(func, wait) {
    try {
        let timeout;
        return function executedFunction(...args) {
            const later = () => {
                clearTimeout(timeout);
                func(...args);
            };
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
        };
    } catch (error) {
        console.error('Debounce error:', error);
        return func;
    }
}

// Throttle Function
function throttle(func, limit) {
    try {
        let inThrottle;
        return function() {
            const args = arguments;
            const context = this;
            if (!inThrottle) {
                func.apply(context, args);
                inThrottle = true;
                setTimeout(() => inThrottle = false, limit);
            }
        };
    } catch (error) {
        console.error('Throttle error:', error);
        return func;
    }
}

// Smooth Scroll
function smoothScrollTo(elementId) {
    try {
        const element = document.getElementById(elementId);
        if (element) {
            element.scrollIntoView({ behavior: 'smooth' });
        }
    } catch (error) {
        console.error('Scroll error:', error);
    }
}

// Format Date
function formatDate(date, format = 'short') {
    try {
        const options = {
            short: { year: 'numeric', month: 'short', day: 'numeric' },
            long: { year: 'numeric', month: 'long', day: 'numeric', hour: '2-digit', minute: '2-digit' },
            time: { hour: '2-digit', minute: '2-digit' }
        };
        return new Date(date).toLocaleDateString('en-US', options[format] || options.short);
    } catch (error) {
        console.error('Date format error:', error);
        return date.toString();
    }
}

// Format Number
function formatNumber(num, decimals = 0) {
    try {
        return num.toLocaleString('en-US', {
            minimumFractionDigits: decimals,
            maximumFractionDigits: decimals
        });
    } catch (error) {
        console.error('Number format error:', error);
        return num.toString();
    }
}

// Format Percentage
function formatPercentage(num, decimals = 1) {
    try {
        return `${(num * 100).toFixed(decimals)}%`;
    } catch (error) {
        console.error('Percentage format error:', error);
        return '0%';
    }
}

// File Upload Helper
function handleFileUpload(input, callback) {
    try {
        const file = input.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = function(e) {
                callback(e.target.result, file);
            };
            reader.readAsText(file);
        }
    } catch (error) {
        console.error('File upload error:', error);
        showNotification('File upload failed', 'error');
    }
}

// Utility Functions
const utils = {
    delay: (ms) => new Promise(resolve => setTimeout(resolve, ms)),
    
    randomId: () => Math.random().toString(36).substr(2, 9),
    
    slugify: (text) => {
        try {
            return text.toString().toLowerCase()
                .replace(/\s+/g, '-')
                .replace(/[^\w\-]+/g, '')
                .replace(/\-\-+/g, '-')
                .replace(/^-+/, '')
                .replace(/-+$/, '');
        } catch (error) {
            console.error('Slugify error:', error);
            return text.toString().toLowerCase();
        }
    },
    
    truncate: (text, length, suffix = '...') => {
        try {
            return text.length > length ? text.substring(0, length) + suffix : text;
        } catch (error) {
            console.error('Truncate error:', error);
            return text;
        }
    },
    
    escapeHtml: (text) => {
        try {
            const map = {
                '&': '&amp;',
                '<': '&lt;',
                '>': '&gt;',
                '"': '&quot;',
                "'": '&#039;'
            };
            return text.replace(/[&<>"']/g, m => map[m]);
        } catch (error) {
            console.error('HTML escape error:', error);
            return text;
        }
    }
};

// Global error handler
window.addEventListener('error', function(e) {
    console.error('Global JavaScript error:', e.error);
});

// Unhandled promise rejection handler
window.addEventListener('unhandledrejection', function(e) {
    console.error('Unhandled promise rejection:', e.reason);
});

console.log('Main.js loaded successfully - Production Ready');
