#!/usr/bin/env python
"""
Test different email formats to see how classifier behaves
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from app import app, classifier

def test_email_formats():
    with app.app_context():
        test_cases = [
            # Random strings
            "asdfghjkl",
            "qwertyuiop",
            
            # Proper email formats
            "Hello John,\n\nI hope this email finds you well. I wanted to follow up on our meeting from last week regarding the project timeline. Let me know if you have any questions.\n\nBest regards,\nSarah",
            
            "Hi team,\n\nPlease find attached the quarterly report for your review. The deadline for feedback is Friday at 5 PM.\n\nThanks,\nMike",
            
            "Dear Customer,\n\nThank you for your recent purchase. Your order #12345 has been shipped and should arrive within 3-5 business days.\n\nBest regards,\nCustomer Service",
            
            # Short normal messages
            "How are you doing today?",
            "See you at the meeting tomorrow",
            "Thanks for your help yesterday",
            
            # Edge cases
            "Meeting at 3pm",
            "Call me when you get this",
            "Quick question about the project"
        ]
        
        print("🧪 Testing various email formats...")
        print("=" * 80)
        
        for i, text in enumerate(test_cases, 1):
            try:
                prediction, confidence, risk_level = classifier.predict(text, 'ensemble')
                
                # Truncate long text for display
                display_text = text[:50] + "..." if len(text) > 50 else text
                display_text = display_text.replace('\n', ' ')
                
                print(f"{i:2d}. Text: '{display_text}'")
                print(f"    Prediction: {prediction}")
                print(f"    Confidence: {confidence:.3f}")
                print(f"    Risk Level: {risk_level}")
                print("-" * 60)
            except Exception as e:
                print(f"ERROR: {e}")
                print("-" * 60)

if __name__ == "__main__":
    test_email_formats()
