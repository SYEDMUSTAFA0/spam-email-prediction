#!/usr/bin/env python
"""
Debug the "Thanks!" issue
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from app_simple import EnhancedSpamDetector

def debug_thanks():
    print("🔧 DEBUGGING 'THANKS!' ISSUE")
    print("=" * 40)
    
    detector = EnhancedSpamDetector()
    
    text = "Thanks!"
    print(f"Original text: '{text}'")
    print(f"Length: {len(text)}")
    
    text_stripped = text.strip()
    print(f"Stripped text: '{text_stripped}'")
    print(f"Stripped length: {len(text_stripped)}")
    
    # Test validation step by step
    print(f"\n🔍 VALIDATION STEPS:")
    
    # Step 1: Empty check
    if not text_stripped:
        print("❌ Failed: Empty input")
        return
    else:
        print("✅ Passed: Empty check")
    
    # Step 2: Length check
    if len(text_stripped) < 3:
        print(f"❌ Failed: Length check (len={len(text_stripped)} < 3)")
        return
    else:
        print("✅ Passed: Length check")
    
    # Step 3: Gibberish check
    gibberish_result = detector._is_gibberish(text_stripped)
    if gibberish_result['is_gibberish'] and len(text_stripped) > 20:
        print(f"❌ Failed: Gibberish check")
        return
    else:
        print("✅ Passed: Gibberish check")
    
    # Step 4: Excessive numbers check
    if detector._has_excessive_numbers(text_stripped):
        print(f"❌ Failed: Excessive numbers")
        return
    else:
        print("✅ Passed: Excessive numbers")
    
    # Step 5: Excessive symbols check
    if detector._has_excessive_symbols(text_stripped):
        print(f"❌ Failed: Excessive symbols")
        return
    else:
        print("✅ Passed: Excessive symbols")
    
    # Step 6: Word count check
    words = text_stripped.split()
    if len(words) < 2:
        print(f"❌ Failed: Word count (words={len(words)} < 2)")
        return
    else:
        print("✅ Passed: Word count")
    
    print(f"\n✅ All validation passed!")
    
    # Test prediction
    result = detector.predict(text)
    print(f"Prediction: {result['prediction']}")
    print(f"Confidence: {result['confidence']}%")
    
    if 'error' in result:
        print(f"Error: {result['error']}")

if __name__ == "__main__":
    debug_thanks()
