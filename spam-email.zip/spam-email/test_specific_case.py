#!/usr/bin/env python
"""
Test the specific case the user provided
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from app_simple import SimpleSpamClassifier

def test_specific_case():
    print("🔧 TESTING SPECIFIC USER CASE")
    print("=" * 50)
    
    classifier = SimpleSpamClassifier()
    
    # Test the exact message the user provided
    user_message = "902y3109r1v ohf kno13hub2-018739-219ep# D\\"
    
    print(f"Testing message: '{user_message}'")
    print(f"Message length: {len(user_message)}")
    
    # Test preprocessing
    processed = classifier.preprocess_text(user_message)
    print(f"Processed: '{processed}'")
    
    # Test scoring
    spam_score = classifier.calculate_spam_score(user_message)
    print(f"Spam score: {spam_score}")
    
    # Test prediction
    prediction, confidence, risk = classifier.predict(user_message, 'rule_based')
    print(f"Prediction: {prediction}")
    print(f"Confidence: {confidence}")
    print(f"Risk level: {risk}")
    
    # Analyze why it's not spam
    print("\n🔍 ANALYSIS:")
    print("  - Contains random characters: ✅")
    print("  - Contains numbers mixed with letters: ✅") 
    print("  - Contains special characters: ✅")
    print("  - Contains backslash: ✅")
    print("  - Current prediction: ❌ Should be SPAM")
    
    # Check what indicators are found
    text_lower = user_message.lower()
    print(f"\n📋 INDICATOR CHECK:")
    print(f"  Text lower: '{text_lower}'")
    
    # Check for random patterns
    import re
    has_numbers = bool(re.search(r'\d', user_message))
    has_special = bool(re.search(r'[^a-zA-Z0-9\s]', user_message))
    has_random = bool(re.search(r'[0-9]+[a-z]+[0-9]+', user_message.lower()))
    
    print(f"  Has numbers: {has_numbers}")
    print(f"  Has special chars: {has_special}")
    print(f"  Has random pattern: {has_random}")

if __name__ == "__main__":
    test_specific_case()
