from flask import Flask, render_template, request, jsonify, redirect, url_for, flash, session
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, login_user, logout_user, login_required, current_user
from flask_wtf.csrf import CSRFProtect, CSRFError
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime
import os
import pickle
import re
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.naive_bayes import MultinomialNB
from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVC
from sklearn.metrics import accuracy_score, classification_report
import nltk
from nltk.corpus import stopwords
from nltk.stem import PorterStemmer
import pandas as pd
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

app = Flask(__name__)
app.config.from_object('config')

# Fallback database configuration
if not app.config.get('SQLALCHEMY_DATABASE_URI'):
    app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///spam_email.db'

# Fallback secret key
if not app.config.get('SECRET_KEY') or app.config.get('SECRET_KEY') == 'your-secret-key-here-change-in-production':
    app.config['SECRET_KEY'] = 'dev-secret-key-change-in-production'

db = SQLAlchemy(app)
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'
csrf = CSRFProtect(app)

# Download NLTK data
try:
    nltk.data.find('tokenizers/punkt')
    nltk.data.find('corpora/stopwords')
except LookupError:
    nltk.download('punkt')
    nltk.download('stopwords')

# Database Models
class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(128), nullable=False)
    is_admin = db.Column(db.Boolean, default=False)
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    predictions = db.relationship('Prediction', backref='user', lazy=True)
    
    def set_password(self, password):
        self.password_hash = generate_password_hash(password)
    
    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

class Prediction(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    email_content = db.Column(db.Text, nullable=False)
    prediction = db.Column(db.String(10), nullable=False)  # 'spam' or 'ham'
    confidence_score = db.Column(db.Float, nullable=False)
    risk_level = db.Column(db.String(10), nullable=False)  # 'low', 'medium', 'high'
    model_used = db.Column(db.String(50), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class SpamDataset(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    email_text = db.Column(db.Text, nullable=False)
    label = db.Column(db.String(10), nullable=False)  # 'spam' or 'ham'
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

# ML Models
class SpamClassifier:
    def __init__(self):
        self.models = {}
        self.vectorizer = None
        self.stemmer = PorterStemmer()
        self.stop_words = set(stopwords.words('english'))
        self.load_models()
    
    def preprocess_text(self, text):
        # Convert to lowercase
        text = text.lower()
        # Remove special characters and numbers
        text = re.sub(r'[^a-zA-Z\s]', '', text)
        # Tokenize
        tokens = nltk.word_tokenize(text)
        # Remove stopwords and stem
        tokens = [self.stemmer.stem(token) for token in tokens if token not in self.stop_words]
        return ' '.join(tokens)
    
    def train_models(self, dataset_path=None):
        # Load or create dataset
        if dataset_path and os.path.exists(dataset_path):
            df = pd.read_csv(dataset_path)
        else:
            # Use database data
            spam_data = SpamDataset.query.all()
            if len(spam_data) < 100:
                # Create sample dataset if not enough data
                return self.create_sample_dataset()
            
            df = pd.DataFrame([(d.email_text, d.label) for d in spam_data], 
                             columns=['email_text', 'label'])
        
        # Preprocess
        df['processed_text'] = df['email_text'].apply(self.preprocess_text)
        
        # Feature extraction
        self.vectorizer = TfidfVectorizer(max_features=5000)
        X = self.vectorizer.fit_transform(df['processed_text'])
        y = df['label']
        
        # Train models
        self.models['naive_bayes'] = MultinomialNB().fit(X, y)
        self.models['logistic_regression'] = LogisticRegression(random_state=42).fit(X, y)
        self.models['svm'] = SVC(probability=True, random_state=42).fit(X, y)
        
        # Save models
        self.save_models()
        return True
    
    def predict(self, text, model_name='ensemble'):
        if not self.models or not self.vectorizer:
            return None, None, None
        
        processed_text = self.preprocess_text(text)
        X = self.vectorizer.transform([processed_text])
        
        if model_name == 'ensemble':
            # Use all models and average the predictions
            predictions = []
            confidences = []
            
            for name, model in self.models.items():
                pred = model.predict(X)[0]
                conf = model.predict_proba(X)[0].max()
                predictions.append(pred)
                confidences.append(conf)
            
            # Convert string predictions to numeric for voting
            numeric_predictions = []
            for pred in predictions:
                if isinstance(pred, str):
                    numeric_predictions.append(1 if pred.lower() == 'spam' else 0)
                else:
                    numeric_predictions.append(int(pred))
            
            # Majority voting for prediction
            final_pred = max(set(numeric_predictions), key=numeric_predictions.count)
            avg_confidence = np.mean(confidences)
        else:
            if model_name not in self.models:
                model_name = 'naive_bayes'
            
            model = self.models[model_name]
            final_pred = model.predict(X)[0]
            avg_confidence = model.predict_proba(X)[0].max()
        
        # Determine risk level based on confidence (0-1 scale)
        confidence_percent = avg_confidence * 100
        
        if confidence_percent >= 70:
            risk_level = 'high'
        elif confidence_percent >= 40:
            risk_level = 'medium'
        else:
            risk_level = 'low'
        
        # Convert numeric prediction to text label
        prediction_label = 'spam' if final_pred == 1 else 'not spam'
        
        # Override risk if prediction is spam
        if prediction_label == 'spam' and risk_level == 'low':
            risk_level = 'medium'
        
        return prediction_label, avg_confidence, risk_level
    
    def save_models(self):
        os.makedirs('models', exist_ok=True)
        with open('models/vectorizer.pkl', 'wb') as f:
            pickle.dump(self.vectorizer, f)
        
        for name, model in self.models.items():
            with open(f'models/{name}.pkl', 'wb') as f:
                pickle.dump(model, f)
    
    def load_models(self):
        try:
            print("Loading models...")
            with open('models/vectorizer.pkl', 'rb') as f:
                self.vectorizer = pickle.load(f)
            print("Vectorizer loaded successfully")
            
            model_files = ['naive_bayes.pkl', 'logistic_regression.pkl', 'svm.pkl']
            for model_file in model_files:
                model_name = model_file.replace('.pkl', '')
                if os.path.exists(f'models/{model_file}'):
                    with open(f'models/{model_file}', 'rb') as f:
                        self.models[model_name] = pickle.load(f)
                    print(f"Model {model_name} loaded successfully")
                else:
                    print(f"Model file {model_file} not found")
            print(f"Total models loaded: {len(self.models)}")
        except Exception as e:
            print(f"Error loading models: {e}")
            pass  # Models not found, will be trained on first run
    
    def create_sample_dataset(self):
        sample_emails = [
            ("Congratulations! You've won a $1,000,000 lottery prize. Click here to claim.", "spam"),
            ("Get cheap viagra now! Limited time offer!", "spam"),
            ("URGENT: Your account will be suspended. Please update your information.", "spam"),
            ("Meeting tomorrow at 2 PM in conference room B", "ham"),
            ("Can you send me the report by end of day?", "ham"),
            ("Happy birthday! Hope you have a wonderful day.", "ham"),
            ("FREE IPHONE! Click here to get your free gift", "spam"),
            ("Your order has been shipped and will arrive in 3-5 business days", "ham"),
            ("Make $1000/day working from home! No experience needed!", "spam"),
            ("Don't forget about our team lunch this Friday", "ham")
        ]
        
        for email_text, label in sample_emails:
            dataset = SpamDataset(email_text=email_text, label=label)
            db.session.add(dataset)
        
        db.session.commit()
        return self.train_models()

# Initialize classifier
classifier = SpamClassifier()

# Routes
@app.route('/')
def index():
    return render_template('index.html')

@app.route('/about')
def about():
    return render_template('about.html')

@app.route('/how_it_works')
def how_it_works():
    return render_template('how_it_works.html')

@app.route('/statistics')
@login_required
def statistics():
    return render_template('statistics.html')

@app.route('/contact')
def contact():
    return render_template('contact.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        
        user = User.query.filter_by(username=username).first()
        
        if user and user.check_password(password) and user.is_active:
            login_user(user, remember=True)
            next_page = request.args.get('next')
            return redirect(next_page) if next_page else redirect(url_for('dashboard'))
        else:
            flash('Invalid username or password', 'error')
    
    return render_template('login.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form.get('username')
        email = request.form.get('email')
        password = request.form.get('password')
        
        if User.query.filter_by(username=username).first():
            flash('Username already exists', 'error')
            return render_template('register.html')
        
        if User.query.filter_by(email=email).first():
            flash('Email already registered', 'error')
            return render_template('register.html')
        
        user = User(username=username, email=email)
        user.set_password(password)
        db.session.add(user)
        db.session.commit()
        
        flash('Registration successful! Please log in.', 'success')
        return redirect(url_for('login'))
    
    return render_template('register.html')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('index'))

@app.route('/dashboard')
def dashboard():
    # Temporarily remove login requirement for testing
    if current_user.is_authenticated and current_user.is_admin:
        return redirect(url_for('admin_dashboard'))
    return render_template('dashboard.html')

@app.route('/api/predict', methods=['POST'])
@login_required
def api_predict():
    print(f"API predict called. Request JSON: {request.is_json}")
    if not request.is_json:
        return jsonify({'error': 'Content-Type must be application/json'}), 400
    
    data = request.get_json()
    print(f"Received data: {data}")
    email_content = data.get('email_content', '')
    model_name = data.get('model', 'ensemble')
    
    print(f"Email content: '{email_content}'")
    print(f"Model: {model_name}")
    
    if not email_content.strip():
        return jsonify({'error': 'Email content is required'}), 400
    
    # Get ML prediction
    prediction, confidence, risk_level = classifier.predict(email_content, model_name)
    
    if prediction is None:
        # Fallback to rule-based detection
        prediction, confidence, risk_level, keywords = rule_based_detection(email_content)
        model_used = 'rule_based'
    else:
        # Extract keywords from the email
        keywords = extract_spam_keywords(email_content)
        model_used = model_name
    
    # Determine reason
    # Apply smart spam detection logic
    if prediction == 'spam':
        # Check for high confidence spam (clear spam)
        if confidence >= 0.7:
            # High confidence spam - keep as spam
            reason = "High confidence spam detection based on multiple factors"
        # Check for random/keyboard mashing patterns (always treat as spam)
        elif any(pattern in email_content.lower() for pattern in ['qwerty', 'asdf', 'zxcv']) or \
             re.search(r'^[a-zA-Z]{10,}$', email_content):
            # Random patterns - always treat as spam
            reason = "Contains random character patterns - indicative of spam"
        # Check for medium confidence with spam indicators
        elif confidence >= 0.55 and any(indicator in email_content.lower() for indicator in [
            'free', 'win', 'prize', 'money', 'urgent', 'click', 'buy', 'now', 
            'limited', 'offer', 'discount', 'viagra', 'lottery', 'winner'
        ]):
            # Medium confidence with spam keywords - keep as spam
            reason = "Suspicious promotional keywords detected"
        # Low confidence but short/random - treat as spam
        elif confidence < 0.6 and len(email_content.strip()) < 20:
            # Check if it's a common legitimate word/phrase
            legitimate_words = [
                'hello', 'hi', 'hey', 'thanks', 'thank you', 'bye', 'goodbye',
                'ok', 'okay', 'yes', 'no', 'please', 'sorry', 'welcome',
                'morning', 'afternoon', 'evening', 'night', 'day', 'today',
                'meeting', 'call', 'email', 'message', 'note', 'update'
            ]
            
            if email_content.lower().strip() in legitimate_words:
                prediction = 'not spam'
                risk_level = 'low'
                confidence = 0.95
                reason = "Common legitimate greeting or phrase"
            else:
                prediction = 'spam'
                reason = "Short suspicious content - likely spam"
        # Low confidence or no clear spam indicators - treat as legitimate
        else:
            prediction = 'not spam'
            risk_level = 'low'
            confidence = 0.95
            reason = "Content appears to be legitimate"
    else:
        # Not spam - determine appropriate reason
        if confidence < 0.6:
            reason = "Appears to be legitimate but lacks clear context"
        elif confidence < 0.8:
            reason = "Email appears to be legitimate"
        else:
            reason = "Email appears to be legitimate with proper structure"
    
    # Save prediction to database
    prediction_record = Prediction(
        user_id=current_user.id,
        email_content=email_content,
        prediction=prediction,
        confidence_score=confidence,
        risk_level=risk_level,
        model_used=model_used
    )
    db.session.add(prediction_record)
    db.session.commit()
    
    return jsonify({
        'prediction': prediction,
        'confidence': round(confidence * 100, 1),
        'risk_level': risk_level.title(),
        'reason': reason,
        'keywords': keywords,
        'model_used': model_used
    })

@app.route('/api/predict_public', methods=['POST'])
@csrf.exempt
def api_predict_public():
    """Public API endpoint for testing without authentication"""
    
    if not request.is_json:
        return jsonify({'error': 'Content-Type must be application/json'}), 400
    
    data = request.get_json()
    email_content = data.get('email_content', '')
    model_name = data.get('model', 'ensemble')
    
    if not email_content.strip():
        return jsonify({'error': 'Email content is required'}), 400
    
    # PRIORITY: Use rule-based detection first for more accurate results
    prediction, confidence, risk_level, keywords = rule_based_detection(email_content)
    model_used = 'rule_based'
    
    # Only use ML as backup for very obvious spam cases that rule-based might miss
    # Don't use ML for content that already looks like legitimate email
    if len(email_content.strip()) > 50 and not is_email_like_content(email_content):
        # For longer content that doesn't look like email, try ML as backup
        ml_prediction, ml_confidence, ml_risk_level = classifier.predict(email_content, model_name)
        if ml_prediction is not None and ml_confidence > 0.8:
            # Only use ML if it's VERY confident and rule-based is uncertain
            if prediction == 'spam' and confidence < 0.8:
                prediction = ml_prediction
                confidence = ml_confidence
                risk_level = ml_risk_level
                model_used = model_name
                keywords = extract_spam_keywords(email_content)
    
    # Determine reason
    if prediction == 'spam':
        # Check for specific reasons in order of priority
        if len(email_content.strip()) < 10:
            reason = "Content too short - appears to be incomplete or suspicious"
        elif any(pattern in email_content.lower() for pattern in ['qwerty', 'asdf', 'zxcv']):
            reason = "Contains keyboard mashing patterns - typical of spam/bots"
        elif re.search(r'^[a-zA-Z]{10,}$', email_content) and not re.search(r'[aeiou]', email_content.lower()):
            reason = "Contains random character sequences with no vowels - indicative of spam"
        elif re.search(r'[a-zA-Z]{3,}[0-9]{3,}|[0-9]{3,}[a-zA-Z]{3,}', email_content):
            reason = "Contains suspicious mixed alphanumeric patterns - common in spam"
        elif detect_gibberish(email_content) > 0.3:
            reason = "Content appears to be random gibberish - not legitimate email format"
        elif not is_email_like_content(email_content):
            reason = "Content does not follow proper email format or structure"
        elif not has_proper_structure(email_content):
            reason = "Lacks proper sentence structure - suspicious formatting"
        elif keywords:
            reason = f"Suspicious promotional keywords detected: {', '.join(keywords[:3])}"
        else:
            reason = "Multiple suspicious patterns detected - content appears to be spam"
    else:
        reason = "Email appears to be legitimate with proper structure and content"
    
    return jsonify({
        'prediction': prediction,
        'confidence': round(confidence * 100, 1),
        'risk_level': risk_level.title(),
        'reason': reason,
        'keywords': keywords,
        'model_used': model_used
    })

def rule_based_detection(text):
    """Enhanced rule-based spam detection"""
    spam_keywords = ['free', 'win', 'prize', 'money', 'cash', 'urgent', 'limited', 'offer', 
                    'click', 'buy', 'now', 'guaranteed', 'risk', 'congratulations', 'lottery',
                    'winner', 'claim', 'viagra', 'cialis', 'iphone', 'discount']
    
    text_lower = text.lower()
    found_keywords = [kw for kw in spam_keywords if kw in text_lower]
    
    # Calculate spam score
    spam_score = len(found_keywords) * 0.15
    
    # Check for urgent language
    if any(urgent in text_lower for urgent in ['urgent', 'immediate', 'act now', 'hurry']):
        spam_score += 0.2
    
    # Check for money amounts
    if any(money in text_lower for money in ['$1000', '$5000', 'million', 'prize', 'award']):
        spam_score += 0.25
    
    # Check for excessive punctuation or capitalization
    if text.count('!') > 3 or text.count('?') > 2:
        spam_score += 0.1
    if sum(1 for c in text if c.isupper()) / len(text) > 0.3:
        spam_score += 0.1
    
    # NEW: Check for random strings and gibberish
    gibberish_score = detect_gibberish(text)
    spam_score += gibberish_score
    
    # NEW: Check for non-email format content
    if not is_email_like_content(text):
        spam_score += 0.3
    
    # NEW: Check for very short or very long content (suspicious)
    if len(text.strip()) < 5:
        spam_score += 0.4  # Extremely short content is suspicious
    elif len(text.strip()) < 10 and not is_email_like_content(text):
        spam_score += 0.3  # Short non-email content is suspicious
    elif len(text.strip()) > 1000:
        spam_score += 0.2  # Very long content might be spam
    
    # NEW: Check for lack of proper sentence structure
    if not has_proper_structure(text):
        spam_score += 0.2
    
    # Make prediction - LOWERED THRESHOLD from 0.6 to 0.3
    if spam_score >= 0.3:
        prediction = 'spam'
        confidence = min(spam_score + 0.2, 0.95)
        confidence_percent = confidence * 100
        if confidence_percent >= 70:
            risk_level = 'high'
        elif confidence_percent >= 40:
            risk_level = 'medium'
        else:
            risk_level = 'medium'  # Spam should never be low
    else:
        prediction = 'not spam'
        confidence = min((1 - spam_score) + 0.1, 0.95)
        confidence_percent = confidence * 100
        if confidence_percent >= 70:
            risk_level = 'high'
        elif confidence_percent >= 40:
            risk_level = 'medium'
        else:
            risk_level = 'low'
    
    return prediction, confidence, risk_level, found_keywords

def detect_gibberish(text):
    """Detect if text contains random strings or gibberish"""
    score = 0
    
    # Check for random character sequences
    words = text.split()
    random_word_count = 0
    
    for word in words:
        # Remove common punctuation
        clean_word = re.sub(r'[^\w]', '', word)
        
        # Check for random consonant sequences
        if len(clean_word) > 3:
            consonant_ratio = sum(1 for c in clean_word.lower() if c not in 'aeiou') / len(clean_word)
            if consonant_ratio > 0.8:  # Too many consonants
                random_word_count += 1
            
            # Check for repeated characters
            if re.search(r'(.)\1{2,}', clean_word):  # 3+ repeated chars
                random_word_count += 1
            
            # Check for keyboard mashing (qwerty, asdf, etc.)
            if re.search(r'(qwerty|asdf|zxcv|1234|abcd)', clean_word.lower()):
                random_word_count += 1
    
    # If more than 30% of words seem random, add to score
    if len(words) > 0 and random_word_count / len(words) > 0.3:
        score += 0.4
    
    # Check for completely random strings
    if re.search(r'^[a-zA-Z]{10,}$', text) and not re.search(r'[aeiou]', text.lower()):
        score += 0.5  # Long string with no vowels
    
    # Check for mixed random characters and numbers
    if re.search(r'[a-zA-Z]{3,}[0-9]{3,}|[0-9]{3,}[a-zA-Z]{3,}', text):
        score += 0.3
    
    return score

def is_email_like_content(text):
    """Check if content resembles an email message"""
    text_lower = text.lower()
    
    # Email indicators
    email_indicators = [
        'dear', 'hello', 'hi', 'regards', 'sincerely', 'best regards',
        'thank you', 'thanks', 'please', 'from', 'to', 'subject',
        'message', 'email', 'mail', 'contact', 'reply', 'send',
        'inquire', 'inquiry', 'writing', 'services', 'help'
    ]
    
    # Check for email-like structure
    has_greeting = any(indicator in text_lower for indicator in ['dear', 'hello', 'hi'])
    has_closing = any(indicator in text_lower for indicator in ['regards', 'sincerely', 'thanks', 'thank you'])
    has_email_terms = any(indicator in text_lower for indicator in email_indicators)
    
    # Check for proper sentences (basic check)
    sentences = re.split(r'[.!?]+', text)
    proper_sentences = sum(1 for s in sentences if len(s.strip()) > 10 and s.strip()[0].isupper())
    
    # Check for formal/business language
    formal_indicators = any(indicator in text_lower for indicator in [
        'writing', 'inquire', 'inquiry', 'services', 'business', 'professional',
        'meeting', 'appointment', 'discussion', 'proposal', 'information'
    ])
    
    # More lenient check - if it has multiple email characteristics, it's probably legitimate
    email_score = 0
    if has_greeting: email_score += 1
    if has_closing: email_score += 1
    if has_email_terms: email_score += 1
    if proper_sentences >= 2: email_score += 1
    if formal_indicators: email_score += 1
    
    # Special case: Common greetings like "hello" should be considered email-like
    if text.strip().lower() in ['hello', 'hi', 'dear', 'hey']:
        email_score = max(email_score, 2)  # Ensure it passes the threshold
    
    return email_score >= 2

def has_proper_structure(text):
    """Check if text has proper sentence/paragraph structure"""
    # Basic checks for proper structure
    has_capital_start = any(sentence.strip() and sentence.strip()[0].isupper() 
                           for sentence in re.split(r'[.!?]+', text))
    
    # Check for reasonable word lengths (not too many extremely short/long words)
    words = text.split()
    if len(words) == 0:
        return False
    
    avg_word_length = sum(len(word) for word in words) / len(words)
    
    # Very short or very long average word length is suspicious
    if avg_word_length < 2 or avg_word_length > 15:
        return False
    
    # Check for punctuation (some punctuation is normal)
    has_punctuation = bool(re.search(r'[.!?]', text))
    
    # More lenient check - if it has capitalization and reasonable words, it's probably fine
    return has_capital_start and (2 <= avg_word_length <= 10)

def extract_spam_keywords(text):
    """Extract spam keywords from text"""
    spam_keywords = ['free', 'win', 'prize', 'money', 'cash', 'urgent', 'limited', 'offer', 
                    'click', 'buy', 'now', 'guaranteed', 'risk', 'congratulations', 'lottery',
                    'winner', 'claim', 'viagra', 'cialis', 'iphone', 'discount']
    
    text_lower = text.lower()
    found_keywords = [kw for kw in spam_keywords if kw in text_lower]
    return found_keywords[:10]  # Limit to 10 keywords

@app.route('/predict', methods=['POST'])
@login_required
def predict():
    email_content = request.form.get('email_content')
    model_name = request.form.get('model', 'ensemble')
    
    if not email_content:
        return jsonify({'error': 'Email content is required'}), 400
    
    prediction, confidence, risk_level = classifier.predict(email_content, model_name)
    
    if prediction is None:
        return jsonify({'error': 'Models not trained yet'}), 500
    
    # Save prediction to database
    prediction_record = Prediction(
        user_id=current_user.id,
        email_content=email_content,
        prediction=prediction,
        confidence_score=confidence,
        risk_level=risk_level,
        model_used=model_name
    )
    db.session.add(prediction_record)
    db.session.commit()
    
    return jsonify({
        'prediction': prediction,
        'confidence': confidence,
        'risk_level': risk_level,
        'model_used': model_name
    })

@app.route('/api/stats')
@login_required
def api_stats():
    # Get user's prediction statistics
    user_predictions = Prediction.query.filter_by(user_id=current_user.id).all()
    
    total_predictions = len(user_predictions)
    spam_predictions = len([p for p in user_predictions if p.prediction == 'spam'])
    ham_predictions = len([p for p in user_predictions if p.prediction == 'ham'])
    spam_percentage = (spam_predictions / total_predictions * 100) if total_predictions > 0 else 0
    
    # Get overall system stats
    total_system_predictions = Prediction.query.count()
    total_system_spam = Prediction.query.filter_by(prediction='spam').count()
    total_system_ham = Prediction.query.filter_by(prediction='ham').count()
    
    return jsonify({
        'user_stats': {
            'total_predictions': total_predictions,
            'spam_predictions': spam_predictions,
            'ham_predictions': ham_predictions,
            'spam_percentage': round(spam_percentage, 1)
        },
        'system_stats': {
            'total_predictions': total_system_predictions,
            'spam_predictions': total_system_spam,
            'ham_predictions': total_system_ham
        }
    })

@app.route('/api/stats_public')
def api_stats_public():
    """Public stats endpoint for testing without authentication"""
    # Get overall system stats (no user filtering)
    total_system_predictions = Prediction.query.count()
    total_system_spam = Prediction.query.filter_by(prediction='spam').count()
    total_system_ham = Prediction.query.filter_by(prediction='ham').count()
    
    # For demo purposes, create mock user stats
    spam_percentage = (total_system_spam / total_system_predictions * 100) if total_system_predictions > 0 else 0
    
    return jsonify({
        'user_stats': {
            'total_predictions': min(total_system_predictions, 100),  # Cap for demo
            'spam_predictions': min(total_system_spam, 50),
            'ham_predictions': min(total_system_ham, 50),
            'spam_percentage': round(spam_percentage, 1)
        },
        'system_stats': {
            'total_predictions': total_system_predictions,
            'spam_predictions': total_system_spam,
            'ham_predictions': total_system_ham
        }
    })

@app.route('/history')
@login_required
def history():
    predictions = Prediction.query.filter_by(user_id=current_user.id).order_by(Prediction.created_at.desc()).limit(50).all()
    return render_template('history.html', predictions=predictions)

@app.route('/admin')
@login_required
def admin_dashboard():
    if not current_user.is_admin:
        return redirect(url_for('dashboard'))
    
    total_users = User.query.count()
    total_predictions = Prediction.query.count()
    spam_predictions = Prediction.query.filter_by(prediction='spam').count()
    ham_predictions = Prediction.query.filter_by(prediction='ham').count()
    
    recent_predictions = Prediction.query.order_by(Prediction.created_at.desc()).limit(10).all()
    users = User.query.all()
    
    return render_template('admin/dashboard.html', 
                         total_users=total_users,
                         total_predictions=total_predictions,
                         spam_predictions=spam_predictions,
                         ham_predictions=ham_predictions,
                         recent_predictions=recent_predictions,
                         users=users)

@app.route('/admin/train_model', methods=['POST'])
@login_required
def train_model():
    if not current_user.is_admin:
        return jsonify({'error': 'Unauthorized'}), 403
    
    success = classifier.train_models()
    if success:
        return jsonify({'message': 'Model trained successfully'})
    else:
        return jsonify({'error': 'Failed to train model'}), 500

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
        # Train models if not exists
        if not classifier.models:
            classifier.train_models()
    app.run(debug=True)
