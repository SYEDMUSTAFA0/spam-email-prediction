#!/usr/bin/env python
"""
Simple test of prediction endpoint
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from app_simple import app

def test_simple_prediction():
    print("🔧 SIMPLE PREDICTION TEST")
    print("=" * 40)
    
    with app.test_client() as client:
        # Test 1: Check if server is running
        response = client.get('/')
        print(f"1. Server status: {response.status_code}")
        
        # Test 2: Get login page
        login_page = client.get('/login')
        print(f"2. Login page status: {login_page.status_code}")
        
        # Check CSRF token in login page
        page_content = login_page.data.decode('utf-8')
        if 'csrf_token' in page_content:
            print("   ✅ CSRF token found in login page")
            
            # Extract CSRF token with better pattern
            import re
            patterns = [
                r'name="csrf_token" type="hidden" value="([^"]+)"',
                r'value="([^"]{40,})"',  # Long tokens are usually CSRF
                r'csrf_token.*?value="([^"]+)"'
            ]
            
            csrf_token = None
            for pattern in patterns:
                match = re.search(pattern, page_content)
                if match:
                    csrf_token = match.group(1)
                    print(f"   ✅ CSRF token extracted: {csrf_token[:20]}...")
                    break
            
            if csrf_token:
                # Test 3: Try login
                login_data = {
                    'username': 'admin',
                    'password': 'admin123',
                    'csrf_token': csrf_token
                }
                
                login_response = client.post('/login', data=login_data, follow_redirects=False)
                print(f"3. Login status: {login_response.status_code}")
                
                if login_response.status_code in [302, 303]:
                    print("   ✅ Login successful (redirect)")
                    
                    # Get session cookie
                    session_cookie = None
                    for cookie in login_response.headers.getlist('Set-Cookie'):
                        if 'session=' in cookie:
                            session_cookie = cookie.split(';')[0]
                            break
                    
                    if session_cookie:
                        print(f"   ✅ Session cookie: {session_cookie[:30]}...")
                        
                        # Test 4: Try prediction
                        headers = {'Cookie': session_cookie}
                        
                        test_text = "Congratulations! You won a free iPhone"
                        prediction_response = client.post('/api/predict', 
                            json={
                                'email_content': test_text,
                                'model': 'rule_based'
                            },
                            headers=headers
                        )
                        
                        print(f"4. Prediction status: {prediction_response.status_code}")
                        print(f"   Content-Type: {prediction_response.content_type}")
                        
                        if prediction_response.status_code == 200:
                            result = prediction_response.get_json()
                            print(f"   ✅ Prediction: {result.get('prediction')}")
                            print(f"   ✅ Confidence: {result.get('confidence')}%")
                        else:
                            print(f"   ❌ Error response: {prediction_response.data[:200]}")
                    else:
                        print("   ❌ No session cookie found")
                else:
                    print(f"   ❌ Login failed: {login_response.data[:200]}")
            else:
                print("   ❌ CSRF token extraction failed")
        else:
            print("   ❌ No CSRF token in login page")
        
        # Test 5: Test prediction without login (should fail)
        print(f"\n5. Testing prediction without authentication:")
        prediction_response = client.post('/api/predict', 
            json={
                'email_content': 'Test message',
                'model': 'rule_based'
            }
        )
        print(f"   Status: {prediction_response.status_code}")
        print(f"   Should be 302 (redirect to login)")

if __name__ == "__main__":
    test_simple_prediction()
