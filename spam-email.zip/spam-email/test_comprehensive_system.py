#!/usr/bin/env python3
"""
Comprehensive test script for the spam email prediction system
Tests both spam and normal examples to verify functionality
"""

import requests
import json
import time

# Test cases
TEST_CASES = [
    # Spam examples
    {
        "email": "Congratulations! You won $5000 lottery",
        "expected": "spam",
        "description": "Lottery spam"
    },
    {
        "email": "Click here to claim your prize",
        "expected": "spam", 
        "description": "Prize claim spam"
    },
    {
        "email": "Free iPhone offer today",
        "expected": "spam",
        "description": "Free offer spam"
    },
    {
        "email": "URGENT: Your account will be suspended. Please update your information immediately!",
        "expected": "spam",
        "description": "Urgent account spam"
    },
    {
        "email": "Make $1000/day working from home! No experience needed! Limited time offer!",
        "expected": "spam",
        "description": "Money making spam"
    },
    
    # Normal examples
    {
        "email": "Meeting scheduled tomorrow",
        "expected": "ham",
        "description": "Normal meeting"
    },
    {
        "email": "Project update attached",
        "expected": "ham",
        "description": "Normal work email"
    },
    {
        "email": "Can you review this document when you get a chance?",
        "expected": "ham",
        "description": "Normal collaboration"
    },
    {
        "email": "Your order has been shipped and will arrive in 3-5 business days",
        "expected": "ham",
        "description": "Normal shipping notification"
    },
    {
        "email": "Happy birthday! Hope you have a wonderful day.",
        "expected": "ham",
        "description": "Normal personal message"
    },
    
    # Random/invalid
    {
        "email": "jevdwhucwqhjbeflj3beoiu18u0398098",
        "expected": "spam",
        "description": "Random gibberish"
    }
]

def test_prediction_api(base_url="http://localhost:5000"):
    """Test the prediction API with test cases"""
    
    print("🧪 Testing Spam Email Prediction System")
    print("=" * 50)
    
    # First, login to get session
    session = requests.Session()
    
    # Try to login (you may need to create a test user first)
    login_data = {
        "username": "testuser",
        "password": "testpass123"
    }
    
    try:
        login_response = session.post(f"{base_url}/login", data=login_data)
        if login_response.status_code == 200:
            print("✅ Logged in successfully")
        else:
            print("⚠️  Login failed, testing without authentication")
    except:
        print("⚠️  Could not connect to login endpoint")
    
    results = []
    
    for i, test_case in enumerate(TEST_CASES, 1):
        print(f"\n📧 Test {i}: {test_case['description']}")
        print(f"   Email: '{test_case['email']}'")
        
        # Test the API
        try:
            response = session.post(
                f"{base_url}/api/predict",
                json={
                    "email_content": test_case["email"],
                    "model": "rule_based"
                },
                headers={"Content-Type": "application/json"}
            )
            
            if response.status_code == 200:
                data = response.json()
                prediction = data.get("prediction", "unknown")
                confidence = data.get("confidence", "unknown")
                risk_level = data.get("risk_level", "unknown")
                keywords = data.get("keywords", [])
                reason = data.get("reason", "")
                
                print(f"   ✅ Status: {response.status_code}")
                print(f"   🎯 Prediction: {prediction}")
                print(f"   📊 Confidence: {confidence}")
                print(f"   ⚠️  Risk Level: {risk_level}")
                print(f"   🔍 Keywords: {keywords}")
                print(f"   📝 Reason: {reason}")
                
                # Check if prediction matches expected
                if prediction == test_case["expected"]:
                    print(f"   ✅ CORRECT - Expected {test_case['expected']}, got {prediction}")
                    results.append({"test": test_case, "result": "PASS", "data": data})
                else:
                    print(f"   ❌ INCORRECT - Expected {test_case['expected']}, got {prediction}")
                    results.append({"test": test_case, "result": "FAIL", "data": data})
                    
            elif response.status_code == 401:
                print(f"   🔒 Authentication required (401)")
                results.append({"test": test_case, "result": "AUTH_ERROR", "data": None})
            else:
                print(f"   ❌ Error: {response.status_code}")
                print(f"   Response: {response.text}")
                results.append({"test": test_case, "result": "ERROR", "data": None})
                
        except requests.exceptions.ConnectionError:
            print(f"   ❌ Connection Error - Is the server running on {base_url}?")
            results.append({"test": test_case, "result": "CONNECTION_ERROR", "data": None})
            break
        except Exception as e:
            print(f"   ❌ Unexpected Error: {e}")
            results.append({"test": test_case, "result": "EXCEPTION", "data": None})
    
    # Summary
    print("\n" + "=" * 50)
    print("📊 TEST SUMMARY")
    print("=" * 50)
    
    passed = len([r for r in results if r["result"] == "PASS"])
    failed = len([r for r in results if r["result"] == "FAIL"])
    errors = len([r for r in results if r["result"] in ["ERROR", "AUTH_ERROR", "CONNECTION_ERROR", "EXCEPTION"]])
    total = len(results)
    
    print(f"✅ Passed: {passed}/{total}")
    print(f"❌ Failed: {failed}/{total}")
    print(f"⚠️  Errors: {errors}/{total}")
    print(f"📈 Success Rate: {(passed/total*100):.1f}%" if total > 0 else "N/A")
    
    # Show failed tests
    if failed > 0:
        print("\n❌ FAILED TESTS:")
        for result in results:
            if result["result"] == "FAIL":
                test = result["test"]
                data = result["data"]
                print(f"   • {test['description']}")
                print(f"     Expected: {test['expected']}, Got: {data.get('prediction', 'unknown')}")
    
    return results

def test_stats_api(base_url="http://localhost:5000"):
    """Test the stats API endpoint"""
    print("\n📈 Testing Stats API")
    print("-" * 30)
    
    session = requests.Session()
    
    try:
        response = session.get(f"{base_url}/api/stats")
        if response.status_code == 200:
            data = response.json()
            print("✅ Stats API working")
            print(f"   User Stats: {data.get('user_stats', {})}")
            print(f"   System Stats: {data.get('system_stats', {})}")
            return True
        elif response.status_code == 401:
            print("🔒 Stats API requires authentication")
            return False
        else:
            print(f"❌ Stats API error: {response.status_code}")
            return False
    except Exception as e:
        print(f"❌ Stats API exception: {e}")
        return False

if __name__ == "__main__":
    print("🚀 Starting Comprehensive Spam Detection System Test")
    print("Make sure the Flask app is running on http://localhost:5000")
    print()
    
    # Test stats API first
    test_stats_api()
    
    # Test prediction API
    results = test_prediction_api()
    
    print("\n🎯 Test completed!")
    print("If you see authentication errors, make sure to:")
    print("1. Create a test user account")
    print("2. Update the login credentials in this script")
    print("3. Or modify the API endpoints to not require login for testing")
