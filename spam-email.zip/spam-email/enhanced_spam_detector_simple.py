#!/usr/bin/env python
"""
Enhanced Spam Email Prediction System with Input Validation (No ML Dependencies)
"""

import re
import string
from collections import Counter

class EnhancedSpamDetector:
    def __init__(self):
        # Enhanced spam patterns for rule-based detection
        self.spam_patterns = {
            'promotional': [
                'free', 'win', 'prize', 'money', 'cash', 'offer', 'discount', 
                'promotion', 'special', 'deal', 'save', 'cheap', 'buy', 'now', 
                'urgent', 'limited', 'act now', 'click here', 'order now', 'exclusive'
            ],
            'lottery': [
                'lottery', 'winner', 'congratulations', 'selected', 'million', 
                'billion', 'prize', 'claim', 'reward', 'congrats'
            ],
            'suspicious': [
                'viagra', 'casino', 'poker', 'bet', 'gamble', 'xxx', 'adult', 
                'dating', 'webcam', 'sexy', 'naked', 'hot' , 'hack'
            ],
            'financial': [
                'loan', 'credit', 'debt', 'investment', 'insurance', 'refund', 
                'guaranteed', 'risk', 'scam', 'fraud', 'phishing', 'hack', 'breach'
            ],
            'urgency': [
                'urgent', 'immediate', 'final', 'last chance', 'limited time', 
                'expiring', 'act now', 'don\'t wait', 'hurry'
            ]
        }
        
        # Suspicious patterns
        self.suspicious_patterns = {
            'exclamation': r'!{2,}',
            'caps': r'[A-Z]{4,}',
            'numbers': r'\d{4,}',
            'special_chars': r'[@#$%^&*]{2,}',
            'random_alphanum': r'[a-zA-Z0-9]{8,}',
            'number_letter_mix': r'\d+[a-zA-Z]+\d+'
        }
        
        # Legitimate indicators
        self.legitimate_patterns = [
            'meeting', 'project', 'report', 'deadline', 'team', 'office', 
            'schedule', 'appointment', 'conference', 'presentation', 
            'document', 'attachment', 'sincerely', 'regards', 'best', 
            'thank', 'appreciate', 'hello', 'hi', 'dear', 'colleague'
        ]
    
    def validate_input(self, text):
        """Validate input text and detect invalid content"""
        if not text or not text.strip():
            return {
                'valid': False,
                'error': 'Email content is required.',
                'reason': 'empty_input'
            }
        
        text = text.strip()
        
        # Check minimum length
        if len(text) < 10:
            return {
                'valid': False,
                'error': 'Email content too short. Please enter a valid email message.',
                'reason': 'too_short'
            }
        
        # Check maximum length
        if len(text) > 10000:
            return {
                'valid': False,
                'error': 'Email content too long (max 10KB).',
                'reason': 'too_long'
            }
        
        # Check for gibberish/random strings
        gibberish_result = self._is_gibberish(text)
        if gibberish_result['is_gibberish']:
            return {
                'valid': False,
                'error': 'Invalid email content. Please enter a meaningful email message.',
                'reason': 'gibberish',
                'details': gibberish_result['details']
            }
        
        # Check for excessive numbers/symbols
        if self._has_excessive_numbers(text):
            return {
                'valid': False,
                'error': 'Invalid email content. Too many numbers detected.',
                'reason': 'excessive_numbers'
            }
        
        if self._has_excessive_symbols(text):
            return {
                'valid': False,
                'error': 'Invalid email content. Too many special characters detected.',
                'reason': 'excessive_symbols'
            }
        
        # Check minimum word count
        words = text.split()
        if len(words) < 3:
            return {
                'valid': False,
                'error': 'Email content too brief. Please enter a complete message.',
                'reason': 'too_few_words'
            }
        
        return {'valid': True, 'error': None, 'reason': None}
    
    def _is_gibberish(self, text):
        """Detect gibberish or random strings"""
        details = []
        
        # Check alphabet ratio
        alpha_chars = sum(1 for c in text if c.isalpha())
        total_chars = len(text.replace(' ', ''))
        if total_chars > 0:
            alpha_ratio = alpha_chars / total_chars
            if alpha_ratio < 0.3:  # Less than 30% letters
                details.append(f"Low alphabet ratio: {alpha_ratio:.2f}")
                return {'is_gibberish': True, 'details': details}
        
        # Check for random character patterns
        words = text.split()
        gibberish_words = 0
        
        for word in words:
            if len(word) > 5:
                # Calculate character diversity
                unique_chars = len(set(word.lower()))
                diversity_ratio = unique_chars / len(word)
                
                # High diversity with no vowels suggests gibberish
                vowels = sum(1 for c in word.lower() if c in 'aeiou')
                vowel_ratio = vowels / len(word)
                
                if diversity_ratio > 0.8 and vowel_ratio < 0.2:
                    gibberish_words += 1
                    details.append(f"Gibberish word: {word}")
        
        # If more than 30% of words are gibberish
        gibberish_ratio = gibberish_words / len(words) if words else 0
        if gibberish_ratio > 0.3:
            details.append(f"Gibberish words ratio: {gibberish_ratio:.2f}")
            return {'is_gibberish': True, 'details': details}
        
        return {'is_gibberish': False, 'details': details}
    
    def _has_excessive_numbers(self, text):
        """Check for excessive numbers"""
        numbers = re.findall(r'\d+', text)
        total_digits = sum(len(num) for num in numbers)
        total_chars = len(text.replace(' ', ''))
        
        if total_chars > 0:
            number_ratio = total_digits / total_chars
            return number_ratio > 0.4  # More than 40% digits
        
        return False
    
    def _has_excessive_symbols(self, text):
        """Check for excessive special characters"""
        special_chars = sum(1 for c in text if not c.isalnum() and not c.isspace())
        total_chars = len(text.replace(' ', ''))
        
        if total_chars > 0:
            symbol_ratio = special_chars / total_chars
            return symbol_ratio > 0.3  # More than 30% special characters
        
        return False
    
    def preprocess_text(self, text):
        """Enhanced text preprocessing"""
        # Convert to lowercase
        text = text.lower()
        
        # Remove URLs
        text = re.sub(r'http[s]?://(?:[a-zA-Z]|[0-9]|[$-_@.&+]|[!*\\(\\),]|(?:%[0-9a-fA-F][0-9a-fA-F]))+', '', text)
        
        # Remove email addresses
        text = re.sub(r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b', '', text)
        
        # Remove excessive numbers (keep some for context)
        text = re.sub(r'\d{4,}', '', text)
        
        # Remove special characters but keep basic punctuation
        text = re.sub(r'[^a-zA-Z\s\!\?\.\,\-]', '', text)
        
        # Tokenize and remove short words
        words = [word for word in text.split() if len(word) > 2]
        
        return ' '.join(words)
    
    def detect_spam_patterns(self, text):
        """Rule-based spam pattern detection"""
        spam_indicators = []
        spam_score = 0.0
        
        text_lower = text.lower()
        
        # Check spam keywords
        for category, keywords in self.spam_patterns.items():
            matches = []
            for keyword in keywords:
                if keyword in text_lower:
                    matches.append(keyword)
                    spam_score += 0.3
            
            if matches:
                spam_indicators.append({
                    'type': category,
                    'matches': matches,
                    'count': len(matches)
                })
        
        # Check suspicious patterns
        for pattern_name, pattern in self.suspicious_patterns.items():
            matches = re.findall(pattern, text)
            if matches:
                spam_indicators.append({
                    'type': pattern_name,
                    'matches': matches[:3],  # Show first 3 examples
                    'count': len(matches)
                })
                spam_score += len(matches) * 0.2
        
        # Check legitimate patterns (reduce score)
        legitimate_matches = 0
        for legit_word in self.legitimate_patterns:
            if legit_word in text_lower:
                legitimate_matches += 1
                spam_score -= 0.2
        
        if legitimate_matches > 0:
            spam_indicators.append({
                'type': 'legitimate',
                'matches': legitimate_matches,
                'count': legitimate_matches
            })
        
        return spam_indicators, max(0, spam_score)
    
    def predict(self, text):
        """Main prediction method"""
        # Step 1: Validate input
        validation = self.validate_input(text)
        if not validation['valid']:
            return {
                'prediction': 'invalid',
                'confidence': 0.0,
                'risk_level': 'low',
                'reason': validation['error'],
                'error': validation['error']
            }
        
        # Step 2: Detect spam patterns
        spam_patterns, pattern_score = self.detect_spam_patterns(text)
        
        # Step 3: Preprocess text
        processed_text = self.preprocess_text(text)
        
        # Step 4: Rule-based prediction
        if pattern_score > 1.0:
            prediction = 'spam'
            confidence = min(0.95, (pattern_score / 2.0) + 0.5)
            risk_level = 'high'
        elif pattern_score > 0.5:
            prediction = 'spam'
            confidence = min(0.85, (pattern_score / 1.5) + 0.4)
            risk_level = 'medium'
        else:
            prediction = 'ham'
            confidence = 0.8
            risk_level = 'low'
        
        # Step 5: Format response
        response = {
            'prediction': prediction,
            'confidence': round(confidence * 100, 1),
            'risk_level': risk_level,
            'processed_text': processed_text,
            'spam_patterns': spam_patterns,
            'pattern_score': round(pattern_score, 2)
        }
        
        # Add reason for prediction
        if prediction == 'spam' and spam_patterns:
            spam_types = [p['type'] for p in spam_patterns if p['type'] != 'legitimate']
            if spam_types:
                response['reason'] = f"Suspicious patterns detected: {', '.join(spam_types[:3])}"
        elif prediction == 'ham':
            response['reason'] = "Content appears to be legitimate"
        
        return response

# Test the enhanced detector
if __name__ == "__main__":
    detector = EnhancedSpamDetector()
    
    test_cases = [
        ("Congratulations! You won a free iPhone", "Expected: Spam"),
        ("Meeting scheduled tomorrow at 10am", "Expected: Ham"),
        ("jevdwhucwqhjbeflj3beoiu18u0398098", "Expected: Invalid"),
        ("902y3109r1v ohf kno13hub2-018739-219ep# D\\", "Expected: Spam/Invalid"),
        ("Hi team, please review the attached report", "Expected: Ham"),
        ("FREE VIAGRA!!! SPECIAL PROMOTION!!!", "Expected: Spam"),
        ("Hello, I hope this email finds you well", "Expected: Ham"),
        ("ACT NOW! GUARANTEED CASH REWARD!!!", "Expected: Spam"),
        ("", "Expected: Invalid"),
        ("Hi", "Expected: Invalid"),
        ("Limited time offer! Buy now and get 50% discount!", "Expected: Spam")
    ]
    
    print("🔧 TESTING ENHANCED SPAM DETECTOR")
    print("=" * 70)
    
    correct_predictions = 0
    total_predictions = len(test_cases)
    
    for i, (text, expected) in enumerate(test_cases, 1):
        print(f"\n{i}. Testing: {text[:50]}{'...' if len(text) > 50 else ''}")
        print(f"   Expected: {expected}")
        
        result = detector.predict(text)
        
        print(f"   Prediction: {result['prediction']}")
        print(f"   Confidence: {result['confidence']}%")
        print(f"   Risk Level: {result['risk_level']}")
        
        if 'error' in result:
            print(f"   Error: {result['error']}")
        elif 'reason' in result:
            print(f"   Reason: {result['reason']}")
        
        if result.get('spam_patterns'):
            pattern_types = [p['type'] for p in result['spam_patterns']]
            print(f"   Patterns: {', '.join(pattern_types)}")
        
        # Check if prediction matches expectation
        expected_lower = expected.lower().split()[-1]  # Get last word (spam/ham/invalid)
        if result['prediction'] == expected_lower:
            correct_predictions += 1
            print(f"   Result: ✅ CORRECT")
        else:
            print(f"   Result: ❌ WRONG")
        
        print("-" * 50)
    
    # Calculate accuracy
    accuracy = (correct_predictions / total_predictions) * 100
    print(f"\n📊 ACCURACY RESULTS:")
    print(f"   Correct: {correct_predictions}/{total_predictions}")
    print(f"   Accuracy: {accuracy:.1f}%")
    
    print(f"\n🎯 ENHANCED SPAM DETECTION SYSTEM {'✅ WORKING GREAT!' if accuracy >= 80 else '❌ NEEDS IMPROVEMENT'}")
