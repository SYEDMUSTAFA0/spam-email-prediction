#!/usr/bin/env python
"""
Quick test to create user and test API
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from app import app, db, User, classifier
from werkzeug.security import generate_password_hash

def create_test_user():
    with app.app_context():
        # Check if user already exists
        existing_user = User.query.filter_by(username='test').first()
        if existing_user:
            print("✅ Test user already exists: username='test', password='test123'")
            return existing_user
        
        # Create test user with unique email
        import time
        timestamp = int(time.time())
        test_user = User(
            username='test',
            email=f'test{timestamp}@example.com',
            password_hash=generate_password_hash('test123')
        )
        
        db.session.add(test_user)
        db.session.commit()
        print("✅ Test user created: username='test', password='test123'")
        return test_user

def test_prediction():
    with app.app_context():
        # Test the classifier directly
        test_email = "heyy"
        prediction, confidence, risk_level = classifier.predict(test_email, 'ensemble')
        
        print(f"✅ Direct ML test:")
        print(f"   Email: '{test_email}'")
        print(f"   Prediction: {prediction}")
        print(f"   Confidence: {confidence:.2f}")
        print(f"   Risk Level: {risk_level}")

if __name__ == "__main__":
    print("🔧 Quick test setup...")
    create_test_user()
    test_prediction()
    print("\n🌐 You can now:")
    print("1. Go to http://localhost:5000")
    print("2. Login with username='test', password='test123'")
    print("3. Test the spam detection on the dashboard")
