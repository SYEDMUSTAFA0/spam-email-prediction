#!/usr/bin/env python3

import sys
import os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from app import rule_based_detection, detect_gibberish, is_email_like_content, has_proper_structure

# Test cases
test_cases = [
    'asdfghjklqwerty',  # Random keyboard mashing
    'xyz123abc456',     # Mixed alphanumeric
    'hi',               # Very short
    'FREE MONEY NOW WIN PRIZE',  # Traditional spam
    'Hello, I hope this email finds you well. Please let me know if you need anything.',  # Normal email
    'bcdfghjklmnpqrstvwxyz',  # No vowels
    'Congratulations! You have won $1,000,000!',  # Lottery spam
    'randomtext123',    # Short random
    'This is a legitimate business email regarding our meeting tomorrow at 2 PM.',  # Professional email
    'CLICK HERE NOW!!! FREE!!!',  # Excessive punctuation
]

print('Testing enhanced spam detection:')
print('=' * 50)

for i, test in enumerate(test_cases, 1):
    print(f'\nTest {i}: {test[:50]}...' if len(test) > 50 else f'\nTest {i}: {test}')
    
    prediction, confidence, risk_level, keywords = rule_based_detection(test)
    gibberish_score = detect_gibberish(test)
    email_like = is_email_like_content(test)
    proper_structure = has_proper_structure(test)
    
    print(f'Prediction: {prediction}')
    print(f'Confidence: {confidence:.2f}')
    print(f'Risk Level: {risk_level}')
    print(f'Keywords: {keywords}')
    print(f'Gibberish Score: {gibberish_score:.2f}')
    print(f'Email Like: {email_like}')
    print(f'Proper Structure: {proper_structure}')
    print('-' * 30)

print('\nSummary:')
print('Random strings and gibberish should be detected as SPAM')
print('Proper emails should be detected as NOT SPAM')
